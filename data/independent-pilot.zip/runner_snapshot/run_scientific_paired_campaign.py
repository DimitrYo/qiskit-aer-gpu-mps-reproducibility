#!/usr/bin/env python3
"""P2 paired orchestration; no duplicated reference calculation or timer.

Freeze with --contract FILE --run-dir NEW_DIRECTORY. This copies the exact
runner sources, then runs correctness for every input/configuration before
session 0. Confirmation stops after session 0; --resume starts session 1 only
after its frozen minimum gap. --validate-only uses the archived runner, never
the subsequently edited live E2/E3 files. No failed cell is retried in place.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import inspect
import itertools
import json
import math
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys
import time

from run_e2_numerical_correctness_pilot import load_manifest, manifest_payload, sha256_json
from run_scientific_cpu_pilot import (
    THREAD_VARIABLES, controlled_environment, digest, read, runtime_state,
    validate_report as validate_base_report, verify_candidate, write_new,
)
from scientific_circuit_inputs import build_scientific_circuit, load_scientific_manifest

HERE = Path(__file__).resolve().parent
SNAPSHOT_FILES = (
    "run_scientific_paired_campaign.py", "run_scientific_cpu_pilot.py",
    "run_e2_numerical_correctness_pilot.py", "run_e3_timing_cell.py",
    "mps_execution_environment.py", "scientific_circuit_inputs.py",
    "scientific_campaign_statistics.py",
)
PROTOCOL = {"warmups": 5, "timed_repetitions": 20, "shots": 100, "threads": 6,
            "max_bond_dimension": 1024, "truncation_threshold": 0.0,
            "precision": "double", "dispatch_threshold_elements": 8401}
PINNED_CUSTOM_REVISION = "a1242579272784330b217085fe11b7e1481922ad"
RUNTIME_VERSIONS = {"qiskit": "2.5.0", "qiskit_aer": "0.17.2",
                    "numpy": "2.4.6", "threadpoolctl": "3.6.0"}
LOADER_INJECTION_KEYS = ("LD_PRELOAD", "LD_AUDIT")


def utc_stamp():
    return datetime.now(timezone.utc).isoformat()


def workload(spec):
    return f"BW-{spec['qubits']}" if spec["kind"] == "brickwork" else f"pQFT-{spec['qubits']}"


def make_schedule(input_ids, candidate_ids, stage, seed, *, workload_groups=None):
    """Balance permutations within workload; freeze first order and reverse."""
    rng = random.Random(seed)
    inputs = list(input_ids)
    rng.shuffle(inputs)
    groups = workload_groups or {input_id: "all" for input_id in inputs}
    if set(groups) != set(inputs):
        raise RuntimeError("schedule workload groups differ from frozen input IDs")
    orders = {}
    for group in sorted(set(groups.values())):
        grouped_inputs = [input_id for input_id in inputs if groups[input_id] == group]
        permutations = list(itertools.permutations(sorted(candidate_ids)))
        repeated = []
        while len(repeated) < len(grouped_inputs):
            rng.shuffle(permutations)
            repeated.extend(permutations)
        orders.update({input_id: list(order) for input_id, order in zip(grouped_inputs, repeated)})
    first = {"input_order": inputs, "candidate_orders": orders}
    if stage == "pilot":
        return [first]
    return [first, {"input_order": list(reversed(inputs)),
                    "candidate_orders": {key: list(reversed(value)) for key, value in orders.items()}}]


def roles(contract):
    return {candidate["role"]: candidate for candidate in contract["candidates"]}


def paired_environment(candidate):
    """Remove loader instrumentation before exec, not after it is loaded."""
    environment = controlled_environment(candidate)
    cleared = [key for key in LOADER_INJECTION_KEYS if key in environment]
    for key in LOADER_INJECTION_KEYS:
        environment.pop(key, None)
    return environment, cleared


def paired_runtime_state(candidate):
    runtime = runtime_state(candidate)
    import numpy
    import threadpoolctl
    runtime["package_versions"] = {"qiskit": runtime["qiskit_version"],
        "qiskit_aer": runtime["aer_version"], "numpy": numpy.__version__,
        "threadpoolctl": threadpoolctl.__version__}
    runtime["loader_injection_present"] = {key: key in os.environ for key in LOADER_INJECTION_KEYS}
    return runtime


def validate_report(report, contract, contract_hash, candidate, manifest_hash):
    validate_base_report(report, contract, contract_hash, candidate, manifest_hash)
    runtime = report["runtime"]
    if runtime.get("package_versions") != contract["runtime_versions"]:
        raise RuntimeError("runtime package versions differ from frozen P2 environment")
    if runtime.get("loader_injection_present") != {key: False for key in LOADER_INJECTION_KEYS}:
        raise RuntimeError("loader instrumentation is present or its absence was not recorded")


def validate_contract(contract, manifest_path=None, runner_dir=HERE):
    if contract.get("schema_version") != 1 or contract.get("stage") not in {"P2_PILOT", "P2_CONFIRMATION"}:
        raise RuntimeError("not a P2 paired campaign contract")
    stage = "pilot" if contract["stage"] == "P2_PILOT" else "confirmation"
    if contract.get("protocol") != PROTOCOL:
        raise RuntimeError("P2 protocol differs from 5/20/100, double, chi1024/cutoff0 and six threads")
    if contract.get("runtime_versions") != RUNTIME_VERSIONS:
        raise RuntimeError("freeze the validated Qiskit, Aer, NumPy and threadpoolctl versions")
    for key in ("seed_simulator", "seed_transpiler", "bootstrap_seed", "order_seed"):
        if type(contract.get(key)) is not int or not 0 <= contract[key] <= 2**32 - 1:
            raise RuntimeError(f"freeze an explicit uint32 {key}")
    affinity = contract.get("cpu_affinity", [])
    if len(affinity) != 6 or len(set(affinity)) != 6 or any(type(value) is not int or value < 0 for value in affinity):
        raise RuntimeError("freeze six distinct CPU affinity IDs from P1")
    if contract.get("minimum_session_gap_seconds") != (0 if stage == "pilot" else 1800):
        raise RuntimeError("confirmation requires the preregistered 30-minute inter-session gap")
    if type(contract.get("cell_wall_time_seconds")) not in (int, float) or not 0 < contract["cell_wall_time_seconds"] < math.inf:
        raise RuntimeError("declare a positive finite cell wall-time cap")
    candidates = contract.get("candidates", [])
    by_role = roles(contract)
    if len(by_role) != len(candidates) or len({c["id"] for c in candidates}) != len(candidates):
        raise RuntimeError("candidate IDs and roles must be unique")
    if not {"selected_cpu", "gpu"} <= set(by_role) or set(by_role) - {"selected_cpu", "gpu", "internal_cpu"}:
        raise RuntimeError("declare selected_cpu, gpu, and only the required internal_cpu")
    cpu, gpu = by_role["selected_cpu"], by_role["gpu"]
    if cpu["backend"] not in {"custom_cpu", "upstream_cpu"} or gpu["backend"] != "custom_gpu":
        raise RuntimeError("invalid CPU/GPU candidate roles")
    if any(type(c.get("mps_lapack")) is not bool for c in candidates) or cpu["mps_lapack"] != gpu["mps_lapack"]:
        raise RuntimeError("GPU CPU-fallback LAPACK policy must match the selected CPU")
    internal = by_role.get("internal_cpu")
    if (cpu["backend"] == "upstream_cpu") != (internal is not None):
        raise RuntimeError("an upstream selected CPU requires a separate same-source CPU control")
    same_source_cpu = internal or cpu
    if same_source_cpu["backend"] != "custom_cpu" or same_source_cpu["mps_lapack"] != gpu["mps_lapack"]:
        raise RuntimeError("invalid same-source CPU control")
    for key in ("source_directory", "source_revision", "extension", "extension_sha256", "python",
                "pythonpath", "library_search_paths"):
        if same_source_cpu.get(key) != gpu.get(key):
            raise RuntimeError("same-source CPU and GPU must use the identical build and interpreter")
    if gpu.get("source_revision") != PINNED_CUSTOM_REVISION:
        raise RuntimeError("P2 GPU source is not the validated P0 revision")
    for candidate in candidates:
        if not candidate["id"] or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for ch in candidate["id"]):
            raise RuntimeError("candidate ID is not a safe artifact directory name")
        if len(candidate.get("extension_sha256", "")) != 64:
            raise RuntimeError("candidate extension hash missing")
    manifest = load_scientific_manifest(Path(manifest_path or contract["manifest"]), expected_stage=stage)
    if manifest["manifest_sha256"] != contract["manifest_sha256"]:
        raise RuntimeError("frozen input manifest changed")
    input_ids = [spec["id"] for spec in manifest["circuits"]]
    if any(spec.get("exact_reference") is not True or spec.get("offload_required") is not False for spec in manifest["circuits"]):
        raise RuntimeError("all independent inputs require exact references and retain no-offload outcomes")
    expected = make_schedule(input_ids, [c["id"] for c in candidates], stage, contract["order_seed"],
                             workload_groups={spec["id"]: workload(spec) for spec in manifest["circuits"]})
    if contract.get("sessions") != expected:
        raise RuntimeError("session order differs from the frozen counterbalanced schedule")
    if set(contract.get("runner_sha256", {})) != set(SNAPSHOT_FILES):
        raise RuntimeError("runner snapshot inventory is incomplete")
    for name in SNAPSHOT_FILES:
        if contract["runner_sha256"][name] != digest(Path(runner_dir) / name):
            raise RuntimeError(f"runner snapshot hash mismatch: {name}")
    return manifest


def validate_baseline_binding(contract, baseline_dir):
    binding = contract["p1_binding"]
    selection_path, p1_path = baseline_dir / "selection.json", baseline_dir / "contract.json"
    if digest(selection_path) != binding["selection_sha256"] or digest(p1_path) != binding["contract_sha256"]:
        raise RuntimeError("P1 selection/contract changed after P2 freeze")
    selection, p1 = read(selection_path), read(p1_path)
    selected = roles(contract)["selected_cpu"]
    if (selection.get("status") != "PASS" or selection.get("stage") != "P1_CPU_SELECTION" or
            selection["selected_cpu"] != selected["id"] or selection["contract_sha256"] != digest(p1_path)):
        raise RuntimeError("P2 CPU is not the source-bound P1 selection")
    original = next((c for c in p1["candidates"] if c["id"] == selected["id"]), None)
    if original is None or any(selected.get(key) != value for key, value in original.items()):
        raise RuntimeError("selected CPU configuration changed after P1 selection")
    if contract["cpu_affinity"] != p1["cpu_affinity"]:
        raise RuntimeError("P2 CPU affinity differs from P1")


def validate_completed_p1(p1_run_dir):
    """Revalidate stored P1 data using its archived sources; never simulate."""
    p1_path = p1_run_dir / "contract.json"
    p1, selection = read(p1_path), read(p1_run_dir / "cpu_selection.json")
    if selection.get("status") != "PASS" or selection.get("contract_sha256") != digest(p1_path):
        raise RuntimeError("P1 selection is not complete and contract-bound")
    snapshot = p1_run_dir / "runner_snapshot"
    for name, expected in p1["runner_sha256"].items():
        if Path(name).name != name or digest(snapshot / name) != expected:
            raise RuntimeError("P1 validation snapshot differs from its measured runner")
    selected = next(c for c in p1["candidates"] if c["id"] == selection["selected_cpu"])
    environment, _ = paired_environment(selected)
    completed = subprocess.run([selected["python"], str(snapshot / "run_scientific_cpu_pilot.py"),
        "--contract", str(p1_path), "--run-dir", str(p1_run_dir), "--validate-only"],
        env=environment, capture_output=True, text=True, check=True)
    if json.loads(completed.stdout) != selection:
        raise RuntimeError("P1 stored-data validation disagrees with its saved selection")
    return p1, selection


def validate_precision_binding(plan, contract, manifest):
    count = sum(workload(spec) == "BW-16" for spec in manifest["circuits"])
    if count != plan["selected_primary_inputs"]:
        raise RuntimeError("confirmation input count differs from fixed pilot precision decision")
    if (plan["cpu_candidate"] != roles(contract)["selected_cpu"]["id"] or
            plan["gpu_candidate"] != roles(contract)["gpu"]["id"]):
        raise RuntimeError("pilot precision planning used a different CPU/GPU contrast")
    if plan.get("pilot_input_exclusion_required") is not True:
        raise RuntimeError("pilot plan does not preserve its input-exclusion requirement")
    if set(plan["pilot_input_ids"]) & {spec["id"] for spec in manifest["circuits"]}:
        raise RuntimeError("pilot inputs must not enter confirmation")


def prepare_contract(p1_run_dir, manifest_path, *, order_seed, bootstrap_seed=20260907,
                     cell_wall_time_seconds=3600, pilot_run_dir=None):
    """Prepare a reviewable contract from validated records without running P2."""
    p1_run_dir, manifest_path = Path(p1_run_dir).resolve(), Path(manifest_path).resolve()
    p1, selection = validate_completed_p1(p1_run_dir)
    stage = "confirmation" if pilot_run_dir is not None else "pilot"
    manifest = load_scientific_manifest(manifest_path, expected_stage=stage)
    selected = next(c for c in p1["candidates"] if c["id"] == selection["selected_cpu"])
    source_cpu = next(c for c in p1["candidates"]
                      if c["backend"] == "custom_cpu" and c["mps_lapack"] is selected["mps_lapack"])
    gpu = {**source_cpu, "id": "custom_gpu_lapack" if selected["mps_lapack"] else "custom_gpu",
           "backend": "custom_gpu", "role": "gpu"}
    candidates = [{**selected, "role": "selected_cpu"}, gpu]
    if selected["backend"] == "upstream_cpu":
        candidates.append({**source_cpu, "role": "internal_cpu"})
    contract = {"schema_version": 1, "stage": "P2_CONFIRMATION" if stage == "confirmation" else "P2_PILOT",
        "protocol": dict(PROTOCOL), "runtime_versions": dict(RUNTIME_VERSIONS),
        "cpu_affinity": list(p1["cpu_affinity"]), "minimum_session_gap_seconds": 1800 if stage == "confirmation" else 0,
        "cell_wall_time_seconds": cell_wall_time_seconds, "candidates": candidates,
        "manifest": str(manifest_path), "manifest_sha256": manifest["manifest_sha256"],
        "seed_simulator": p1["seed_simulator"], "seed_transpiler": p1["seed_transpiler"],
        "order_seed": order_seed, "bootstrap_seed": bootstrap_seed,
        "runner_sha256": {name: digest(HERE / name) for name in SNAPSHOT_FILES},
        "p1_binding": {"selection_path": str(p1_run_dir / "cpu_selection.json"),
            "selection_sha256": digest(p1_run_dir / "cpu_selection.json"),
            "contract_path": str(p1_run_dir / "contract.json"), "contract_sha256": digest(p1_run_dir / "contract.json")}}
    contract["sessions"] = make_schedule([spec["id"] for spec in manifest["circuits"]],
        [candidate["id"] for candidate in candidates], stage, order_seed,
        workload_groups={spec["id"]: workload(spec) for spec in manifest["circuits"]})
    if pilot_run_dir is not None:
        pilot_run_dir = Path(pilot_run_dir).resolve()
        environment, _ = paired_environment(selected)
        completed = subprocess.run([selected["python"], str(pilot_run_dir / "runner_snapshot" / Path(__file__).name),
            "--run-dir", str(pilot_run_dir), "--validate-only"],
            env=environment, capture_output=True, text=True, check=True)
        validated = json.loads(completed.stdout)
        plan_path = pilot_run_dir / "sample_size_plan.json"
        if (validated != read(pilot_run_dir / "analysis.json") or validated.get("stage") != "P2_PILOT" or
                validated.get("status") != "PASS" or validated["sample_size_plan"] != read(plan_path)):
            raise RuntimeError("paired pilot records do not reproduce their saved precision plan")
        validate_precision_binding(validated["sample_size_plan"], contract, manifest)
        contract["pilot_binding"] = {"sample_size_path": str(plan_path), "sample_size_sha256": digest(plan_path)}
    validate_contract(contract)
    return contract


def verify_archive(run_dir):
    contract = read(run_dir / "contract.json")
    manifest = validate_contract(contract, run_dir / "manifest.json", run_dir / "runner_snapshot")
    inventory = read(run_dir / "runner_snapshot.json")
    if inventory != {"schema_version": 1, "files_sha256": contract["runner_sha256"]}:
        raise RuntimeError("snapshot registry differs from frozen contract")
    validate_baseline_binding(contract, run_dir / "baseline")
    if contract["stage"] == "P2_CONFIRMATION":
        binding = contract["pilot_binding"]
        plan_path = run_dir / "baseline" / "pilot_sample_size.json"
        if digest(plan_path) != binding["sample_size_sha256"]:
            raise RuntimeError("pilot sample-size decision changed")
        plan = read(plan_path)
        validate_precision_binding(plan, contract, manifest)
    return contract, manifest


def freeze_campaign(contract_path, run_dir):
    contract = read(contract_path)
    manifest = validate_contract(contract)
    if run_dir.exists():
        raise RuntimeError("refusing to reuse any campaign directory, including a failed run")
    from run_e2_numerical_correctness_pilot import run_pilot
    from run_e3_timing_cell import execute_cell
    if any("circuit_builder" not in inspect.signature(function).parameters for function in (run_pilot, execute_cell)):
        raise RuntimeError("P2 requires the reviewed optional circuit_builder callback in E2/E3")
    run_dir.mkdir(parents=True)
    write_new(run_dir / "contract.json", contract)
    write_new(run_dir / "manifest.json", manifest)
    snapshot = run_dir / "runner_snapshot"
    snapshot.mkdir()
    for name in SNAPSHOT_FILES:
        shutil.copyfile(HERE / name, snapshot / name)
    write_new(run_dir / "runner_snapshot.json", {"schema_version": 1, "files_sha256": contract["runner_sha256"]})
    baseline = run_dir / "baseline"
    baseline.mkdir()
    shutil.copyfile(contract["p1_binding"]["selection_path"], baseline / "selection.json")
    shutil.copyfile(contract["p1_binding"]["contract_path"], baseline / "contract.json")
    if contract["stage"] == "P2_CONFIRMATION":
        shutil.copyfile(contract["pilot_binding"]["sample_size_path"], baseline / "pilot_sample_size.json")
    for spec in manifest["circuits"]:
        single = {"schema_version": 1, "purpose": manifest["purpose"], "circuits": [spec]}
        single["manifest_sha256"] = sha256_json(manifest_payload(single))
        write_new(run_dir / "inputs" / f"{spec['id']}.json", single)
    verify_archive(run_dir)


def checked_single_manifest(run_dir, input_id, manifest):
    spec = next((spec for spec in manifest["circuits"] if spec["id"] == input_id), None)
    single = load_manifest(run_dir / "inputs" / f"{input_id}.json")
    if spec is None or single["circuits"] != [spec]:
        raise RuntimeError("single-input cell differs from the frozen independent input")
    return single


def validate_config(config, contract, candidate, shots):
    expected = {"method": "matrix_product_state", "device": "GPU" if candidate["backend"] == "custom_gpu" else "CPU",
                "precision": "double", "shots": shots, "max_bond_dimension": 1024,
                "truncation_threshold": 0.0, "seed_transpiler": contract["seed_transpiler"],
                "mps_lapack": candidate["mps_lapack"]}
    if shots == 100:
        expected["seed_simulator"] = contract["seed_simulator"]
    if any(config.get(key) != value for key, value in expected.items()):
        raise RuntimeError("cell configuration differs from frozen P2 protocol")


def validate_correctness(report, contract, contract_hash, candidate, single, evidence_dir=None):
    validate_report(report, contract, contract_hash, candidate, single["manifest_sha256"])
    validate_config(report["simulation_config"], contract, candidate, 1)
    if report.get("svd_reconstruction_validation") is not True or len(report["records"]) != 1:
        raise RuntimeError("missing reconstruction-enabled exact correctness gate")
    spec, record = single["circuits"][0], report["records"][0]
    if record["status"] != "PASS" or record["circuit_id"] != spec["id"] or record["qasm_sha256"] != spec["qasm_sha256"]:
        raise RuntimeError("failed or mismatched independent-input correctness gate")
    reference, mps = record["reference"], record["mps"]
    if (reference["fidelity_min"] != 1.0 - 1e-12 or mps["fidelity_min"] != 1.0 - 1e-10 or
            mps["norm_error_max"] != 1e-10 or
            not all(math.isfinite(float(value)) for value in (reference["fidelity"], mps["fidelity"], mps["norm_error"])) or
            reference["fidelity"] < 1.0 - 1e-12 or mps["fidelity"] < 1.0 - 1e-10 or not 0 <= mps["norm_error"] <= 1e-10):
        raise RuntimeError("original exact numerical acceptance thresholds not met")
    if len(record.get("compiled_qasm_sha256", "")) != 64:
        raise RuntimeError("missing measured-graph fingerprint from correctness preparation")
    if candidate["backend"] == "custom_gpu":
        if report.get("offload_observation") not in {"OBSERVED", "NOT_OBSERVED"}:
            raise RuntimeError("missing explicit GPU offload outcome")
        if report["offload_observation"] == "OBSERVED":
            proof = report["offload_proof"]
            path = Path(evidence_dir) / "gpu_svd.events.jsonl" if evidence_dir is not None else Path(proof["events_path"])
            records = [json.loads(line) for line in path.read_text().splitlines()]
            if (not records or len(records) != proof["event_count"] or digest(path) != proof["event_sha256"] or
                    any(event.get("event") != "cutensor_csvd_wrapper" for event in records)):
                raise RuntimeError("GPU correctness offload proof changed or is invalid")
    return record["compiled_qasm_sha256"]


def expected_inactive_environment():
    from mps_execution_environment import DIAGNOSTIC_PATH_KEYS, RECONSTRUCTION_KEYS
    return {"dispatch_threshold_elements": 8401,
            "diagnostic_paths_enabled": {key: False for key in DIAGNOSTIC_PATH_KEYS},
            "reconstruction_checks_enabled": {key: False for key in RECONSTRUCTION_KEYS}}


def validate_timing_cell(directory, contract, contract_hash, candidate, single, compiled_hash, run_id):
    report = read(directory / "timing_report.json")
    validate_report(report, contract, contract_hash, candidate, single["manifest_sha256"])
    validate_config(report["simulation_config"], contract, candidate, 100)
    if report.get("instrumentation_mode") != "none":
        raise RuntimeError("instrumented samples cannot enter P2 timing analysis")
    if report.get("warmup_count") != 5 or report.get("timed_repetition_count") != 20:
        raise RuntimeError("incomplete 5/20 cell report")
    samples = []
    for name, count, warmup in (("warmups.jsonl", 5, True), ("timings.jsonl", 20, False)):
        records = [json.loads(line) for line in (directory / name).read_text().splitlines()]
        if len(records) != count or {record["sample_index"] for record in records} != set(range(count)):
            raise RuntimeError("missing, extra or duplicate warmup/timing samples")
        for record in records:
            if (record["is_warmup"] is not warmup or record["run_id"] != run_id or
                    record["circuit_id"] != single["circuits"][0]["id"] or record["backend"] != candidate["backend"] or
                    record.get("compiled_qasm_sha256") != compiled_hash or
                    type(record["elapsed_seconds"]) not in (int, float) or
                    not math.isfinite(record["elapsed_seconds"]) or record["elapsed_seconds"] <= 0):
                raise RuntimeError("invalid timing identity, measured graph or duration")
            validate_config(record["simulation_config"], contract, candidate, 100)
            if record.get("instrumentation_mode") != "none" or record.get("effective_environment") != expected_inactive_environment():
                raise RuntimeError("raw timing sample contains missing/active diagnostic controls")
            metadata = record["result_metadata"]
            if (metadata.get("method") != "matrix_product_state" or
                    metadata.get("device") != ("GPU" if candidate["backend"] == "custom_gpu" else "CPU") or
                    metadata.get("matrix_product_state_lapack") is not candidate["mps_lapack"] or
                    not 1 <= metadata.get("parallel_state_update", 1) <= 6):
                raise RuntimeError("observed simulator configuration differs from frozen candidate")
        if not warmup:
            samples = [record["elapsed_seconds"] for record in records]
    return samples


def validate_diagnostic_cell(directory, contract, contract_hash, candidate, single, compiled_hash, run_id):
    report = read(directory / "diagnostic_report.json")
    validate_report(report, contract, contract_hash, candidate, single["manifest_sha256"])
    validate_config(report["simulation_config"], contract, candidate, 100)
    if (candidate["backend"] != "custom_gpu" or report.get("instrumentation_mode") != "opt_in_recorder" or
            report.get("performance_claims_permitted") is not False or
            report.get("warmup_count") != 0 or report.get("timed_repetition_count") != 1):
        raise RuntimeError("invalid separate 0/1/100 GPU diagnostic")
    records = [json.loads(line) for line in (directory / "diagnostic_samples.jsonl").read_text().splitlines()]
    if len(records) != 1:
        raise RuntimeError("the measured-graph diagnostic must contain exactly one call")
    record = records[0]
    expected_environment = expected_inactive_environment()
    expected_environment["diagnostic_paths_enabled"]["AER_CUTENSOR_SVD_EVENTS_PATH"] = True
    if (record["is_warmup"] is not False or record["sample_index"] != 0 or record["run_id"] != run_id or
            record["circuit_id"] != single["circuits"][0]["id"] or record["backend"] != "custom_gpu" or
            record.get("compiled_qasm_sha256") != compiled_hash or
            record.get("instrumentation_mode") != "opt_in_recorder" or
            record.get("effective_environment") != expected_environment):
        raise RuntimeError("GPU diagnostic graph, identity or instrumentation mismatch")
    validate_config(record["simulation_config"], contract, candidate, 100)
    metadata = record["result_metadata"]
    if metadata.get("device") != "GPU" or metadata.get("matrix_product_state_lapack") is not candidate["mps_lapack"]:
        raise RuntimeError("diagnostic did not execute the selected GPU configuration")
    event_path = directory / "svd_events" / f"{single['circuits'][0]['id']}.events.jsonl"
    cells = report.get("offload_cells", [])
    if not event_path.exists():
        if cells:
            raise RuntimeError("offload report claims a missing event file")
        return False
    events = [json.loads(line) for line in event_path.read_text().splitlines()]
    if (not events or len(cells) != 1 or cells[0]["events_sha256"] != digest(event_path) or
            cells[0]["cutensor_csvd_wrapper_calls"] != len(events) or
            any(event.get("event") != "cutensor_csvd_wrapper" or
                any(type(event.get(key)) is not int or event[key] < 1 for key in ("rows", "columns")) for event in events)):
        raise RuntimeError("invalid successful-SVD event proof for the measured graph")
    return True


def run_diagnostics(run_dir, contract, manifest, compiled):
    gpu, errors = roles(contract)["gpu"], []
    for spec in manifest["circuits"]:
        if not launch(run_dir, contract, gpu, spec["id"], "diagnostic", compiled_hash=compiled[spec["id"]]):
            errors.append({"input_id": spec["id"], "reason": "measured-graph diagnostic child failed"})
    write_new(run_dir / "diagnostic_gate.json", {"status": "FAIL" if errors else "PASS",
        "contract_sha256": digest(run_dir / "contract.json"), "errors": errors,
        "scope": "one separate exact-measured-graph 100-shot diagnostic per input; no-offload is retained"})
    if errors:
        raise RuntimeError("measured-graph diagnostics failed; no timing launched")


def validate_diagnostic_archive(run_dir, contract, manifest, compiled):
    gate = read(run_dir / "diagnostic_gate.json")
    bound_hash, gpu = digest(run_dir / "contract.json"), roles(contract)["gpu"]
    if gate.get("status") != "PASS" or gate.get("contract_sha256") != bound_hash or gate.get("errors"):
        raise RuntimeError("separate measured-graph diagnostic gate did not pass")
    observations = {}
    for spec in manifest["circuits"]:
        directory = run_dir / "diagnostic" / spec["id"] / gpu["id"]
        observations[spec["id"]] = validate_diagnostic_cell(directory, contract, bound_hash, gpu,
            checked_single_manifest(run_dir, spec["id"], manifest), compiled[spec["id"]], run_dir.name)
        if read(directory / "process_exit.json").get("status") != "PASS":
            raise RuntimeError("failed diagnostic process cannot establish offload outcome")
    return observations


def execute_child(task_path):
    task = read(task_path)
    run_dir, destination = Path(task["run_dir"]), Path(task["destination"])
    try:
        if any(key in os.environ for key in LOADER_INJECTION_KEYS):
            raise RuntimeError("launch a fresh child without LD_PRELOAD or LD_AUDIT")
        contract, manifest = verify_archive(run_dir)
        contract_hash = digest(run_dir / "contract.json")
        if contract_hash != task["contract_sha256"]:
            raise RuntimeError("contract changed after child dispatch")
        candidate = next(c for c in contract["candidates"] if c["id"] == task["candidate"])
        verify_candidate(candidate)
        single = checked_single_manifest(run_dir, task["input_id"], manifest)
        os.sched_setaffinity(0, contract["cpu_affinity"])
        if sorted(os.sched_getaffinity(0)) != sorted(contract["cpu_affinity"]):
            raise RuntimeError("could not establish frozen CPU affinity")
        if task["mode"] == "correctness":
            from run_e2_numerical_correctness_pilot import run_pilot
            events = destination / "gpu_svd.events.jsonl" if candidate["backend"] == "custom_gpu" else None
            report = run_pilot(single, candidate["backend"], 1024, 0.0, contract["seed_transpiler"], events,
                offload_required=False, mps_lapack=candidate["mps_lapack"], dispatch_threshold=8401,
                validate_svd_result=True, circuit_builder=build_scientific_circuit)
            report.update({"runtime": paired_runtime_state(candidate), "contract_sha256": contract_hash,
                           "candidate_id": candidate["id"], "manifest_sha256": single["manifest_sha256"],
                           "offload_evidence_scope": "E2 correctness execution including state extraction; not a timed GPU-call trace"})
            write_new(destination / "correctness.json", report)
            validate_correctness(report, contract, contract_hash, candidate, single, destination)
        else:
            from run_e3_timing_cell import execute_cell
            runtime = []

            def checkpoint(record):
                if not runtime:
                    runtime.append(paired_runtime_state(candidate))
                filename = ("diagnostic_samples.jsonl" if task["mode"] == "diagnostic" else
                            "warmups.jsonl" if record["is_warmup"] else "timings.jsonl")
                with (destination / filename).open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")

            diagnostic = task["mode"] == "diagnostic"
            _, records, report = execute_cell(manifest=single, backend=candidate["backend"], run_id=run_dir.name,
                warmups=0 if diagnostic else 5, timed_repetitions=1 if diagnostic else 20,
                shots=100, max_bond_dimension=1024, truncation_threshold=0.0,
                seed_simulator=contract["seed_simulator"], seed_transpiler=contract["seed_transpiler"],
                events_dir=destination / "svd_events" if diagnostic else None,
                dispatch_threshold=8401, mps_lapack=candidate["mps_lapack"],
                expected_compiled_hashes={task["input_id"]: task["compiled_qasm_sha256"]},
                allow_uninstrumented_gpu_timing=True, cell_wall_time_seconds=contract["cell_wall_time_seconds"],
                progress_callback=checkpoint, circuit_builder=build_scientific_circuit)
            report.update({"runtime": runtime[0], "contract_sha256": contract_hash, "candidate_id": candidate["id"]})
            if diagnostic:
                report["performance_claims_permitted"] = False
                report["offload_evidence_scope"] = "one separate 100-shot execution of the exact compiled measured graph"
                write_new(destination / "diagnostic_report.json", report)
                validate_diagnostic_cell(destination, contract, contract_hash, candidate, single,
                                          task["compiled_qasm_sha256"], run_dir.name)
            else:
                write_new(destination / "timing_report.json", report)
                validate_timing_cell(destination, contract, contract_hash, candidate, single,
                                     task["compiled_qasm_sha256"], run_dir.name)
    except Exception as error:
        if not (destination / "failure.json").exists():
            write_new(destination / "failure.json", {"status": "FAIL", "error": str(error),
                "exception": type(error).__name__, "mode": task["mode"], "at_utc": utc_stamp()})
        raise


def launch(run_dir, contract, candidate, input_id, mode, session=None, compiled_hash=None):
    directory = run_dir / (mode if mode in {"correctness", "diagnostic"} else f"timing/session_{session}") / input_id / candidate["id"]
    directory.mkdir(parents=True, exist_ok=False)
    task = {"run_dir": str(run_dir.resolve()), "destination": str(directory.resolve()),
            "contract_sha256": digest(run_dir / "contract.json"), "candidate": candidate["id"],
            "input_id": input_id, "mode": mode, "session": session, "compiled_qasm_sha256": compiled_hash}
    write_new(directory / "task.json", task)
    environment, cleared_loader_keys = paired_environment(candidate)
    outcome = {"started_utc": utc_stamp(), "loader_injection_keys_cleared_before_exec": cleared_loader_keys}
    print(f"[P2] {mode} session={session} {input_id} {candidate['id']}", flush=True)
    with (directory / "process.log").open("x", encoding="utf-8") as log:
        try:
            completed = subprocess.run([candidate["python"], str(run_dir / "runner_snapshot" / Path(__file__).name),
                                       "--cell-task", str(directory / "task.json")],
                env=environment, stdout=log, stderr=subprocess.STDOUT,
                timeout=contract["cell_wall_time_seconds"] + 120)
            outcome.update({"status": "PASS" if completed.returncode == 0 else "FAIL", "exit_code": completed.returncode})
        except subprocess.TimeoutExpired:
            outcome.update({"status": "FAIL", "exit_code": None, "error": "process wall-time cap exceeded"})
        except OSError as error:
            outcome.update({"status": "FAIL", "exit_code": None, "error": str(error)})
    outcome["finished_utc"] = utc_stamp()
    write_new(directory / "process_exit.json", outcome)
    return outcome["status"] == "PASS"


def run_correctness(run_dir, contract, manifest):
    errors, compiled = [], {}
    for spec in manifest["circuits"]:
        input_hashes = []
        for candidate in contract["candidates"]:
            if not launch(run_dir, contract, candidate, spec["id"], "correctness"):
                errors.append({"input_id": spec["id"], "candidate": candidate["id"], "reason": "child failed"})
                continue
            try:
                evidence_dir = run_dir / "correctness" / spec["id"] / candidate["id"]
                report = read(evidence_dir / "correctness.json")
                input_hashes.append(validate_correctness(report, contract, digest(run_dir / "contract.json"), candidate,
                                     checked_single_manifest(run_dir, spec["id"], manifest), evidence_dir))
            except (OSError, ValueError, KeyError, RuntimeError) as error:
                errors.append({"input_id": spec["id"], "candidate": candidate["id"], "reason": str(error)})
        if len(input_hashes) != len(contract["candidates"]) or len(set(input_hashes)) != 1:
            errors.append({"input_id": spec["id"], "reason": "all configurations did not establish one measured graph"})
        else:
            compiled[spec["id"]] = input_hashes[0]
    write_new(run_dir / "correctness_gate.json", {"status": "FAIL" if errors else "PASS",
        "contract_sha256": digest(run_dir / "contract.json"), "errors": errors,
        "policy": "all inputs/configurations checked before timing; any failure halts the campaign"})
    if errors:
        raise RuntimeError("correctness/graph gates failed; all available failures retained and no timing launched")
    write_new(run_dir / "compiled_hashes.json", compiled)


def validate_correctness_archive(run_dir, contract, manifest):
    gate = read(run_dir / "correctness_gate.json")
    bound_hash = digest(run_dir / "contract.json")
    if gate.get("status") != "PASS" or gate.get("contract_sha256") != bound_hash or gate.get("errors"):
        raise RuntimeError("campaign correctness gate did not pass")
    compiled = read(run_dir / "compiled_hashes.json")
    if set(compiled) != {spec["id"] for spec in manifest["circuits"]}:
        raise RuntimeError("measured-graph inventory differs from frozen inputs")
    for spec in manifest["circuits"]:
        single = checked_single_manifest(run_dir, spec["id"], manifest)
        for candidate in contract["candidates"]:
            evidence_dir = run_dir / "correctness" / spec["id"] / candidate["id"]
            report = read(evidence_dir / "correctness.json")
            if validate_correctness(report, contract, bound_hash, candidate, single, evidence_dir) != compiled[spec["id"]]:
                raise RuntimeError("correctness compiled graph differs from common timing graph")
    return compiled


def session_gap_remaining(completion, now, minimum_gap):
    ended = datetime.fromisoformat(completion["finished_utc"])
    if ended.tzinfo is None or now.tzinfo is None:
        raise RuntimeError("session timestamps must include time zones")
    return max(0.0, minimum_gap - (now - ended).total_seconds())


def wait_for_session_gap(completion, minimum_gap, wait):
    while True:
        remaining = session_gap_remaining(completion, datetime.now(timezone.utc), minimum_gap)
        if remaining <= 0:
            return
        if not wait:
            raise RuntimeError(f"session 1 is not ready: {remaining:.1f} seconds remain; resume explicitly later")
        print(f"[P2] inter-session gap: {remaining:.0f} seconds remain", flush=True)
        time.sleep(min(30.0, remaining))


def checkpoint_session(run_dir, contract, manifest, session, started):
    compiled = validate_correctness_archive(run_dir, contract, manifest)
    for spec in manifest["circuits"]:
        single = checked_single_manifest(run_dir, spec["id"], manifest)
        for candidate in contract["candidates"]:
            directory = run_dir / "timing" / f"session_{session}" / spec["id"] / candidate["id"]
            validate_timing_cell(directory, contract, digest(run_dir / "contract.json"), candidate, single,
                                 compiled[spec["id"]], run_dir.name)
            if read(directory / "process_exit.json").get("status") != "PASS":
                raise RuntimeError("failed process cannot enter a completed session")
    files = sorted(path for path in (run_dir / "timing" / f"session_{session}").rglob("*") if path.is_file())
    write_new(run_dir / f"session_{session}.complete.json", {"status": "PASS", "session": session,
        "started_utc": started, "finished_utc": utc_stamp(), "contract_sha256": digest(run_dir / "contract.json"),
        "files_sha256": {str(path.relative_to(run_dir)): digest(path) for path in files}})


def validate_session_checkpoint(run_dir, session):
    checkpoint = read(run_dir / f"session_{session}.complete.json")
    if (checkpoint.get("status") != "PASS" or checkpoint.get("session") != session or
            checkpoint.get("contract_sha256") != digest(run_dir / "contract.json")):
        raise RuntimeError("session checkpoint is not bound to the current contract")
    actual_files = {str(path.relative_to(run_dir)) for path in (run_dir / "timing" / f"session_{session}").rglob("*") if path.is_file()}
    if set(checkpoint["files_sha256"]) != actual_files:
        raise RuntimeError("completed session file inventory changed")
    for name, expected in checkpoint["files_sha256"].items():
        path = (run_dir / name).resolve()
        if run_dir.resolve() not in path.parents or digest(path) != expected:
            raise RuntimeError("completed session evidence changed")
    contract = read(run_dir / "contract.json")
    start = read(run_dir / f"session_{session}.started.json")
    if start["started_utc"] != checkpoint["started_utc"] or start["contract_sha256"] != checkpoint["contract_sha256"]:
        raise RuntimeError("session start/checkpoint binding differs")
    previous = datetime.fromisoformat(checkpoint["started_utc"])
    if previous.tzinfo is None:
        raise RuntimeError("session start timestamp lacks time zone")
    schedule = contract["sessions"][session]
    for input_id in schedule["input_order"]:
        for candidate_id in schedule["candidate_orders"][input_id]:
            directory = run_dir / "timing" / f"session_{session}" / input_id / candidate_id
            task, outcome = read(directory / "task.json"), read(directory / "process_exit.json")
            began, ended = map(datetime.fromisoformat, (outcome["started_utc"], outcome["finished_utc"]))
            if (task["mode"] != "timing" or task["session"] != session or task["input_id"] != input_id or
                    task["candidate"] != candidate_id or task["contract_sha256"] != checkpoint["contract_sha256"] or
                    outcome.get("status") != "PASS" or outcome.get("exit_code") != 0 or
                    began.tzinfo is None or ended.tzinfo is None or began < previous or ended < began):
                raise RuntimeError("recorded child order/status differs from frozen session schedule")
            previous = ended
    finished = datetime.fromisoformat(checkpoint["finished_utc"])
    if finished.tzinfo is None or finished < previous:
        raise RuntimeError("session checkpoint predates its final child")
    return checkpoint


def run_session(run_dir, session, wait_for_gap=False):
    contract, manifest = verify_archive(run_dir)
    if (run_dir / "campaign_failure.json").exists():
        raise RuntimeError("failed campaigns cannot be resumed in place")
    if session >= len(contract["sessions"]):
        raise RuntimeError("session is not part of this contract")
    if (run_dir / f"session_{session}.started.json").exists():
        raise RuntimeError("session already started; partial cells cannot be rerun in place")
    if session == 1:
        completed = validate_session_checkpoint(run_dir, 0)
        wait_for_session_gap(completed, contract["minimum_session_gap_seconds"], wait_for_gap)
    started = utc_stamp()
    write_new(run_dir / f"session_{session}.started.json", {"started_utc": started, "contract_sha256": digest(run_dir / "contract.json")})
    try:
        if session == 0:
            run_correctness(run_dir, contract, manifest)
        compiled = validate_correctness_archive(run_dir, contract, manifest)
        if session == 0:
            run_diagnostics(run_dir, contract, manifest, compiled)
        validate_diagnostic_archive(run_dir, contract, manifest, compiled)
        candidates = {c["id"]: c for c in contract["candidates"]}
        schedule = contract["sessions"][session]
        for input_id in schedule["input_order"]:
            for candidate_id in schedule["candidate_orders"][input_id]:
                if not launch(run_dir, contract, candidates[candidate_id], input_id, "timing", session, compiled[input_id]):
                    raise RuntimeError("timing child failed; partial samples preserved and campaign halted")
        checkpoint_session(run_dir, contract, manifest, session, started)
        if session + 1 == len(contract["sessions"]):
            result = summarize(run_dir)
            write_new(run_dir / "analysis.json", result)
            if contract["stage"] == "P2_PILOT":
                write_new(run_dir / "sample_size_plan.json", result["sample_size_plan"])
            print("PASS: all frozen P2 sessions completed", flush=True)
        else:
            print("PAUSED: session 0 complete; resume session 1 explicitly after the frozen 30-minute gap", flush=True)
    except Exception as error:
        if not (run_dir / "campaign_failure.json").exists():
            write_new(run_dir / "campaign_failure.json", {"status": "FAIL", "session": session,
                "error": str(error), "at_utc": utc_stamp(), "partial_evidence_retained": True})
        raise


def summarize(run_dir):
    from scientific_campaign_statistics import analyze_campaign_contrast, plan_primary_sample_size
    contract, manifest = verify_archive(run_dir)
    compiled = validate_correctness_archive(run_dir, contract, manifest)
    offload_observations = validate_diagnostic_archive(run_dir, contract, manifest, compiled)
    bound_hash, by_role = digest(run_dir / "contract.json"), roles(contract)
    blocks = tuple(range(1, len(contract["sessions"]) + 1))
    completions = [validate_session_checkpoint(run_dir, block - 1) for block in blocks]
    if len(completions) == 2:
        if session_gap_remaining(completions[0], datetime.fromisoformat(completions[1]["started_utc"]), 1800) > 0:
            raise RuntimeError("recorded sessions violate the frozen minimum gap")
    contrasted_cpus = [by_role["selected_cpu"]] + ([by_role["internal_cpu"]] if "internal_cpu" in by_role else [])
    collected = {candidate["id"]: [] for candidate in contrasted_cpus}
    for spec in manifest["circuits"]:
        single = checked_single_manifest(run_dir, spec["id"], manifest)
        offload = offload_observations[spec["id"]]
        for block in blocks:
            timings = {}
            for candidate in contract["candidates"]:
                directory = run_dir / "timing" / f"session_{block-1}" / spec["id"] / candidate["id"]
                timings[candidate["id"]] = validate_timing_cell(directory, contract, bound_hash, candidate, single,
                                                                compiled[spec["id"]], run_dir.name)
            for cpu in contrasted_cpus:
                collected[cpu["id"]].append({"workload": workload(spec), "input_id": spec["id"], "block_id": block,
                    "cpu_candidate": cpu["id"], "gpu_candidate": by_role["gpu"]["id"],
                    "cpu_seconds": timings[cpu["id"]], "gpu_seconds": timings[by_role["gpu"]["id"]],
                    "offload_observed": offload})
    scopes = sorted({workload(spec) for spec in manifest["circuits"]})
    analyses = []
    for cpu in contrasted_cpus if contract["stage"] == "P2_CONFIRMATION" else []:
        for scope in scopes:
            expected = [spec["id"] for spec in manifest["circuits"] if workload(spec) == scope]
            rows = [row for row in collected[cpu["id"]] if row["workload"] == scope]
            role = ("internal_control" if cpu["id"] != by_role["selected_cpu"]["id"] else
                    "primary" if scope == "BW-16" else "secondary")
            analyses.append(analyze_campaign_contrast(rows, workload=scope, cpu_candidate=cpu["id"],
                gpu_candidate=by_role["gpu"]["id"], selected_cpu_candidate=by_role["selected_cpu"]["id"],
                expected_input_ids=expected, expected_blocks=blocks, role=role,
                bootstrap_seed=contract["bootstrap_seed"]))
    result = {"schema_version": 1, "stage": contract["stage"], "status": "PASS", "contract_sha256": bound_hash,
              "analyses": analyses, "paired_input_records": collected,
              "scope": "configuration-level paired timings; whole independent input is the inference unit",
              "offload_evidence_scope": "separate one-run 100-shot diagnostics of the exact compiled measured graph; instrumentation absent from timed calls"}
    if contract["stage"] == "P2_PILOT":
        expected = [spec["id"] for spec in manifest["circuits"] if workload(spec) == "BW-16"]
        rows = [row for row in collected[by_role["selected_cpu"]["id"]] if row["workload"] == "BW-16"]
        result["sample_size_plan"] = plan_primary_sample_size(rows, expected_input_ids=expected,
            cpu_candidate=by_role["selected_cpu"]["id"], gpu_candidate=by_role["gpu"]["id"], pilot_block=1)
    return result


def archived_entry(run_dir, arguments):
    # Bootstrap checks only bytes with stdlib helpers. Semantic validation must
    # run inside the snapshot so later E2/E3/input changes cannot invalidate it.
    contract = read(run_dir / "contract.json")
    registry = read(run_dir / "runner_snapshot.json")
    if registry != {"schema_version": 1, "files_sha256": contract["runner_sha256"]}:
        raise RuntimeError("archived runner registry changed")
    for name, expected in contract["runner_sha256"].items():
        if Path(name).name != name or digest(run_dir / "runner_snapshot" / name) != expected:
            raise RuntimeError("archived runner bytes changed")
    entry = run_dir / "runner_snapshot" / Path(__file__).name
    return subprocess.call([sys.executable, str(entry), "--run-dir", str(run_dir), *arguments])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path)
    parser.add_argument("--prepare-contract", type=Path, metavar="NEW_JSON")
    parser.add_argument("--p1-run-dir", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--pilot-run-dir", type=Path)
    parser.add_argument("--order-seed", type=int)
    parser.add_argument("--bootstrap-seed", type=int, default=20260907)
    parser.add_argument("--cell-wall-time-seconds", type=float, default=3600)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--cell-task", type=Path)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--wait-for-gap", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--run-session-zero", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        if args.prepare_contract:
            if args.p1_run_dir is None or args.manifest is None or args.order_seed is None:
                parser.error("--prepare-contract requires --p1-run-dir, --manifest and --order-seed")
            if args.contract or args.run_dir or args.resume or args.validate_only or args.cell_task:
                parser.error("contract preparation is a separate read-only validation stage")
            contract = prepare_contract(args.p1_run_dir, args.manifest, order_seed=args.order_seed,
                bootstrap_seed=args.bootstrap_seed, cell_wall_time_seconds=args.cell_wall_time_seconds,
                pilot_run_dir=args.pilot_run_dir)
            write_new(args.prepare_contract.resolve(), contract)
            print(f"PREPARED: {args.prepare_contract.resolve()}; no P2 execution launched")
            return 0
        if args.cell_task:
            execute_child(args.cell_task.resolve())
            return 0
        if args.run_dir is None:
            parser.error("--run-dir is required")
        run_dir = args.run_dir.resolve()
        if args.contract:
            if args.resume or args.validate_only or args.run_session_zero:
                parser.error("--contract starts a new run only")
            freeze_campaign(args.contract.resolve(), run_dir)
            return archived_entry(run_dir, ["--run-session-zero"])
        forwarded = (["--validate-only"] if args.validate_only else ["--resume"] if args.resume else ["--run-session-zero"])
        if args.wait_for_gap:
            forwarded.append("--wait-for-gap")
        if HERE != run_dir / "runner_snapshot":
            return archived_entry(run_dir, forwarded)
        if args.validate_only:
            print(json.dumps(summarize(run_dir), indent=2))
        else:
            run_session(run_dir, 1 if args.resume else 0, args.wait_for_gap)
        return 0
    except Exception as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
