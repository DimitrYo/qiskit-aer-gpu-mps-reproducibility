"""Prepare a fresh MPS child without inheriting research instrumentation.

Only known execution controls are inspected. Reports contain key names and
effective booleans/numeric settings, never inherited paths or arbitrary values.
"""

from __future__ import annotations

import os
import sys
from collections.abc import Mapping


DIAGNOSTIC_PATH_KEYS = (
    "AER_CUTENSOR_SVD_EVENTS_PATH",
    "AER_CUTENSOR_SVD_PROFILE_PATH",
    "AER_CUTENSOR_SVD_DECISIONS_PATH",
    "AER_CUBLAS_EVENTS_PATH",
    "AER_CPU_LAPACK_PROFILE_PATH",
)
RECONSTRUCTION_KEYS = (
    "AER_CUTENSOR_SVD_VALIDATE_RESULT",
    "AER_MPS_SVD_VALIDATE_RESULT",
)
DIAGNOSTIC_KEYS = DIAGNOSTIC_PATH_KEYS + RECONSTRUCTION_KEYS
DISPATCH_THRESHOLD_KEY = "AER_CUTENSOR_SVD_MIN_ELEMENTS"
DEFAULT_DISPATCH_THRESHOLD = 8401
LOADER_INJECTION_KEYS = ("LD_PRELOAD", "LD_AUDIT")


def assert_loader_environment(expected: Mapping[str, str] | None = None) -> None:
    """A loader hook cannot be undone by deleting its variable after startup.

    Ordinary correctness/timing children must start without loader injection.
    A separate verified diagnostic may explicitly bind the exact preload value.
    Never include an inherited path/value in the error or ordinary report.
    """
    expected = dict(expected or {})
    if set(expected) - set(LOADER_INJECTION_KEYS):
        raise RuntimeError("unknown loader control")
    actual = {key: os.environ[key] for key in LOADER_INJECTION_KEYS if key in os.environ}
    if actual != expected:
        raise RuntimeError("unexpected loader injection; launch a fresh child without LD_PRELOAD/LD_AUDIT")


def prepare_mps_environment(*, dispatch_threshold: int | None = None,
                            validate_svd_result: bool = False,
                            expected_loader_environment: Mapping[str, str] | None = None) -> dict[str, object]:
    """Reset inherited controls before Aer can cache its dispatch threshold.

    Diagnostic callers re-enable only explicitly requested recorders afterward.
    Reconstruction validation is an explicit correctness-only opt-in; timing
    callers must leave it false. A second call after importing Aer is refused
    because changing the environment cannot reset native cached configuration.
    """
    if "qiskit_aer" in sys.modules:
        raise RuntimeError("MPS execution requires a fresh child before importing qiskit_aer")
    assert_loader_environment(expected_loader_environment)
    if dispatch_threshold is not None and (
            type(dispatch_threshold) is not int or not 1 <= dispatch_threshold <= (1 << 64) - 1):
        raise RuntimeError("MPS dispatch threshold must be a positive integer representable as uint64")
    if type(validate_svd_result) is not bool:
        raise RuntimeError("validate_svd_result must be boolean")
    inherited = sorted(key for key in DIAGNOSTIC_KEYS if key in os.environ)
    inherited_threshold = DISPATCH_THRESHOLD_KEY in os.environ
    for key in DIAGNOSTIC_KEYS:
        os.environ.pop(key, None)
    effective_threshold = (
        DEFAULT_DISPATCH_THRESHOLD if dispatch_threshold is None else dispatch_threshold
    )
    os.environ[DISPATCH_THRESHOLD_KEY] = str(effective_threshold)
    if validate_svd_result:
        for key in RECONSTRUCTION_KEYS:
            os.environ[key] = "1"
    return {
        "policy": "reset_known_controls_before_aer_import",
        "inherited_diagnostic_keys_cleared": inherited,
        "inherited_dispatch_override_replaced": inherited_threshold,
        "dispatch_threshold_source": "runner_default" if dispatch_threshold is None else "explicit_argument",
        "dispatch_threshold_elements": effective_threshold,
        "pre_import_effective_state": execution_environment_state(),
    }


def execution_environment_state() -> dict[str, object]:
    """Report the activation semantics actually used by the native helpers."""
    raw_threshold = os.environ.get(DISPATCH_THRESHOLD_KEY, "")
    threshold = int(raw_threshold) if raw_threshold.isdecimal() else None
    return {
        "diagnostic_paths_enabled": {key: bool(os.environ.get(key)) for key in DIAGNOSTIC_PATH_KEYS},
        "reconstruction_checks_enabled": {key: os.environ.get(key) == "1" for key in RECONSTRUCTION_KEYS},
        "dispatch_threshold_elements": threshold,
    }


def assert_execution_environment(*, dispatch_threshold: int,
                                 diagnostic_paths: Mapping[str, str] | None = None,
                                 validate_svd_result: bool = False,
                                 expected_loader_environment: Mapping[str, str] | None = None) -> dict[str, object]:
    """Fail before execution if code between setup and run changed a control."""
    assert_loader_environment(expected_loader_environment)
    expected_paths = diagnostic_paths or {}
    if set(expected_paths) - set(DIAGNOSTIC_PATH_KEYS):
        raise RuntimeError("unknown MPS diagnostic path control")
    changed = [key for key in DIAGNOSTIC_PATH_KEYS
               if os.environ.get(key) != expected_paths.get(key)]
    changed.extend(key for key in RECONSTRUCTION_KEYS
                   if os.environ.get(key) != ("1" if validate_svd_result else None))
    if os.environ.get(DISPATCH_THRESHOLD_KEY) != str(dispatch_threshold):
        changed.append(DISPATCH_THRESHOLD_KEY)
    if changed:
        raise RuntimeError("MPS execution environment changed after setup: " + ", ".join(changed))
    return execution_environment_state()
