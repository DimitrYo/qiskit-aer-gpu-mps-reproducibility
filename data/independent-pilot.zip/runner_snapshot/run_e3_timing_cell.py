#!/usr/bin/env python3
"""Collect one isolated, run-scoped Article 2 MPS timing cell.

This process is intentionally invoked by exactly one selected environment.  It
never imports a second environment, never obtains a statevector, and never
computes a speed-up.  The companion executor owns cross-environment process
selection and combines these immutable per-cell files only after every cell
has succeeded.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Callable

from mps_execution_environment import (
    DEFAULT_DISPATCH_THRESHOLD,
    assert_execution_environment,
    prepare_mps_environment,
)
from run_e2_numerical_correctness_pilot import (
    DEFAULT_MANIFEST,
    assert_backend_provenance,
    build_circuit,
    load_manifest,
    qasm_sha256,
)

DEFAULT_WARMUPS = 5
DEFAULT_TIMED_REPETITIONS = 20
DEFAULT_SHOTS = 100


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_jsonl_new(path: Path, records: list[dict[str, object]]) -> None:
    """Write a new evidence file; replacing prior evidence is prohibited."""
    if path.exists():
        raise RuntimeError(f"refusing to overwrite existing evidence: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(record, sort_keys=True) + "\n" for record in records), encoding="utf-8")


def configure_backend(backend: str, events_dir: Path | None, profile_dir: Path | None,
                      decisions_dir: Path | None, dispatch_threshold: int | None,
                      allow_uninstrumented_gpu_timing: bool) -> tuple[str, Path | None, Path | None, Path | None]:
    if backend != "custom_gpu":
        if any(path is not None for path in (events_dir, profile_dir, decisions_dir)):
            raise RuntimeError("explicit recorder directories require the custom_gpu diagnostic mode")
        return "CPU", None, None, None
    if events_dir is None and not allow_uninstrumented_gpu_timing:
        raise RuntimeError("custom_gpu requires --events-dir for per-circuit cuTensorNet event evidence")
    if dispatch_threshold is not None and dispatch_threshold < 1:
        raise RuntimeError("custom_gpu dispatch threshold must be positive")
    if events_dir is not None:
        events_dir.mkdir(parents=True, exist_ok=True)
    if profile_dir is not None:
        profile_dir.mkdir(parents=True, exist_ok=True)
    if decisions_dir is not None:
        decisions_dir.mkdir(parents=True, exist_ok=True)
    os.environ["AER_ENABLE_CUTENSORNET"] = "1"
    os.environ["AER_THRUST_BACKEND"] = "CUDA"
    os.environ["AER_CUTENSOR_SVD_MIN_ELEMENTS"] = str(
        DEFAULT_DISPATCH_THRESHOLD if dispatch_threshold is None else dispatch_threshold)
    return "GPU", events_dir, profile_dir, decisions_dir


def read_events(path: Path) -> tuple[int, str]:
    if not path.is_file():
        raise RuntimeError(f"custom_gpu did not create cuTensorNet event log: {path}")
    count = len(path.read_text(encoding="utf-8").splitlines())
    if count < 1:
        raise RuntimeError(f"custom_gpu created an empty cuTensorNet event log: {path}")
    return count, sha256_file(path)


def execute_cell(*, manifest: dict[str, object], backend: str, run_id: str,
                 warmups: int, timed_repetitions: int, shots: int,
                 max_bond_dimension: int, truncation_threshold: float,
                 seed_simulator: int, seed_transpiler: int,
                 events_dir: Path | None, profile_dir: Path | None = None,
                 decisions_dir: Path | None = None,
                 dispatch_threshold: int | None = None,
                 mps_lapack: bool = False,
                 circuit_builder: Callable[[dict[str, object]], object] | None = None,
                 expected_compiled_hashes: dict[str, str] | None = None,
                 allow_uninstrumented_gpu_timing: bool = False,
                 cell_wall_time_seconds: float | None = None,
                 progress_callback: Callable[[dict[str, object]], None] | None = None) -> tuple[list[dict[str, object]], list[dict[str, object]], dict[str, object]]:
    """Execute frozen circuits with one Aer import and return raw records.

    Transpilation is deliberately outside sample timing.  The timed interval is
    ``AerSimulator.run(...).result()`` only; this avoids timing host-side
    circuit construction or state extraction and keeps every sample comparable.
    """
    if type(mps_lapack) is not bool:
        raise RuntimeError("mps_lapack must be boolean")
    environment_policy = prepare_mps_environment(dispatch_threshold=dispatch_threshold)
    effective_threshold = int(environment_policy["dispatch_threshold_elements"])
    device, events_dir, profile_dir, decisions_dir = configure_backend(
        backend, events_dir, profile_dir, decisions_dir, dispatch_threshold,
        allow_uninstrumented_gpu_timing)
    import qiskit_aer
    from qiskit import transpile
    from qiskit_aer import AerSimulator

    aer_path = Path(qiskit_aer.__file__).resolve()
    assert_backend_provenance(backend, aer_path)
    simulator = AerSimulator(
        method="matrix_product_state", device=device, precision="double",
        mps_lapack=mps_lapack,
        matrix_product_state_max_bond_dimension=max_bond_dimension,
        matrix_product_state_truncation_threshold=truncation_threshold,
    )
    if device not in simulator.available_devices():
        raise RuntimeError(f"requested {device} is unavailable: {simulator.available_devices()}")
    if cell_wall_time_seconds is not None and cell_wall_time_seconds <= 0:
        raise RuntimeError("cell wall-time limit must be positive")

    config = {
        "method": "matrix_product_state", "device": device, "precision": "double", "shots": shots,
        "max_bond_dimension": max_bond_dimension,
        "truncation_threshold": truncation_threshold,
        "seed_simulator": seed_simulator, "seed_transpiler": seed_transpiler,
        "mps_lapack": mps_lapack,
    }
    warmup_records: list[dict[str, object]] = []
    timing_records: list[dict[str, object]] = []
    offload_cells: list[dict[str, object]] = []
    profile_cells: list[dict[str, object]] = []
    decision_cells: list[dict[str, object]] = []
    instrumentation_mode = (
        "opt_in_recorder" if any(path is not None for path in
                                 (events_dir, profile_dir, decisions_dir)) else "none"
    )
    effective_environment = assert_execution_environment(dispatch_threshold=effective_threshold)
    cell_started = time.perf_counter()
    circuits = manifest.get("circuits")
    assert isinstance(circuits, list)
    if expected_compiled_hashes is not None and set(expected_compiled_hashes) != {
            str(spec["id"]) for spec in circuits}:
        raise RuntimeError("expected compiled QASM hashes must cover exactly the selected circuits")
    for spec in circuits:
        assert isinstance(spec, dict)
        circuit_id = str(spec["id"])
        circuit_started = time.perf_counter()
        print(f"[TIMING-CELL] {backend} {circuit_id}: start", flush=True)
        # A frozen manifest may require offload for selected cells.  The
        # historical default remains brickwork=True so existing evidence keeps
        # its original contract; new sweeps make every expectation explicit.
        offload_required = bool(
            spec.get("offload_required", str(spec.get("kind")) == "brickwork")
        )
        circuit = (circuit_builder or build_circuit)(spec)
        if qasm_sha256(circuit) != spec.get("qasm_sha256"):
            raise RuntimeError(f"{circuit_id}: generated QASM hash differs from frozen manifest")
        # The frozen manifest describes the unitary workload.  A terminal
        # all-qubit measurement gives ``shots`` its ordinary sampling meaning
        # without changing that logical circuit or introducing state extraction
        # into the timed path.
        timing_circuit = circuit.copy()
        timing_circuit.measure_all()
        compiled = transpile(timing_circuit, simulator, optimization_level=0, seed_transpiler=seed_transpiler)
        compiled_hash = qasm_sha256(compiled)
        if (expected_compiled_hashes is not None and
                compiled_hash != expected_compiled_hashes[circuit_id]):
            raise RuntimeError(f"{circuit_id}: compiled QASM hash differs from the frozen timing graph")
        event_path: Path | None = None
        profile_path: Path | None = None
        decisions_path: Path | None = None
        diagnostic_paths: dict[str, str] = {}
        if backend == "custom_gpu":
            if events_dir is not None:
                event_path = events_dir / f"{circuit_id}.events.jsonl"
                if event_path.exists():
                    raise RuntimeError(f"refusing to overwrite event evidence: {event_path}")
                os.environ["AER_CUTENSOR_SVD_EVENTS_PATH"] = str(event_path.resolve())
                diagnostic_paths["AER_CUTENSOR_SVD_EVENTS_PATH"] = str(event_path.resolve())
            if profile_dir is not None:
                profile_path = profile_dir / f"{circuit_id}.profile.jsonl"
                if profile_path.exists():
                    raise RuntimeError(f"refusing to overwrite profile evidence: {profile_path}")
                os.environ["AER_CUTENSOR_SVD_PROFILE_PATH"] = str(profile_path.resolve())
                diagnostic_paths["AER_CUTENSOR_SVD_PROFILE_PATH"] = str(profile_path.resolve())
            if decisions_dir is not None:
                decisions_path = decisions_dir / f"{circuit_id}.decisions.jsonl"
                if decisions_path.exists():
                    raise RuntimeError(f"refusing to overwrite dispatch evidence: {decisions_path}")
                os.environ["AER_CUTENSOR_SVD_DECISIONS_PATH"] = str(decisions_path.resolve())
                diagnostic_paths["AER_CUTENSOR_SVD_DECISIONS_PATH"] = str(decisions_path.resolve())
        for index in range(warmups + timed_repetitions):
            # Setup and this integrity check are outside the elapsed interval.
            effective_environment = assert_execution_environment(
                dispatch_threshold=effective_threshold, diagnostic_paths=diagnostic_paths)
            started = time.perf_counter()
            result = simulator.run(compiled, shots=shots, seed_simulator=seed_simulator).result()
            elapsed = time.perf_counter() - started
            if not result.success:
                raise RuntimeError(f"{circuit_id}: Aer returned unsuccessful result: {result.status}")
            metadata = dict(result.results[0].metadata)
            if backend == "custom_gpu" and metadata.get("device") != "GPU":
                raise RuntimeError(f"{circuit_id}: custom_gpu result lacks GPU metadata: {metadata}")
            if metadata.get("matrix_product_state_lapack") is not mps_lapack:
                raise RuntimeError(f"{circuit_id}: result metadata does not confirm requested mps_lapack")
            record = {
                "run_id": run_id, "circuit_id": circuit_id, "backend": backend,
                "qasm_sha256": str(spec["qasm_sha256"]),
                "compiled_qasm_sha256": compiled_hash,
                "is_warmup": index < warmups,
                "sample_index": index if index < warmups else index - warmups,
                "elapsed_seconds": elapsed, "simulation_config": config,
                "result_metadata": metadata,
                "instrumentation_mode": instrumentation_mode,
                "effective_environment": effective_environment,
            }
            if backend == "custom_gpu":
                record["offload_required"] = offload_required
            (warmup_records if index < warmups else timing_records).append(record)
            if progress_callback is not None:
                # This callback is invoked after the timed interval. Its
                # diagnostic checkpoint cannot alter elapsed_seconds.
                progress_callback(record)
            if (cell_wall_time_seconds is not None and
                    time.perf_counter() - cell_started > cell_wall_time_seconds):
                raise RuntimeError(
                    f"{circuit_id}: cell exceeded declared wall-time limit "
                    f"of {cell_wall_time_seconds:.3f} seconds")
        if event_path is not None:
            if event_path.is_file():
                event_count, event_sha256 = read_events(event_path)
                offload_cells.append({
                    "circuit_id": circuit_id, "backend": "custom_gpu",
                    "cutensor_csvd_wrapper_calls": event_count,
                    "events_path": str(event_path.resolve()), "events_sha256": event_sha256,
                    "offload_required": offload_required,
                })
            elif offload_required:
                raise RuntimeError(f"{circuit_id}: offload-required custom_gpu cell did not create a cuTensorNet event log")
        if profile_path is not None and profile_path.is_file():
            profile_count, profile_sha256 = read_events(profile_path)
            profile_cells.append({
                "circuit_id": circuit_id, "backend": "custom_gpu",
                "profile_records": profile_count, "profile_path": str(profile_path.resolve()),
                "profile_sha256": profile_sha256,
            })
        elif offload_required and profile_dir is not None:
            raise RuntimeError(f"{circuit_id}: offload-required custom_gpu cell did not create a phase profile")
        if decisions_path is not None and decisions_path.is_file():
            decision_count, decision_sha256 = read_events(decisions_path)
            decision_cells.append({
                "circuit_id": circuit_id, "backend": "custom_gpu",
                "decision_records": decision_count, "decisions_path": str(decisions_path.resolve()),
                "decisions_sha256": decision_sha256,
            })
        print(
            f"[TIMING-CELL] {backend} {circuit_id}: complete "
            f"in {time.perf_counter() - circuit_started:.3f}s",
            flush=True,
        )
    report: dict[str, object] = {
        "schema_version": 1, "run_id": run_id, "backend": backend,
        "status": "PASS", "aer_path": str(aer_path),
        "manifest_sha256": manifest["manifest_sha256"], "simulation_config": config,
        "warmup_count": warmups, "timed_repetition_count": timed_repetitions,
        "offload_cells": offload_cells,
        "profile_cells": profile_cells,
        "decision_cells": decision_cells,
        "instrumentation_mode": instrumentation_mode,
        "environment_policy": environment_policy,
        "effective_environment": effective_environment,
        "dispatch_threshold_elements": effective_threshold,
        "cell_wall_time_seconds": cell_wall_time_seconds,
        "timing_scope": "AerSimulator.run(...).result(); transpilation and state extraction excluded",
        "statevector_extraction": False,
        "measurement_policy": "terminal_measure_all on a copy of the frozen measurement-free circuit",
        "compiled_qasm_scope": "terminal-measurement circuit after optimization_level=0 transpilation; hashed outside timer",
    }
    return warmup_records, timing_records, report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--backend", choices=("custom_gpu", "custom_cpu", "upstream_cpu"), required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--warmups-output", type=Path, required=True)
    parser.add_argument("--timings-output", type=Path, required=True)
    parser.add_argument("--report-output", type=Path, required=True)
    parser.add_argument("--events-dir", type=Path)
    parser.add_argument("--profile-dir", type=Path,
                        help="Optional custom-GPU cuTensorNet phase-profile directory.")
    parser.add_argument("--decisions-dir", type=Path,
                        help="Optional custom-GPU SVD-dispatch diagnostic directory.")
    parser.add_argument("--dispatch-threshold", type=int,
                        help="Positive AER_CUTENSOR_SVD_MIN_ELEMENTS override; default 8401."
                             " Inherited overrides are replaced before Aer import.")
    parser.add_argument("--mps-lapack", action=argparse.BooleanOptionalAction, default=False,
                        help="Explicit public Aer mps_lapack option; default false.")
    parser.add_argument("--allow-uninstrumented-gpu-timing", action="store_true",
                        help="Allow custom-GPU samples without event/profile recorder I/O."
                             " Intended only for a runner with a separate offload diagnostic.")
    parser.add_argument("--cell-wall-time-seconds", type=float,
                        help="Optional positive cap for the complete process/cell; partial files are preserved on timeout.")
    parser.add_argument("--warmups", type=int, default=DEFAULT_WARMUPS)
    parser.add_argument("--timed-repetitions", type=int, default=DEFAULT_TIMED_REPETITIONS)
    parser.add_argument("--shots", type=int, default=DEFAULT_SHOTS)
    parser.add_argument("--max-bond-dimension", type=int, default=128)
    parser.add_argument("--truncation-threshold", type=float, default=0.0)
    parser.add_argument("--seed-simulator", type=int, default=20260722)
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    args = parser.parse_args()
    try:
        if not args.run_id.replace("-", "").replace("_", "").replace(".", "").isalnum():
            raise RuntimeError("run_id may contain only letters, digits, dot, underscore, and hyphen")
        if min(args.warmups, args.timed_repetitions, args.shots) < 1:
            raise RuntimeError("warmups, timed repetitions, and shots must be positive")
        if args.max_bond_dimension < 2 or args.truncation_threshold < 0:
            raise RuntimeError("max bond dimension must be >= 2 and truncation threshold must be >= 0")
        if args.report_output.exists():
            raise RuntimeError(f"refusing to overwrite existing evidence: {args.report_output}")
        partial_warmups = args.warmups_output.with_name(args.warmups_output.name + ".partial")
        partial_timings = args.timings_output.with_name(args.timings_output.name + ".partial")
        if partial_warmups.exists() or partial_timings.exists():
            raise RuntimeError("refusing to overwrite partial evidence from an earlier failed cell")
        partial_warmups.parent.mkdir(parents=True, exist_ok=True)

        def checkpoint(record: dict[str, object]) -> None:
            destination = partial_warmups if record["is_warmup"] else partial_timings
            with destination.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record, sort_keys=True) + "\n")

        manifest = load_manifest(args.manifest)
        warmups, timings, report = execute_cell(
            manifest=manifest, backend=args.backend, run_id=args.run_id,
            warmups=args.warmups, timed_repetitions=args.timed_repetitions, shots=args.shots,
            max_bond_dimension=args.max_bond_dimension, truncation_threshold=args.truncation_threshold,
            seed_simulator=args.seed_simulator, seed_transpiler=args.seed_transpiler,
            events_dir=args.events_dir, profile_dir=args.profile_dir,
            decisions_dir=args.decisions_dir, dispatch_threshold=args.dispatch_threshold,
            mps_lapack=args.mps_lapack,
            allow_uninstrumented_gpu_timing=args.allow_uninstrumented_gpu_timing,
            cell_wall_time_seconds=args.cell_wall_time_seconds,
            progress_callback=checkpoint,
        )
        write_jsonl_new(args.warmups_output, warmups)
        write_jsonl_new(args.timings_output, timings)
        args.report_output.parent.mkdir(parents=True, exist_ok=True)
        args.report_output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        partial_warmups.unlink(missing_ok=True)
        partial_timings.unlink(missing_ok=True)
        print(f"PASS: wrote {len(warmups)} warm-ups and {len(timings)} timings for {args.backend}")
        return 0
    except RuntimeError as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
