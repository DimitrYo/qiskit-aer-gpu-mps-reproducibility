#!/usr/bin/env python3
"""Run the Article 2 E2 numerical-correctness pilot without collecting timings.

This is deliberately separate from the legacy benchmark runner.  It freezes
measurement-free circuit inputs, verifies their QASM fingerprints, compares
an MPS result against two exact statevector references, and writes a single
JSON report for one selected environment.  It performs no warm-ups, repeated
runs, timing aggregation, plotting, or speedup calculation.

Run this script once per backend/environment.  The intended E2 comparison is
``custom_gpu``, ``custom_cpu``, and ``upstream_cpu`` on the same manifest.
Only the custom-GPU invocation is required to use a GPU; the later canonical
executor will combine these reports into publication evidence after E3/L4.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
from pathlib import Path
from typing import Any, Callable

from mps_execution_environment import assert_execution_environment, prepare_mps_environment


TESTS_DIR = Path(__file__).resolve().parent
EXPERIMENTS_DIR = TESTS_DIR.parents[1]
CODE_DIR = EXPERIMENTS_DIR.parent
DEFAULT_LOCAL_PR_DIR = (CODE_DIR / "qiskit-aer-pr2168").resolve()
DEFAULT_MANIFEST = EXPERIMENTS_DIR / "manifests" / "e2_numerical_correctness_pilot.json"

REFERENCE_FIDELITY_MIN = 1.0 - 1.0e-12
MPS_FIDELITY_MIN = 1.0 - 1.0e-10
NORM_ERROR_MAX = 1.0e-10
SUPPORTED_CIRCUIT_KINDS = {
    "ghz", "qft_prepared", "brickwork", "qaoa_ring", "schmidt_pair",
    "variational_chain",
}


def canonical_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_json(value: object) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def expected_custom_source_dir() -> Path:
    """Return the selected custom Aer source, including an isolated worktree."""
    return Path(os.environ.get("ARTICLE2_CUSTOM_SOURCE_DIR", str(DEFAULT_LOCAL_PR_DIR))).resolve()


def recipe_payload(spec: dict[str, object]) -> dict[str, object]:
    return {key: value for key, value in spec.items() if key not in {"recipe_sha256", "qasm_sha256"}}


def manifest_payload(manifest: dict[str, object]) -> dict[str, object]:
    return {key: value for key, value in manifest.items() if key != "manifest_sha256"}


def validate_manifest_structure(manifest: dict[str, object], *, allow_pending: bool = False) -> list[str]:
    errors: list[str] = []
    if manifest.get("schema_version") != 1:
        errors.append("schema_version must be 1")
    circuits = manifest.get("circuits")
    if not isinstance(circuits, list) or not circuits:
        return errors + ["circuits must be a non-empty list"]
    ids: set[str] = set()
    for index, spec in enumerate(circuits):
        if not isinstance(spec, dict):
            errors.append(f"circuits[{index}] must be an object")
            continue
        circuit_id = spec.get("id")
        if not isinstance(circuit_id, str) or not circuit_id:
            errors.append(f"circuits[{index}].id must be a non-empty string")
        elif circuit_id in ids:
            errors.append(f"duplicate circuit id: {circuit_id}")
        else:
            ids.add(circuit_id)
        if spec.get("kind") not in SUPPORTED_CIRCUIT_KINDS:
            errors.append(f"{circuit_id}: unsupported kind")
        if not isinstance(spec.get("qubits"), int) or int(spec["qubits"]) < 1:
            errors.append(f"{circuit_id}: qubits must be an integer >= 1")
        if spec.get("kind") == "brickwork" and (not isinstance(spec.get("depth"), int) or int(spec["depth"]) < 1):
            errors.append(f"{circuit_id}: brickwork depth must be an integer >= 1")
        if spec.get("kind") in {"qaoa_ring", "variational_chain"} and (
                not isinstance(spec.get("layers"), int) or int(spec["layers"]) < 1):
            errors.append(f"{circuit_id}: layers must be an integer >= 1")
        if spec.get("kind") == "schmidt_pair" and (
                not isinstance(spec.get("tail_weight"), (int, float))
                or not 0.0 < float(spec["tail_weight"]) < 0.5):
            errors.append(f"{circuit_id}: tail_weight must be strictly between 0 and 0.5")
        if "offload_required" in spec and not isinstance(spec["offload_required"], bool):
            errors.append(f"{circuit_id}: offload_required must be boolean")
        for key, expected in (("recipe_sha256", sha256_json(recipe_payload(spec))),):
            actual = spec.get(key)
            if not allow_pending and actual != expected:
                errors.append(f"{circuit_id}: {key} does not match the frozen recipe")
    expected_manifest = sha256_json(manifest_payload(manifest))
    if not allow_pending and manifest.get("manifest_sha256") != expected_manifest:
        errors.append("manifest_sha256 does not match the frozen manifest")
    return errors


def load_manifest(path: Path, *, allow_pending: bool = False) -> dict[str, object]:
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(f"cannot read manifest {path}: {error}") from error
    if not isinstance(manifest, dict):
        raise RuntimeError("manifest root must be a JSON object")
    errors = validate_manifest_structure(manifest, allow_pending=allow_pending)
    if errors:
        raise RuntimeError("invalid frozen manifest: " + "; ".join(errors))
    return manifest


def build_circuit(spec: dict[str, object]):
    """Build a deterministic, measurement-free circuit from one frozen recipe."""
    from qiskit import QuantumCircuit

    qubits = int(spec["qubits"])
    kind = str(spec["kind"])
    circuit = QuantumCircuit(qubits, name=str(spec["id"]))
    if kind == "ghz":
        circuit.h(0)
        for qubit in range(qubits - 1):
            circuit.cx(qubit, qubit + 1)
    elif kind == "qft_prepared":
        # A non-basis product input prevents this QFT case from degenerating
        # into an uninformative computational-basis transformation.
        for qubit in range(qubits):
            circuit.ry(0.071 * (qubit + 1), qubit)
            circuit.rz(0.113 * (2 * qubit + 1), qubit)
        for target in range(qubits):
            circuit.h(target)
            for control in range(target + 1, qubits):
                circuit.cp(math.pi / (2 ** (control - target)), control, target)
        for qubit in range(qubits // 2):
            circuit.swap(qubit, qubits - 1 - qubit)
    elif kind == "brickwork":
        depth = int(spec["depth"])
        seed = int(spec.get("seed", 0))
        # The formula is intentional: it is deterministic, readable, and does
        # not depend on a random-number-generator implementation.
        for layer in range(depth):
            for qubit in range(qubits):
                phase = seed + 17 * layer + 31 * qubit
                circuit.ry(0.017 * ((phase % 29) + 1), qubit)
                circuit.rz(0.023 * (((3 * phase) % 31) + 1), qubit)
            for qubit in range(layer % 2, qubits - 1, 2):
                circuit.cx(qubit, qubit + 1)
    elif kind == "qaoa_ring":
        layers = int(spec["layers"])
        for qubit in range(qubits):
            circuit.h(qubit)
        if qubits == 1:
            edges: list[tuple[int, int]] = []
        elif qubits == 2:
            # A two-node ring has one undirected cost edge, not two copies.
            edges = [(0, 1)]
        else:
            edges = [(qubit, (qubit + 1) % qubits) for qubit in range(qubits)]
        for layer in range(layers):
            gamma = 0.19 + 0.07 * layer
            beta = 0.11 + 0.05 * layer
            for control, target in edges:
                circuit.cx(control, target)
                circuit.rz(2.0 * gamma, target)
                circuit.cx(control, target)
            for qubit in range(qubits):
                circuit.rx(2.0 * beta, qubit)
    elif kind == "schmidt_pair":
        # The Ry-CX pair has Schmidt weights (1-w, w), enabling an
        # integration-level cutoff-boundary test while the idle qubits satisfy
        # the evaluated GPU dispatch policy.
        tail_weight = float(spec["tail_weight"])
        left = qubits // 2 - 1
        circuit.ry(2.0 * math.asin(math.sqrt(tail_weight)), left)
        circuit.cx(left, left + 1)
    else:  # variational_chain
        layers = int(spec["layers"])
        for layer in range(layers):
            for qubit in range(qubits):
                phase = 37 * layer + 19 * qubit + 1
                circuit.ry(0.013 * ((phase % 31) + 1), qubit)
                circuit.rz(0.019 * (((5 * phase) % 29) + 1), qubit)
            for qubit in range(layer % 2, qubits - 1, 2):
                circuit.cx(qubit, qubit + 1)
    return circuit


def qasm_sha256(circuit: Any) -> str:
    from qiskit import qasm2

    return hashlib.sha256(qasm2.dumps(circuit).encode("utf-8")).hexdigest()


def rendered_manifest(manifest: dict[str, object]) -> dict[str, object]:
    """Return the manifest with computed recipe, QASM, and document hashes."""
    rendered = json.loads(json.dumps(manifest))
    circuits = rendered["circuits"]
    assert isinstance(circuits, list)
    for spec in circuits:
        assert isinstance(spec, dict)
        spec["recipe_sha256"] = sha256_json(recipe_payload(spec))
        spec["qasm_sha256"] = qasm_sha256(build_circuit(spec))
    rendered["manifest_sha256"] = sha256_json(manifest_payload(rendered))
    return rendered


def phase_invariant_l2(reference: Any, observed: Any) -> float:
    import numpy as np

    ref = np.asarray(reference, dtype=complex)
    actual = np.asarray(observed, dtype=complex)
    overlap = abs(np.vdot(ref, actual))
    return float(math.sqrt(max(0.0, float(np.vdot(ref, ref).real + np.vdot(actual, actual).real - 2.0 * overlap))))


def fidelity(reference: Any, observed: Any) -> float:
    import numpy as np

    return float(abs(np.vdot(np.asarray(reference, dtype=complex), np.asarray(observed, dtype=complex))) ** 2)


def execute_statevector(simulator: Any, circuit: Any, *, seed_transpiler: int) -> tuple[Any, dict[str, object]]:
    from qiskit import transpile

    circuit_with_snapshot = circuit.copy()
    circuit_with_snapshot.save_statevector()
    compiled = transpile(circuit_with_snapshot, simulator, optimization_level=0, seed_transpiler=seed_transpiler)
    result = simulator.run(compiled, shots=1).result()
    if not result.success:
        raise RuntimeError(f"Aer returned unsuccessful result: {result.status}")
    metadata = result.results[0].metadata
    return result.data(0)["statevector"], dict(metadata)


def read_event_log(path: Path) -> tuple[int, str]:
    """Validate and fingerprint the wrapper-event log produced by the GPU run."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as error:
        raise RuntimeError(f"custom_gpu did not produce event log {path}: {error}") from error
    if not lines:
        raise RuntimeError(f"custom_gpu event log is empty: {path}")
    for line_number, line in enumerate(lines, start=1):
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise RuntimeError(f"invalid custom_gpu event JSON at {path}:{line_number}: {error}") from error
        if not isinstance(value, dict):
            raise RuntimeError(f"custom_gpu event at {path}:{line_number} is not an object")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return len(lines), digest


def assert_backend_provenance(backend: str, aer_path: Path) -> None:
    local_source = expected_custom_source_dir()
    local = local_source in aer_path.parents
    if backend.startswith("custom_") and not local:
        raise RuntimeError(f"{backend} must import the selected custom PR build, got {aer_path}")
    if backend == "upstream_cpu" and local:
        raise RuntimeError(f"upstream_cpu must not import the selected custom PR build, got {aer_path}")


def run_pilot(manifest: dict[str, object], backend: str, max_bond_dimension: int,
              truncation_threshold: float, seed_transpiler: int,
              events_path: Path | None, mps_fidelity_min: float = MPS_FIDELITY_MIN,
              offload_required: bool = True, *, mps_lapack: bool = False,
              dispatch_threshold: int | None = None,
              validate_svd_result: bool = False,
              circuit_builder: Callable[[dict[str, object]], Any] | None = None) -> dict[str, object]:
    if type(mps_lapack) is not bool:
        raise RuntimeError("mps_lapack must be boolean")
    environment_policy = prepare_mps_environment(
        dispatch_threshold=dispatch_threshold, validate_svd_result=validate_svd_result)
    effective_threshold = int(environment_policy["dispatch_threshold_elements"])
    diagnostic_paths: dict[str, str] = {}
    import numpy as np

    if backend == "custom_gpu":
        if events_path is None:
            raise RuntimeError("custom_gpu requires --events-path for cuTensorNet offload evidence")
        if events_path.exists():
            raise RuntimeError(f"refusing to overwrite existing custom_gpu event log: {events_path}")
        events_path.parent.mkdir(parents=True, exist_ok=True)
        os.environ["AER_ENABLE_CUTENSORNET"] = "1"
        os.environ["AER_THRUST_BACKEND"] = "CUDA"
        os.environ["AER_CUTENSOR_SVD_EVENTS_PATH"] = str(events_path.resolve())
        diagnostic_paths["AER_CUTENSOR_SVD_EVENTS_PATH"] = str(events_path.resolve())
    elif events_path is not None:
        raise RuntimeError("--events-path requires custom_gpu")
    from qiskit.quantum_info import Statevector
    from qiskit import transpile
    import qiskit_aer
    from qiskit_aer import AerSimulator

    aer_path = Path(qiskit_aer.__file__).resolve()
    assert_backend_provenance(backend, aer_path)
    device = "GPU" if backend == "custom_gpu" else "CPU"
    mps = AerSimulator(
        method="matrix_product_state", device=device, precision="double",
        mps_lapack=mps_lapack,
        matrix_product_state_max_bond_dimension=max_bond_dimension,
        matrix_product_state_truncation_threshold=truncation_threshold,
    )
    if device not in mps.available_devices():
        raise RuntimeError(f"requested device {device} is not available: {mps.available_devices()}")
    aer_reference = AerSimulator(method="statevector", device="CPU", precision="double")
    records: list[dict[str, object]] = []
    effective_environment = assert_execution_environment(
        dispatch_threshold=effective_threshold, diagnostic_paths=diagnostic_paths,
        validate_svd_result=validate_svd_result)
    circuits = manifest["circuits"]
    assert isinstance(circuits, list)
    for spec in circuits:
        assert isinstance(spec, dict)
        if not spec.get("exact_reference"):
            continue
        circuit = (circuit_builder or build_circuit)(spec)
        actual_hash = qasm_sha256(circuit)
        if actual_hash != spec.get("qasm_sha256"):
            raise RuntimeError(f"{spec['id']}: generated QASM hash differs from frozen manifest")
        # Freeze the graph used later by the timing worker without running it.
        # The reference path still executes its separate measurement-free copy.
        timing_circuit = circuit.copy()
        timing_circuit.measure_all()
        compiled_timing = transpile(timing_circuit, mps, optimization_level=0,
                                    seed_transpiler=seed_transpiler)
        compiled_hash = qasm_sha256(compiled_timing)
        python_reference = Statevector.from_instruction(circuit).data
        effective_environment = assert_execution_environment(
            dispatch_threshold=effective_threshold, diagnostic_paths=diagnostic_paths,
            validate_svd_result=validate_svd_result)
        aer_statevector, reference_metadata = execute_statevector(aer_reference, circuit, seed_transpiler=seed_transpiler)
        reference_fidelity = fidelity(python_reference, aer_statevector)
        if reference_fidelity < REFERENCE_FIDELITY_MIN:
            raise RuntimeError(f"{spec['id']}: independent references disagree (fidelity={reference_fidelity:.16g})")
        effective_environment = assert_execution_environment(
            dispatch_threshold=effective_threshold, diagnostic_paths=diagnostic_paths,
            validate_svd_result=validate_svd_result)
        mps_statevector, mps_metadata = execute_statevector(mps, circuit, seed_transpiler=seed_transpiler)
        if backend == "custom_gpu" and mps_metadata.get("device") != "GPU":
            raise RuntimeError(f"{spec['id']}: custom_gpu result lacks GPU metadata: {mps_metadata}")
        if mps_metadata.get("matrix_product_state_lapack") is not mps_lapack:
            raise RuntimeError(f"{spec['id']}: result metadata does not confirm requested mps_lapack")
        # Aer >= 0.10 returns a Statevector object for a save instruction.
        # Convert it once to avoid relying on its deprecated ndarray protocol.
        mps_vector = np.asarray(mps_statevector, dtype=complex)
        result_fidelity = fidelity(python_reference, mps_vector)
        norm_error = abs(float(np.vdot(mps_vector, mps_vector).real - 1.0))
        phase_l2 = phase_invariant_l2(python_reference, mps_vector)
        passed = result_fidelity >= mps_fidelity_min and norm_error <= NORM_ERROR_MAX
        records.append({
            "circuit_id": spec["id"],
            "qasm_sha256": actual_hash,
            "compiled_qasm_sha256": compiled_hash,
            "reference": {
                "python_statevector": "qiskit.quantum_info.Statevector",
                "aer_statevector": "AerSimulator(method=statevector, device=CPU)",
                "fidelity": reference_fidelity,
                "fidelity_min": REFERENCE_FIDELITY_MIN,
                "metadata": reference_metadata,
            },
            "mps": {
                "fidelity": result_fidelity,
                "fidelity_min": mps_fidelity_min,
                "norm_error": norm_error,
                "norm_error_max": NORM_ERROR_MAX,
                "phase_invariant_l2": phase_l2,
                "metadata": mps_metadata,
            },
            "status": "PASS" if passed else "FAIL",
        })
    if not records:
        raise RuntimeError("manifest has no exact-reference circuits")
    report: dict[str, object] = {
        "schema_version": 1,
        "purpose": "E2 numerical-correctness pilot only; no timing or performance claims.",
        "performance_claims_permitted": False,
        "driver_path": str(Path(__file__).resolve()),
        "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "backend": backend,
        "aer_path": str(aer_path),
        "simulation_config": {
            "method": "matrix_product_state", "device": device, "precision": "double", "shots": 1,
            "max_bond_dimension": max_bond_dimension,
            "truncation_threshold": truncation_threshold,
            "seed_transpiler": seed_transpiler,
            "mps_lapack": mps_lapack,
        },
        "environment_policy": environment_policy,
        "effective_environment": effective_environment,
        "dispatch_threshold_elements": effective_threshold,
        "svd_reconstruction_validation": validate_svd_result,
        "compiled_qasm_scope": "terminal-measurement copy after optimization_level=0 transpilation; not executed by correctness pilot",
        "records": records,
        "status": "PASS" if all(record["status"] == "PASS" for record in records) else "FAIL",
    }
    if backend == "custom_gpu":
        assert events_path is not None
        if events_path.exists():
            event_count, event_sha256 = read_event_log(events_path)
            if event_count < 1:
                raise RuntimeError("custom_gpu completed without a cuTensorNet SVD event")
            report["offload_proof"] = {
                "events_path": str(events_path.resolve()),
                "event_count": event_count,
                "event_sha256": event_sha256,
            }
            report["offload_observation"] = "OBSERVED"
        elif offload_required:
            raise RuntimeError("custom_gpu completed without a cuTensorNet SVD event")
        else:
            # Some deliberately small approximate caps may remain on a
            # non-offload path.  This is a recorded control outcome, never
            # positive offload evidence and never a timing authorization.
            report["offload_observation"] = "NOT_OBSERVED"
            report["offload_expected_events_path"] = str(events_path.resolve())
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--backend", choices=("custom_gpu", "custom_cpu", "upstream_cpu"))
    parser.add_argument("--run-id", help="Required when executing the pilot and writing evidence.")
    parser.add_argument("--output", type=Path, help="Write one JSON correctness report; refuses to overwrite by default.")
    parser.add_argument("--events-path", type=Path,
                        help="Required for custom_gpu; new JSONL wrapper-event log to validate and fingerprint.")
    parser.add_argument("--write-frozen-manifest", action="store_true",
                        help="Print the QASM hashes required to freeze a draft manifest; does not execute Aer.")
    parser.add_argument("--max-bond-dimension", type=int, default=128)
    parser.add_argument("--truncation-threshold", type=float, default=0.0)
    parser.add_argument("--mps-lapack", action=argparse.BooleanOptionalAction, default=False,
                        help="Explicit public Aer mps_lapack option; default false.")
    parser.add_argument("--dispatch-threshold", type=int,
                        help="Positive GPU-SVD element threshold; default 8401 replaces inherited overrides.")
    parser.add_argument("--validate-svd-result", action="store_true",
                        help="Explicitly enable CPU/GPU SVD reconstruction diagnostics in this correctness-only process.")
    parser.add_argument("--mps-fidelity-min", type=float, default=MPS_FIDELITY_MIN,
                        help="Explicit MPS acceptance threshold; exact E2 defaults to 1 - 1e-10.")
    parser.add_argument("--allow-no-offload", action="store_true",
                        help="Record an absent custom-GPU event as NOT_OBSERVED; only for preregistered control studies.")
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    args = parser.parse_args()
    try:
        manifest = load_manifest(args.manifest, allow_pending=args.write_frozen_manifest)
        if args.write_frozen_manifest:
            print(json.dumps(rendered_manifest(manifest), indent=2))
            return 0
        if not args.backend or not args.run_id or not args.output:
            parser.error("--backend, --run-id, and --output are required unless --write-frozen-manifest is used")
        if args.allow_no_offload:
            if args.backend != "custom_gpu":
                parser.error("--allow-no-offload is valid only for custom_gpu")
            if manifest.get("purpose") != "T18 approximate-MPS accuracy-first pilot; not timing evidence.":
                raise RuntimeError("--allow-no-offload is restricted to the frozen T18 control study")
        if (args.max_bond_dimension < 2 or args.truncation_threshold < 0 or
                not 0 < args.mps_fidelity_min <= 1):
            parser.error("max bond dimension must be >= 2 and truncation threshold must be >= 0")
        if args.output.exists():
            raise RuntimeError(f"refusing to overwrite existing evidence: {args.output}")
        report = run_pilot(manifest, args.backend, args.max_bond_dimension,
                           args.truncation_threshold, args.seed_transpiler, args.events_path,
                           args.mps_fidelity_min, not args.allow_no_offload,
                           mps_lapack=args.mps_lapack,
                           dispatch_threshold=args.dispatch_threshold,
                           validate_svd_result=args.validate_svd_result)
        report["run_id"] = args.run_id
        report["manifest_path"] = str(args.manifest.resolve())
        report["manifest_sha256"] = manifest["manifest_sha256"]
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"{report['status']}: E2 numerical-correctness pilot wrote {args.output}")
        return 0 if report["status"] == "PASS" else 1
    except RuntimeError as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
