#!/usr/bin/env python3
"""Source-bound P1 CPU selection; reuses the E2 correctness and E3 timing cells.

Freeze a contract and one five-circuit manifest before running. Every cell is a
fresh process. Failed cells are retained and cannot be silently rerun in place.
This CPU-only selection provides no CPU/GPU performance conclusion.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys

from run_e2_numerical_correctness_pilot import load_manifest, manifest_payload, sha256_json

HERE = Path(__file__).resolve().parent
THREAD_VARIABLES = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                    "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
IMPLEMENTATION_FILES = (Path(__file__).name, "run_e2_numerical_correctness_pilot.py",
                        "run_e3_timing_cell.py", "mps_execution_environment.py")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def validate_contract(contract, manifest_path=None):
    if contract.get("schema_version") != 1 or contract.get("stage") != "P1_CPU_SELECTION":
        raise RuntimeError("not a P1 CPU selection contract")
    if contract.get("protocol") != {"warmups": 5, "timed_repetitions": 20, "shots": 100,
                                    "threads": 6, "max_bond_dimension": 1024,
                                    "truncation_threshold": 0.0, "blocks": 2}:
        raise RuntimeError("P1 protocol differs from the approved plan")
    candidates = contract["candidates"]
    if len(candidates) != 3 or len({c["id"] for c in candidates}) != 3:
        raise RuntimeError("P1 requires three distinct CPU candidates")
    if [(c["backend"], c["mps_lapack"]) for c in candidates] != [
            ("custom_cpu", False), ("custom_cpu", True), ("upstream_cpu", True)]:
        raise RuntimeError("candidate roles must be custom, LAPACK and upstream LAPACK")
    if len(set(contract["cpu_affinity"])) != 6:
        raise RuntimeError("freeze exactly six CPU affinity IDs")
    orders = contract.get("orders", [])
    ids = sorted(c["id"] for c in candidates)
    if len(orders) != 2 or any(len(block) != 5 for block in orders):
        raise RuntimeError("freeze exactly two blocks with five candidate orders each")
    for first, second in zip(*orders):
        if sorted(first) != ids or second != list(reversed(first)):
            raise RuntimeError("each input requires all candidates and a reversed second block")
    for name in IMPLEMENTATION_FILES:
        if contract["runner_sha256"].get(name) != digest(HERE / name):
            raise RuntimeError(f"runner changed after contract freeze: {name}")
    manifest = load_manifest(Path(manifest_path or contract["manifest"]))
    if manifest["manifest_sha256"] != contract["manifest_sha256"]:
        raise RuntimeError("input manifest changed after contract freeze")
    scopes = {(c["kind"], c["qubits"]) for c in manifest["circuits"]}
    if len(manifest["circuits"]) != 5 or scopes != {
            ("brickwork", 14), ("brickwork", 15), ("brickwork", 16),
            ("brickwork", 18), ("qft_prepared", 16)}:
        raise RuntimeError("P1 must contain the five registered workloads")
    return manifest


def verify_candidate(candidate):
    # The binary hash also binds installed upstream wheels for which a Git
    # source path alone would not prove which extension Python loaded.
    if digest(candidate["extension"]) != candidate["extension_sha256"]:
        raise RuntimeError("candidate extension changed after freeze")
    if candidate.get("source_directory"):
        source = candidate["source_directory"]
        revision = subprocess.check_output(["git", "-C", source, "rev-parse", "HEAD"], text=True).strip()
        status = subprocess.check_output(["git", "-C", source, "status", "--porcelain"], text=True).strip()
        if revision != candidate["source_revision"] or status:
            raise RuntimeError("candidate source is dirty or differs from the pinned revision")


def runtime_state(candidate):
    import qiskit
    import qiskit_aer
    from qiskit_aer.backends import controller_wrappers
    from threadpoolctl import threadpool_info
    actual = Path(controller_wrappers.__file__).resolve()
    if actual != Path(candidate["extension"]).resolve() or digest(actual) != candidate["extension_sha256"]:
        raise RuntimeError(f"loaded an unexpected Aer extension: {actual}")
    pools = threadpool_info()
    if not pools or any(p["num_threads"] != 6 for p in pools if p["user_api"] in {"blas", "openmp"}):
        raise RuntimeError(f"actual BLAS/OpenMP thread settings differ from six: {pools}")
    return {"aer_path": qiskit_aer.__file__, "aer_version": qiskit_aer.__version__,
            "qiskit_version": qiskit.__version__, "extension_sha256": digest(actual),
            "thread_pools": pools, "cpu_affinity": sorted(os.sched_getaffinity(0)),
            "thread_environment": {k: os.environ.get(k) for k in THREAD_VARIABLES}}


def execute_child(task_path):
    task = read(task_path)
    contract = read(task["contract"])
    if digest(task["contract"]) != task["contract_sha256"]:
        raise RuntimeError("contract changed after cell dispatch")
    validate_contract(contract, Path(task["contract"]).parent / "manifest.json")
    candidate = next(c for c in contract["candidates"] if c["id"] == task["candidate"])
    verify_candidate(candidate)
    os.sched_setaffinity(0, contract["cpu_affinity"])
    if sorted(os.sched_getaffinity(0)) != sorted(contract["cpu_affinity"]):
        raise RuntimeError("CPU affinity could not be applied")
    manifest = load_manifest(Path(task["manifest"]))
    destination = Path(task["destination"])
    if task["mode"] == "correctness":
        from run_e2_numerical_correctness_pilot import run_pilot
        result = run_pilot(manifest, candidate["backend"], 1024, 0.0,
                           contract["seed_transpiler"], None,
                           mps_lapack=candidate["mps_lapack"], validate_svd_result=True)
        result["runtime"] = runtime_state(candidate)
        result["contract_sha256"] = task["contract_sha256"]
        result["candidate_id"] = candidate["id"]
        result["manifest_sha256"] = manifest["manifest_sha256"]
        write_new(destination / "correctness.json", result)
        if result["status"] != "PASS":
            raise RuntimeError("numerical gate failed; timing is blocked")
    else:
        from run_e3_timing_cell import execute_cell
        checked_runtime = []

        def checkpoint(record):
            if not checked_runtime:
                checked_runtime.append(runtime_state(candidate))
            if record["result_metadata"].get("parallel_state_update", 1) > 6:
                raise RuntimeError("Aer used more than six state-update threads")
            filename = "warmups.jsonl" if record["is_warmup"] else "timings.jsonl"
            with (destination / filename).open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")

        _, _, result = execute_cell(manifest=manifest, backend=candidate["backend"],
            run_id=task["run_id"], warmups=5, timed_repetitions=20, shots=100,
            max_bond_dimension=1024, truncation_threshold=0.0,
            seed_simulator=contract["seed_simulator"], seed_transpiler=contract["seed_transpiler"],
            events_dir=None, mps_lapack=candidate["mps_lapack"],
            expected_compiled_hashes=task["expected_compiled_hashes"],
            cell_wall_time_seconds=contract["cell_wall_time_seconds"], progress_callback=checkpoint)
        result["runtime"] = checked_runtime[0]
        result["contract_sha256"] = task["contract_sha256"]
        result["candidate_id"] = candidate["id"]
        write_new(destination / "timing_report.json", result)


def controlled_environment(candidate):
    environment = os.environ.copy()
    environment.update({key: "6" for key in THREAD_VARIABLES})
    environment.update({"OMP_DYNAMIC": "FALSE", "OMP_PROC_BIND": "FALSE",
                        "PYTHONPATH": candidate.get("pythonpath", ""),
                        "PYTHONNOUSERSITE": "1",
                        "ARTICLE2_CUSTOM_SOURCE_DIR": candidate.get("custom_source_directory",
                                                                    candidate.get("source_directory", ""))})
    environment.pop("OMP_PLACES", None)
    if candidate.get("library_search_paths"):
        environment["LD_LIBRARY_PATH"] = ":".join(candidate["library_search_paths"])
    return environment


def run_campaign(contract_path, run_dir):
    contract = read(contract_path)
    manifest = validate_contract(contract)
    if run_dir.exists():
        raise RuntimeError("refusing to reuse a campaign directory, including a failed campaign")
    run_dir.mkdir(parents=True)
    write_new(run_dir / "contract.json", contract)
    write_new(run_dir / "manifest.json", manifest)
    frozen_contract = run_dir / "contract.json"
    manifests = []
    compiled_hashes = {}
    for spec in manifest["circuits"]:
        single = {"schema_version": 1, "purpose": manifest["purpose"], "circuits": [spec]}
        single["manifest_sha256"] = sha256_json(manifest_payload(single))
        path = run_dir / "inputs" / f"{spec['id']}.json"
        write_new(path, single)
        manifests.append(path)

    def launch(mode, candidate, input_path, block):
        destination = run_dir / mode / f"block_{block}" / input_path.stem / candidate["id"]
        destination.mkdir(parents=True)
        task = {"contract": str(frozen_contract.resolve()), "contract_sha256": digest(frozen_contract),
                "candidate": candidate["id"], "manifest": str(input_path.resolve()),
                "destination": str(destination.resolve()), "mode": mode, "run_id": run_dir.name}
        if mode == "timing":
            task["expected_compiled_hashes"] = {input_path.stem: compiled_hashes[input_path.stem]}
        task_path = destination / "task.json"
        write_new(task_path, task)
        print(f"[P1] {mode} block={block} {input_path.stem} {candidate['id']}", flush=True)
        with (destination / "process.log").open("x", encoding="utf-8") as log:
            try:
                result = subprocess.run([candidate["python"], str(Path(__file__).resolve()),
                                         "--cell-task", str(task_path.resolve())],
                    env=controlled_environment(candidate), stdout=log, stderr=subprocess.STDOUT,
                    timeout=contract["cell_wall_time_seconds"] + 120)
            except subprocess.TimeoutExpired as error:
                raise RuntimeError(f"process timeout, retained partial records: {destination}") from error
        if result.returncode:
            raise RuntimeError(f"cell failed; inspect {destination / 'process.log'}")

    # All three candidates must first pass all five exact-reference gates.
    for input_path in manifests:
        for candidate in contract["candidates"]:
            launch("correctness", candidate, input_path, 0)
        observed = {read(run_dir / "correctness/block_0" / input_path.stem / candidate["id"] /
                         "correctness.json")["records"][0]["compiled_qasm_sha256"]
                    for candidate in contract["candidates"]}
        if len(observed) != 1 or len(next(iter(observed))) != 64:
            raise RuntimeError("candidate transpiled measured circuits differ before timing")
        compiled_hashes[input_path.stem] = observed.pop()
    write_new(run_dir / "compiled_hashes.json", compiled_hashes)
    by_id = {c["id"]: c for c in contract["candidates"]}
    for block, schedule in enumerate(contract["orders"]):
        if len(schedule) != len(manifests):
            raise RuntimeError("invalid counterbalanced schedule length")
        for input_path, order in zip(manifests, schedule):
            if sorted(order) != sorted(by_id):
                raise RuntimeError("schedule does not contain every candidate exactly once")
            for candidate_id in order:
                launch("timing", by_id[candidate_id], input_path, block)
    result = summarize(run_dir)
    write_new(run_dir / "cpu_selection.json", result)
    print(f"PASS: selected {result['selected_cpu']} (CPU-only pilot)", flush=True)


def validate_report(report, contract, contract_hash, candidate, manifest_hash):
    if (report.get("status") != "PASS" or report.get("contract_sha256") != contract_hash
            or report.get("candidate_id") != candidate["id"]
            or report.get("backend") != candidate["backend"]
            or report.get("manifest_sha256") != manifest_hash):
        raise RuntimeError("report identity, status or contract binding mismatch")
    runtime = report["runtime"]
    pools = runtime["thread_pools"]
    if (runtime["extension_sha256"] != candidate["extension_sha256"]
            or sorted(runtime["cpu_affinity"]) != sorted(contract["cpu_affinity"])
            or not pools
            or any(p["num_threads"] != 6 for p in pools if p["user_api"] in {"blas", "openmp"})
            or any(runtime["thread_environment"].get(key) != "6" for key in THREAD_VARIABLES)):
        raise RuntimeError("runtime binary, affinity or thread policy mismatch")


def validate_simulation_config(config, contract, candidate, shots):
    expected = {"method": "matrix_product_state", "device": "CPU", "precision": "double", "shots": shots,
                "max_bond_dimension": 1024, "truncation_threshold": 0.0,
                "seed_transpiler": contract["seed_transpiler"], "mps_lapack": candidate["mps_lapack"]}
    if shots == 100:
        expected["seed_simulator"] = contract["seed_simulator"]
    if any(config.get(k) != v for k, v in expected.items()):
        raise RuntimeError("simulation configuration differs from frozen protocol")


def summarize(run_dir):
    contract = read(run_dir / "contract.json")
    manifest = validate_contract(contract, run_dir / "manifest.json")
    contract_hash = digest(run_dir / "contract.json")
    compiled_hashes = read(run_dir / "compiled_hashes.json")
    if set(compiled_hashes) != {spec["id"] for spec in manifest["circuits"]}:
        raise RuntimeError("missing/extra pre-timing compiled circuit hashes")
    rows = []
    scores = {}
    for candidate in contract["candidates"]:
        log_times = []
        for spec in manifest["circuits"]:
            single = load_manifest(run_dir / "inputs" / f"{spec['id']}.json")
            if single["circuits"] != [spec]:
                raise RuntimeError("single-input manifest differs from frozen campaign")
            correct_path = run_dir / "correctness" / "block_0" / spec["id"] / candidate["id"] / "correctness.json"
            correctness = read(correct_path)
            validate_report(correctness, contract, contract_hash, candidate, single["manifest_sha256"])
            validate_simulation_config(correctness["simulation_config"], contract, candidate, 1)
            if len(correctness["records"]) != 1:
                raise RuntimeError("correctness report must contain exactly one input")
            checked = correctness["records"][0]
            if checked.get("status") != "PASS" or checked.get("circuit_id") != spec["id"] or checked.get("qasm_sha256") != spec["qasm_sha256"]:
                raise RuntimeError("missing/failed correctness gate for this input")
            if checked.get("compiled_qasm_sha256") != compiled_hashes[spec["id"]]:
                raise RuntimeError("candidate correctness transpilation differs from common measured circuit")
            reference, mps = checked["reference"], checked["mps"]
            if (reference.get("fidelity_min") != 1.0 - 1e-12 or mps.get("fidelity_min") != 1.0 - 1e-10
                    or mps.get("norm_error_max") != 1e-10
                    or not all(math.isfinite(float(v)) for v in (reference["fidelity"], mps["fidelity"], mps["norm_error"]))
                    or reference["fidelity"] < 1.0 - 1e-12 or mps["fidelity"] < 1.0 - 1e-10
                    or not 0 <= mps["norm_error"] <= 1e-10):
                raise RuntimeError("numerical acceptance thresholds not met")
            medians = []
            for block in range(2):
                directory = run_dir / "timing" / f"block_{block}" / spec["id"] / candidate["id"]
                report = read(directory / "timing_report.json")
                validate_report(report, contract, contract_hash, candidate, single["manifest_sha256"])
                validate_simulation_config(report["simulation_config"], contract, candidate, 100)
                if report.get("instrumentation_mode") != "none":
                    raise RuntimeError("diagnostic timing cannot select the CPU baseline")
                samples = [json.loads(line) for line in (directory / "timings.jsonl").read_text().splitlines()]
                warmups = [json.loads(line) for line in (directory / "warmups.jsonl").read_text().splitlines()]
                if report["status"] != "PASS" or len(samples) != 20 or len(warmups) != 5:
                    raise RuntimeError("incomplete timing cell")
                for records, count, warmup in ((samples, 20, False), (warmups, 5, True)):
                    if {s["sample_index"] for s in records} != set(range(count)):
                        raise RuntimeError("duplicate/missing sample indices")
                    for sample in records:
                        if (sample["is_warmup"] != warmup or sample["circuit_id"] != spec["id"]
                                or sample["backend"] != candidate["backend"] or sample["run_id"] != run_dir.name
                                or sample.get("compiled_qasm_sha256") != compiled_hashes[spec["id"]]
                                or not math.isfinite(sample["elapsed_seconds"]) or sample["elapsed_seconds"] <= 0):
                            raise RuntimeError("invalid timing/warmup sample")
                        validate_simulation_config(sample["simulation_config"], contract, candidate, 100)
                        from mps_execution_environment import DIAGNOSTIC_PATH_KEYS, RECONSTRUCTION_KEYS
                        effective = sample.get("effective_environment", {})
                        expected_environment = {
                            "dispatch_threshold_elements": 8401,
                            "diagnostic_paths_enabled": {key: False for key in DIAGNOSTIC_PATH_KEYS},
                            "reconstruction_checks_enabled": {key: False for key in RECONSTRUCTION_KEYS}}
                        if sample.get("instrumentation_mode") != "none" or effective != expected_environment:
                            raise RuntimeError("raw sample has missing/active diagnostic controls")
                        metadata = sample["result_metadata"]
                        if (metadata.get("matrix_product_state_lapack") is not candidate["mps_lapack"]
                                or metadata.get("method") != "matrix_product_state" or metadata.get("device") != "CPU"
                                or not 1 <= metadata.get("parallel_state_update", 1) <= 6):
                            raise RuntimeError("observed simulator metadata differs from candidate")
                medians.append(statistics.median(s["elapsed_seconds"] for s in samples))
            value = math.exp(statistics.mean(math.log(m) for m in medians))
            rows.append({"candidate": candidate["id"], "circuit_id": spec["id"],
                         "block_medians_seconds": medians, "geometric_mean_seconds": value})
            log_times.append(math.log(value))
        scores[candidate["id"]] = math.exp(statistics.mean(log_times))
    selected = min(scores, key=scores.get)
    return {"schema_version": 1, "status": "PASS", "stage": "P1_CPU_SELECTION",
            "contract_sha256": digest(run_dir / "contract.json"), "selected_cpu": selected,
            "geometric_mean_seconds": scores, "rows": rows,
            "selection_rule": "minimum geometric mean of per-input/per-block CPU medians; equal input weights",
            "cpu_gpu_performance_claims_permitted": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--cell-task", type=Path)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    try:
        if args.cell_task:
            execute_child(args.cell_task)
        elif args.contract and args.run_dir:
            if args.validate_only:
                print(json.dumps(summarize(args.run_dir), indent=2))
            else:
                run_campaign(args.contract.resolve(), args.run_dir.resolve())
        else:
            parser.error("provide --contract and --run-dir")
        return 0
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
