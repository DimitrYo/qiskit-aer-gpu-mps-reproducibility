"""Input-level statistics for the preregistered Article 2 paired campaign.

The caller supplies the frozen input list and validated retained timing values,
with warm-ups already excluded. Each input is one statistical unit. Its CPU/GPU
pair and all session blocks stay together during bootstrap resampling. This
module does not run simulations, select a CPU candidate, validate physics, or
combine new observations with historical campaigns.
"""

from __future__ import annotations

import math
import random
from collections.abc import Mapping, Sequence
from typing import Any


PRIMARY_WORKLOAD = "BW-16"
SECONDARY_WORKLOADS = ("BW-14", "BW-15", "pQFT-16", "BW-18")
TIMED_REPETITIONS = 20
CONFIRMATORY_BLOCKS = 2
PILOT_INPUTS = 5
SECONDARY_INPUTS = 6
MINIMUM_PRIMARY_INPUTS = 12
MAXIMUM_PRIMARY_INPUTS = 20
TARGET_RELATIVE_HALF_WIDTH = 0.15
# Two-sided 95% Student-t critical value with the five-input pilot's 4 df.
# This is a fixed plug-in planning multiplier, not a power calculation.
PILOT_T_CRITICAL = 2.7764451051977987
BOOTSTRAP_REPETITIONS = 10000
BOOTSTRAP_CONFIDENCE = 0.95
DEFAULT_BOOTSTRAP_SEED = 20260907


def _name(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty string")
    return value


def _names(values: Sequence[str], field: str) -> list[str]:
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
        raise ValueError(f"{field} must be an explicit frozen sequence")
    result = [_name(value, field) for value in values]
    if not result or len(set(result)) != len(result):
        raise ValueError(f"{field} must contain distinct identifiers")
    return result


def _block_ids(values: Sequence[int | str]) -> list[int | str]:
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
        raise ValueError("expected_blocks must be an explicit frozen sequence")
    result = list(values)
    for value in result:
        if type(value) is int:
            if value < 0:
                raise ValueError("block identifiers must be non-negative")
        elif isinstance(value, str) and value.strip():
            pass
        else:
            raise ValueError("block identifiers must be integers or non-empty strings")
    if not result or len(set(result)) != len(result):
        raise ValueError("expected_blocks must contain distinct identifiers")
    return result


def _times(values: Any, field: str) -> list[float]:
    if (not isinstance(values, Sequence) or isinstance(values, (str, bytes))
            or len(values) != TIMED_REPETITIONS):
        raise ValueError(f"{field} must contain exactly {TIMED_REPETITIONS} retained timings, excluding warm-ups")
    result = []
    for value in values:
        if type(value) not in (int, float):
            raise ValueError(f"{field} values must be numeric, not booleans or strings")
        try:
            number = float(value)
        except (ValueError, OverflowError) as error:
            raise ValueError(f"{field} contains an unrepresentable timing") from error
        if not math.isfinite(number) or number <= 0.0:
            raise ValueError(f"{field} values must be positive and finite")
        result.append(number)
    return result


def _median(values: Sequence[float]) -> float:
    ordered = sorted(values)
    middle = len(ordered) // 2
    # All values are positive; this avoids overflowing a + b for large inputs.
    return ordered[middle - 1] + (ordered[middle] - ordered[middle - 1]) / 2.0


def _exp(value: float) -> float:
    try:
        result = math.exp(value)
    except OverflowError as error:
        raise ValueError("CPU/GPU speedup is outside the representable range") from error
    if not math.isfinite(result) or result <= 0.0:
        raise ValueError("CPU/GPU speedup is outside the representable range")
    return result


def _input_summaries(records: Sequence[Mapping[str, Any]], *, workload: str,
                     cpu_candidate: str, gpu_candidate: str,
                     input_ids: Sequence[str], block_ids: Sequence[int | str]) -> list[dict[str, Any]]:
    _name(cpu_candidate, "cpu_candidate")
    _name(gpu_candidate, "gpu_candidate")
    if cpu_candidate == gpu_candidate:
        raise ValueError("CPU and GPU candidate identifiers must differ")
    if not isinstance(records, Sequence) or isinstance(records, (str, bytes)):
        raise ValueError("records must be a sequence of paired input/block records")
    expected_inputs, expected_blocks = set(input_ids), set(block_ids)
    indexed: dict[tuple[str, int | str], dict[str, Any]] = {}
    for record in records:
        if not isinstance(record, Mapping):
            raise ValueError("each paired input/block record must be an object")
        if record.get("workload") != workload:
            raise ValueError("different workloads must be analyzed separately")
        if (record.get("cpu_candidate") != cpu_candidate or
                record.get("gpu_candidate") != gpu_candidate):
            raise ValueError("different candidate pairs must be analyzed separately")
        input_id = _name(record.get("input_id"), "input_id")
        block_id = record.get("block_id")
        _block_ids([block_id])
        if input_id not in expected_inputs or block_id not in expected_blocks:
            raise ValueError("record is outside the frozen input/block grid")
        key = (input_id, block_id)
        if key in indexed:
            raise ValueError("duplicate paired input/block record")
        if type(record.get("offload_observed")) is not bool:
            raise ValueError("offload_observed must be an explicit boolean; it is never an inclusion filter")
        cpu_median = _median(_times(record.get("cpu_seconds"), "cpu_seconds"))
        gpu_median = _median(_times(record.get("gpu_seconds"), "gpu_seconds"))
        log_ratio = math.log(cpu_median) - math.log(gpu_median)
        indexed[key] = {
            "block_id": block_id,
            "cpu_median_seconds": cpu_median,
            "gpu_median_seconds": gpu_median,
            "log_speedup": log_ratio,
            "speedup_cpu_over_gpu": _exp(log_ratio),
            "offload_observed": record["offload_observed"],
        }
    expected_grid = {(input_id, block_id) for input_id in input_ids for block_id in block_ids}
    if set(indexed) != expected_grid:
        raise ValueError("missing input or block from the frozen grid")
    result = []
    for input_id in input_ids:
        blocks = [indexed[(input_id, block_id)] for block_id in block_ids]
        mean_log = math.fsum(block["log_speedup"] for block in blocks) / len(blocks)
        result.append({
            "input_id": input_id,
            "blocks": blocks,
            "mean_log_speedup": mean_log,
            "geometric_mean_speedup": _exp(mean_log),
            "offload_observed_in_any_block": any(block["offload_observed"] for block in blocks),
        })
    return result


def _percentile(ordered: Sequence[float], probability: float) -> float:
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    fraction = position - lower
    return ordered[lower] + fraction * (ordered[upper] - ordered[lower])


def plan_primary_sample_size(pilot_records: Sequence[Mapping[str, Any]], *,
                             expected_input_ids: Sequence[str], cpu_candidate: str,
                             gpu_candidate: str, pilot_block: int | str = 1) -> dict[str, Any]:
    """Use exactly five separate BW-16 pilot inputs to freeze a fixed count.

    Required n = max(2, ceil((t_(.975,4) * s_log / log(1.15))**2)).
    Clamp n to the declared 12..20 budget and disclose when the estimate exceeds
    20. Only between-input spread enters the rule; the mean speedup and whether
    any interval excludes 1 do not. Pilot inputs must not enter confirmation.
    """
    input_ids = _names(expected_input_ids, "expected_input_ids")
    if len(input_ids) != PILOT_INPUTS:
        raise ValueError("sample-size planning requires exactly five frozen pilot inputs")
    blocks = _block_ids([pilot_block])
    summaries = _input_summaries(pilot_records, workload=PRIMARY_WORKLOAD,
                                 cpu_candidate=cpu_candidate, gpu_candidate=gpu_candidate,
                                 input_ids=input_ids, block_ids=blocks)
    logs = [item["mean_log_speedup"] for item in summaries]
    mean_log = math.fsum(logs) / PILOT_INPUTS
    sample_sd = math.sqrt(math.fsum((value - mean_log) ** 2 for value in logs) / (PILOT_INPUTS - 1))
    target_log_half_width = math.log1p(TARGET_RELATIVE_HALF_WIDTH)
    required = max(2, math.ceil((PILOT_T_CRITICAL * sample_sd / target_log_half_width) ** 2))
    selected = min(MAXIMUM_PRIMARY_INPUTS, max(MINIMUM_PRIMARY_INPUTS, required))
    return {
        "schema_version": 1,
        "analysis_kind": "primary_sample_size_plan",
        "planning_rule": "pilot_sd_log_t4_plugin_v1",
        "workload": PRIMARY_WORKLOAD,
        "cpu_candidate": cpu_candidate,
        "gpu_candidate": gpu_candidate,
        "pilot_input_ids": input_ids,
        "pilot_input_count": PILOT_INPUTS,
        "pilot_block_id": pilot_block,
        "pilot_input_summaries": summaries,
        "pilot_sample_sd_log": sample_sd,
        "planning_critical_value": PILOT_T_CRITICAL,
        "target_relative_half_width": TARGET_RELATIVE_HALF_WIDTH,
        "target_log_half_width": target_log_half_width,
        "half_width_definition": "multiplicative upper factor exp(log_half_width)=1.15; not a symmetric linear-scale width",
        "plug_in_required_inputs": required,
        "selected_primary_inputs": selected,
        "minimum_primary_inputs": MINIMUM_PRIMARY_INPUTS,
        "maximum_primary_inputs": MAXIMUM_PRIMARY_INPUTS,
        "budget_limited": required > MAXIMUM_PRIMARY_INPUTS,
        "precision_guaranteed": False,
        "freeze_required_before_confirmatory": True,
        "pilot_input_exclusion_required": True,
        "stopping_rule": "fixed_input_count_no_significance_stopping",
        "scope": "Approximate precision planning from five inputs; not a power calculation or a guarantee about the final bootstrap interval.",
    }


def analyze_campaign_contrast(records: Sequence[Mapping[str, Any]], *, workload: str,
                               cpu_candidate: str, gpu_candidate: str,
                               selected_cpu_candidate: str,
                               expected_input_ids: Sequence[str],
                               expected_blocks: Sequence[int | str] = (1, 2),
                               role: str = "primary",
                               bootstrap_seed: int = DEFAULT_BOOTSTRAP_SEED) -> dict[str, Any]:
    """Analyze one frozen workload/candidate contrast, retaining every input.

    The primary contrast is BW-16 against the selected CPU. Secondary workloads
    and an optional different same-source CPU comparison are descriptive; they
    do not create additional unadjusted confirmatory claims. Source compatibility
    of an internal control and numerical correctness are validated by the caller.
    """
    _name(selected_cpu_candidate, "selected_cpu_candidate")
    if workload not in (PRIMARY_WORKLOAD, *SECONDARY_WORKLOADS):
        raise ValueError("workload is outside the preregistered primary/secondary set")
    if role not in ("primary", "secondary", "internal_control"):
        raise ValueError("unknown analysis role")
    if role == "primary" and (workload != PRIMARY_WORKLOAD or cpu_candidate != selected_cpu_candidate):
        raise ValueError("only BW-16 versus the frozen selected CPU is primary")
    if role == "secondary" and (workload not in SECONDARY_WORKLOADS or cpu_candidate != selected_cpu_candidate):
        raise ValueError("secondary analysis requires a declared secondary workload and the selected CPU")
    if role == "internal_control" and cpu_candidate == selected_cpu_candidate:
        raise ValueError("internal_control must be a separate CPU contrast, not a duplicate selected-CPU comparison")
    if type(bootstrap_seed) is not int or not 0 <= bootstrap_seed < (1 << 64):
        raise ValueError("bootstrap_seed must be a frozen non-negative uint64 integer")
    input_ids = _names(expected_input_ids, "expected_input_ids")
    blocks = _block_ids(expected_blocks)
    if len(blocks) != CONFIRMATORY_BLOCKS:
        raise ValueError("the confirmatory/descriptive campaign requires exactly two frozen blocks")
    if workload == PRIMARY_WORKLOAD:
        if not MINIMUM_PRIMARY_INPUTS <= len(input_ids) <= MAXIMUM_PRIMARY_INPUTS:
            raise ValueError("BW-16 requires the frozen 12..20 confirmatory input count")
    elif len(input_ids) != SECONDARY_INPUTS:
        raise ValueError("each secondary workload requires exactly six frozen inputs")
    summaries = _input_summaries(records, workload=workload, cpu_candidate=cpu_candidate,
                                 gpu_candidate=gpu_candidate, input_ids=input_ids, block_ids=blocks)
    logs = [item["mean_log_speedup"] for item in summaries]
    input_count = len(logs)
    mean_log = math.fsum(logs) / input_count
    rng = random.Random(bootstrap_seed)
    # A selected mean represents its WHOLE input: paired CPU/GPU cells and all
    # blocks. No timing repetitions or blocks are independently resampled.
    bootstrap_means = sorted(
        math.fsum(logs[rng.randrange(input_count)] for _ in range(input_count)) / input_count
        for _ in range(BOOTSTRAP_REPETITIONS)
    )
    tail = (1.0 - BOOTSTRAP_CONFIDENCE) / 2.0
    interval = [_exp(_percentile(bootstrap_means, tail)),
                _exp(_percentile(bootstrap_means, 1.0 - tail))]
    classification = "positive" if interval[0] > 1.0 else "negative" if interval[1] < 1.0 else "inconclusive"
    with_offload = sum(item["offload_observed_in_any_block"] for item in summaries)
    return {
        "schema_version": 1,
        "analysis_kind": "input_cluster_bootstrap",
        "role": role,
        "inference": "primary_confirmatory" if role == "primary" else "descriptive_pointwise",
        "workload": workload,
        "cpu_candidate": cpu_candidate,
        "gpu_candidate": gpu_candidate,
        "selected_cpu_candidate": selected_cpu_candidate,
        "input_ids": input_ids,
        "block_ids": blocks,
        "input_count": input_count,
        "block_count": len(blocks),
        "retained_timings_per_backend_per_block": TIMED_REPETITIONS,
        "input_summaries": summaries,
        "mean_log_speedup": mean_log,
        "geometric_mean_speedup": _exp(mean_log),
        "confidence_interval": interval,
        "confidence_level": BOOTSTRAP_CONFIDENCE,
        "classification": classification,
        "classification_definition": "positive: entire CI above 1; negative: entire CI below 1; otherwise inconclusive; CPU/GPU orientation",
        "bootstrap": {
            "unit": "whole_input",
            "repetitions": BOOTSTRAP_REPETITIONS,
            "seed": bootstrap_seed,
            "method": "linear-interpolated percentile interval in log space, exponentiated",
            "cpu_gpu_pair_preserved": True,
            "all_blocks_preserved": True,
            "within_input_resampling": False,
        },
        "offload_summary": {
            "inputs_with_any_recorded_offload": with_offload,
            "inputs_without_recorded_offload": input_count - with_offload,
            "filter_applied": False,
        },
        "stopping_rule": "fixed_input_count_no_significance_stopping",
        "scope": "Timing statistic conditional on the frozen input ensemble and two sessions on this node; numerical/source gates are external, offload is descriptive, and no SVD-only causal attribution follows.",
    }
