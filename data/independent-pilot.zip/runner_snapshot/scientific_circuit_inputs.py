"""Frozen independent-angle inputs for the future P2/P3 circuit ensemble.

Importing this module creates no inputs. Explicit generation uses NumPy's
Generator(PCG64(seed)); execution consumes recorded angles without regenerating
them. Existing deterministic recipes and all historical manifests are untouched.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

from run_e2_numerical_correctness_pilot import (
    load_manifest, manifest_payload, qasm_sha256, recipe_payload, sha256_json,
)


SCOPES = (("brickwork", 14), ("brickwork", 15), ("brickwork", 16),
          ("brickwork", 18), ("qft_prepared", 16))
PRIMARY_SCOPE = ("brickwork", 16)
DEPTH = 24
SEED_BASES = {"pilot": 100000, "confirmation": 200000}
SEEDS_PER_SCOPE = 1000
DESIGN_ID = "independent_uniform_angles_v1"
DRAW_ORDER = {"brickwork": "layer_major_qubit_major_ry_rz",
              "qft_prepared": "qubit_major_ry_rz_preparation_only"}


def _scope(kind: str, qubits: int) -> tuple[str, int]:
    if not isinstance(kind, str) or type(qubits) is not int or (kind, qubits) not in SCOPES:
        raise ValueError("unregistered scientific circuit scope")
    return kind, qubits


def seed_for(stage: str, kind: str, qubits: int, index: int) -> int:
    scope = _scope(kind, qubits)
    if not isinstance(stage, str) or stage not in SEED_BASES:
        raise ValueError("stage must be pilot or confirmation")
    limit = 5 if stage == "pilot" else (20 if scope == PRIMARY_SCOPE else 6)
    if type(index) is not int or not 0 <= index < limit:
        raise ValueError("seed index is outside the registered stage/scope range")
    return SEED_BASES[stage] + SCOPES.index(scope) * SEEDS_PER_SCOPE + index


def seed_schedule(stage: str, *, primary_confirmation_count: int = 16) -> dict:
    if type(primary_confirmation_count) is not int or not 12 <= primary_confirmation_count <= 20:
        raise ValueError("freeze 12 to 20 primary confirmation circuits before running")
    if not isinstance(stage, str) or stage not in SEED_BASES:
        raise ValueError("stage must be pilot or confirmation")
    schedule = {}
    for scope in SCOPES:
        count = 5 if stage == "pilot" else (primary_confirmation_count if scope == PRIMARY_SCOPE else 6)
        schedule[scope] = tuple(seed_for(stage, *scope, index) for index in range(count))
    return schedule


def generate_scientific_spec(stage: str, kind: str, qubits: int, index: int) -> dict:
    """Generate one unfrozen recipe; build_scientific_manifest adds its hashes."""
    import numpy as np

    seed = seed_for(stage, kind, qubits, index)
    count = 2 * qubits * (DEPTH if kind == "brickwork" else 1)
    rng = np.random.Generator(np.random.PCG64(seed))
    label = "bw" if kind == "brickwork" else "pqft"
    spec = {
        "id": f"{label}_n{qubits}_{stage}_s{seed}",
        "kind": kind, "qubits": qubits, "seed": seed,
        "exact_reference": True, "offload_required": False,
        "ensemble_design": DESIGN_ID, "ensemble_stage": stage, "ensemble_index": index,
        "angle_generator": {
            "api": "numpy.random.Generator", "bit_generator": "PCG64",
            "numpy_version": np.__version__, "seed": seed,
            "distribution": "uniform", "low": -math.pi, "high": math.pi,
            "interval": "[-pi, pi)", "draw_order": DRAW_ORDER[kind],
        },
        "angles": rng.uniform(-math.pi, math.pi, size=count).tolist(),
    }
    if kind == "brickwork":
        spec["depth"] = DEPTH
    return spec


def _validated_angles(spec: dict) -> tuple[str, int, list[float]]:
    if not isinstance(spec, dict):
        raise ValueError("scientific circuit recipe must be an object")
    kind, qubits = _scope(spec.get("kind"), spec.get("qubits"))
    if spec.get("ensemble_design") != DESIGN_ID:
        raise ValueError("unknown scientific ensemble design")
    if spec.get("exact_reference") is not True or spec.get("offload_required") is not False:
        raise ValueError("all ensemble inputs require exact references and retain absent GPU offload as an outcome")
    expected_seed = seed_for(spec.get("ensemble_stage"), kind, qubits, spec.get("ensemble_index"))
    if type(spec.get("seed")) is not int or spec["seed"] != expected_seed:
        raise ValueError("seed is inconsistent with the disjoint stage/scope schedule")
    if not isinstance(spec.get("id"), str) or not spec["id"]:
        raise ValueError("a nonempty circuit identifier is required")
    if kind == "brickwork" and (type(spec.get("depth")) is not int or spec["depth"] != DEPTH):
        raise ValueError("brickwork topology must retain depth 24")
    if kind == "qft_prepared" and "depth" in spec:
        raise ValueError("prepared QFT has fixed topology, not a brickwork depth")
    generator = spec.get("angle_generator")
    expected = {"api": "numpy.random.Generator", "bit_generator": "PCG64",
                "seed": expected_seed, "distribution": "uniform",
                "low": -math.pi, "high": math.pi, "interval": "[-pi, pi)",
                "draw_order": DRAW_ORDER[kind]}
    if (not isinstance(generator, dict)
            or any(generator.get(key) != value for key, value in expected.items())
            or type(generator.get("seed")) is not int
            or not isinstance(generator.get("numpy_version"), str)
            or not generator["numpy_version"].strip()):
        raise ValueError("missing or inconsistent PRNG/version/distribution metadata")
    # The recorded NumPy version is provenance. Replaying raw angles does not
    # require the installed NumPy to match it or consume random numbers.
    angles = spec.get("angles")
    count = 2 * qubits * (DEPTH if kind == "brickwork" else 1)
    if not isinstance(angles, list) or len(angles) != count:
        raise ValueError(f"expected exactly {count} recorded angles")
    if any(type(value) not in (int, float) or not -math.pi <= value < math.pi
           or not math.isfinite(value) for value in angles):
        raise ValueError("angles must be finite real numbers in [-pi, pi)")
    return kind, qubits, angles


def build_scientific_circuit(spec: dict):
    """Validate and replay a frozen-angle workload; no PRNG is invoked here."""
    kind, qubits, angles = _validated_angles(spec)
    from qiskit import QuantumCircuit

    circuit = QuantumCircuit(qubits, name=spec["id"])
    values = iter(angles)
    if kind == "brickwork":
        for layer in range(DEPTH):
            for qubit in range(qubits):
                circuit.ry(next(values), qubit)
                circuit.rz(next(values), qubit)
            for qubit in range(layer % 2, qubits - 1, 2):
                circuit.cx(qubit, qubit + 1)
    else:
        for qubit in range(qubits):
            circuit.ry(next(values), qubit)
            circuit.rz(next(values), qubit)
        # Only the preparation angles vary. The complete QFT gate sequence,
        # controlled phases and final reversal match the existing workload.
        for target in range(qubits):
            circuit.h(target)
            for control in range(target + 1, qubits):
                circuit.cp(math.pi / (2 ** (control - target)), control, target)
        for qubit in range(qubits // 2):
            circuit.swap(qubit, qubits - 1 - qubit)
    return circuit


def build_scientific_manifest(stage: str, *, primary_confirmation_count: int = 16) -> dict:
    """Build a complete frozen ensemble without writing or simulating it."""
    schedule = seed_schedule(stage, primary_confirmation_count=primary_confirmation_count)
    circuits = []
    for (kind, qubits), seeds in schedule.items():
        for index in range(len(seeds)):
            spec = generate_scientific_spec(stage, kind, qubits, index)
            spec["recipe_sha256"] = sha256_json(recipe_payload(spec))
            spec["qasm_sha256"] = qasm_sha256(build_scientific_circuit(spec))
            circuits.append(spec)
    manifest = {
        "schema_version": 1, "purpose": f"Independent-angle {stage} ensemble; no results or timing claims.",
        "ensemble_design": DESIGN_ID, "ensemble_stage": stage,
        "primary_scope": {"kind": PRIMARY_SCOPE[0], "qubits": PRIMARY_SCOPE[1]},
        "seed_schedule": [
            {"kind": kind, "qubits": qubits, "seeds": list(seeds)}
            for (kind, qubits), seeds in schedule.items()
        ],
        "circuits": circuits,
    }
    manifest["manifest_sha256"] = sha256_json(manifest_payload(manifest))
    return manifest


def write_scientific_manifest(path: Path, stage: str, *, primary_confirmation_count: int = 16) -> dict:
    """Persist a newly frozen input file; refuse to overwrite any prior file."""
    path = Path(path)
    if path.exists():
        raise FileExistsError(f"refusing to replace a frozen manifest: {path}")
    manifest = build_scientific_manifest(stage, primary_confirmation_count=primary_confirmation_count)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(manifest, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return manifest


def validate_scientific_manifest(manifest: dict, *, expected_stage: str | None = None) -> dict:
    """Reject missing instances, altered raw inputs and incorrect recipe/QASM hashes."""
    if manifest.get("schema_version") != 1 or manifest.get("ensemble_design") != DESIGN_ID:
        raise ValueError("not a scientific independent-angle manifest")
    if manifest.get("primary_scope") != {"kind": PRIMARY_SCOPE[0], "qubits": PRIMARY_SCOPE[1]}:
        raise ValueError("primary scope must be brickwork at 16 qubits")
    stage = manifest.get("ensemble_stage")
    if expected_stage is not None and stage != expected_stage:
        raise ValueError("input stage does not match the requested campaign")
    circuits = manifest.get("circuits")
    if not isinstance(circuits, list) or any(not isinstance(spec, dict) for spec in circuits):
        raise ValueError("circuits must be a list of complete recipes")
    for spec in circuits:
        _validated_angles(spec)
    primary_count = sum((spec.get("kind"), spec.get("qubits")) == PRIMARY_SCOPE for spec in circuits)
    schedule = seed_schedule(stage, primary_confirmation_count=primary_count if stage == "confirmation" else 16)
    expected = {(kind, qubits, seed) for (kind, qubits), seeds in schedule.items() for seed in seeds}
    observed = {(spec.get("kind"), spec.get("qubits"), spec.get("seed")) for spec in circuits}
    if len(circuits) != len(expected) or observed != expected or len({s.get("id") for s in circuits}) != len(circuits):
        raise ValueError("ensemble has missing, repeated or unregistered input instances")
    if manifest.get("seed_schedule") != [
            {"kind": kind, "qubits": qubits, "seeds": list(seeds)}
            for (kind, qubits), seeds in schedule.items()]:
        raise ValueError("recorded seed schedule differs from the registered ensemble")
    for spec in circuits:
        if spec.get("ensemble_stage") != stage:
            raise ValueError("circuit stage differs from its manifest")
        circuit = build_scientific_circuit(spec)
        if spec.get("recipe_sha256") != sha256_json(recipe_payload(spec)):
            raise ValueError("scientific recipe hash mismatch")
        if spec.get("qasm_sha256") != qasm_sha256(circuit):
            raise ValueError("scientific QASM hash mismatch")
    if manifest.get("manifest_sha256") != sha256_json(manifest_payload(manifest)):
        raise ValueError("scientific manifest hash mismatch")
    return manifest


def load_scientific_manifest(path: Path, *, expected_stage: str | None = None) -> dict:
    return validate_scientific_manifest(load_manifest(Path(path)), expected_stage=expected_stage)
