#!/usr/bin/env python3
"""S1 fixed-input supplementary map, isolated from confirmatory P2 evidence.

Preparation freezes recipes/QASM, the P2 build contract and worker sources.
Run --probe before --run; --resume skips only hash-verified completed cells.
Failed or interrupted cells are never retried in place. --validate-only and
summarize(run_dir) use only the standard library and work after relocation.
No confidence interval or independent-input generalization is produced.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import signal
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ENTRY = "run_supplementary_fixed_input_map.py"
SNAPSHOT_FILES = (ENTRY, "run_e2_numerical_correctness_pilot.py",
                  "run_e3_timing_cell.py", "mps_execution_environment.py",
                  "run_scientific_cpu_pilot.py")
REVISION = "a1242579272784330b217085fe11b7e1481922ad"
EXTENSION_SHA = "0a65457e6b783fa4dd46e89e2b0ffc6f4f3899e0a1fdd81c48345f1ed04ae490"
VERSIONS = {"qiskit": "2.5.0", "qiskit_aer": "0.17.2",
            "numpy": "2.4.6", "threadpoolctl": "3.6.0"}
THREAD_KEYS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
PATH_KEYS = ("AER_CUTENSOR_SVD_EVENTS_PATH", "AER_CUTENSOR_SVD_PROFILE_PATH",
             "AER_CUTENSOR_SVD_DECISIONS_PATH", "AER_CUBLAS_EVENTS_PATH",
             "AER_CPU_LAPACK_PROFILE_PATH")
RECON_KEYS = ("AER_CUTENSOR_SVD_VALIDATE_RESULT", "AER_MPS_SVD_VALIDATE_RESULT")
PROTOCOL = {"warmups": 5, "timed_repetitions": 10, "shots": 100, "threads": 6,
            "max_bond_dimension": 2048, "truncation_threshold": 0.0,
            "precision": "double", "dispatch_threshold_elements": 8401, "blocks": 2}
SEED = 20260912
AFFINITY = [0, 2, 4, 6, 8, 10]
CANDIDATES = ["custom_cpu_lapack", "custom_gpu_lapack"]


def stamp():
    return datetime.now(timezone.utc).isoformat()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def semantic(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def unique_pairs(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "duplicate JSON key")
        value[key] = item
    return value


def decode(text):
    return json.loads(text, object_pairs_hook=unique_pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def read(path):
    return decode(Path(path).read_text(encoding="utf-8"))


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2, allow_nan=False)
        stream.write("\n")


def bound(root, relative):
    """All archive lookups use local relative paths, never recorded host paths."""
    root = Path(root).resolve()
    require(isinstance(relative, str) and relative and "\\" not in relative,
            "invalid archive-relative path")
    pieces = relative.split("/")
    require(not Path(relative).is_absolute() and not any(p in ("", ".", "..") for p in pieces)
            and ":" not in relative, "unsafe archive-relative path")
    current = root
    for piece in pieces:
        current = current / piece
        require(not current.is_symlink(), "symlink is not an evidence file")
    require(current.resolve().is_relative_to(root), "archive path escaped root")
    return current


def inventory(root, exclude=()):
    root = Path(root)
    return {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob("*"))
            if p.is_file() and p.relative_to(root).as_posix() not in exclude
            and "__pycache__" not in p.parts}


def verify_inventory(root, expected, exclude=()):
    require(isinstance(expected, dict), "missing inventory")
    for name, hashed in expected.items():
        path = bound(root, name)
        require(path.is_file() and digest(path) == hashed, "missing or changed artifact: " + name)
    require(inventory(root, exclude) == expected, "unregistered or changed files in cell")


def recipes():
    specs = [{"id": f"brickwork_n{n:02d}_d24_s20260724", "kind": "brickwork",
              "qubits": n, "depth": 24, "seed": 20260724} for n in range(1, 23)]
    specs += [{"id": "qft_prepared_n20", "kind": "qft_prepared", "qubits": 20},
              {"id": "qaoa_ring_n20_p2", "kind": "qaoa_ring", "qubits": 20, "layers": 2},
              {"id": "variational_chain_n20_l6", "kind": "variational_chain", "qubits": 20, "layers": 6},
              {"id": "ghz_n20", "kind": "ghz", "qubits": 20}]
    return [dict(spec, exact_reference=True, offload_required=False) for spec in specs]


def single_manifest(spec):
    value = {"schema_version": 1, "purpose": "S1 fixed historical recipe; n=1 per workload",
             "circuits": [spec]}
    value["manifest_sha256"] = semantic(value)
    return value


def schedule(specs):
    ids = [spec["id"] for spec in specs]
    first = {cid: CANDIDATES[::1 if index % 2 == 0 else -1] for index, cid in enumerate(ids)}
    return [{"input_order": ids, "candidate_orders": first},
            {"input_order": ids[::-1], "candidate_orders": {k: v[::-1] for k, v in first.items()}}]


def validate_frozen(run_dir):
    root = Path(run_dir).resolve()
    sealed = read(root / "PREPARED.json")
    require(sealed.get("status") == "PREPARED", "campaign preparation incomplete")
    for name, hashed in sealed["files_sha256"].items():
        path = bound(root, name)
        require(path.is_file() and digest(path) == hashed, "frozen artifact changed: " + name)
    contract, manifest = read(root / "contract.json"), read(root / "manifest.json")
    require(contract.get("stage") == "S1_FIXED_INPUT_MAP" and contract.get("schema_version") == 1,
            "not an S1 contract")
    require(isinstance(contract.get("run_id"), str) and contract["run_id"] and
            all(c.isalnum() or c in "_-" for c in contract["run_id"]), "invalid run ID")
    require(contract.get("protocol") == PROTOCOL and contract.get("runtime_versions") == VERSIONS,
            "S1 protocol or runtime versions changed")
    require(contract.get("cpu_affinity") == AFFINITY and
            contract.get("seed_simulator") == contract.get("seed_transpiler") == SEED,
            "S1 seed/affinity changed")
    require(contract.get("cell_timeout_seconds") == 3600 and contract.get("probe_timeout_seconds") == 1800,
            "S1 timeout bounds changed")
    baseline = read(root / "baseline_p2_contract.json")
    require(contract.get("baseline_contract_sha256") == digest(root / "baseline_p2_contract.json"),
            "P2 build binding changed")
    require(baseline.get("stage") == "P2_CONFIRMATION" and baseline.get("runtime_versions") == VERSIONS,
            "not the accepted P2 baseline")
    require(contract.get("candidates") == baseline.get("candidates"), "S1 candidates differ from P2")
    candidates = contract["candidates"]
    require([c["id"] for c in candidates] == CANDIDATES and
            [c["backend"] for c in candidates] == ["custom_cpu", "custom_gpu"], "candidate roles changed")
    for candidate in candidates:
        require(candidate["mps_lapack"] is True and candidate["source_revision"] == REVISION
                and candidate["extension_sha256"] == EXTENSION_SHA, "candidate build/LAPACK mismatch")
    for key in ("python", "pythonpath", "source_directory", "extension", "library_search_paths"):
        require(candidates[0].get(key) == candidates[1].get(key), "CPU/GPU do not share one build")
    require(manifest.get("manifest_sha256") == semantic({k: v for k, v in manifest.items()
                                                       if k != "manifest_sha256"})
            == contract.get("manifest_sha256"), "manifest binding mismatch")
    expected = recipes()
    require(len(manifest["circuits"]) == len(expected) == 26, "S1 must retain all 26 fixed inputs")
    for spec, recipe in zip(manifest["circuits"], expected):
        require({k: v for k, v in spec.items() if k not in ("recipe_sha256", "qasm_sha256")} == recipe,
                "input recipe or its position changed")
        require(spec["recipe_sha256"] == semantic(recipe), "recipe hash changed")
        require(digest(bound(root, "circuits/" + spec["id"] + ".qasm")) == spec["qasm_sha256"],
                "frozen QASM changed")
        require(read(bound(root, "inputs/" + spec["id"] + ".json")) == single_manifest(spec),
                "single-input manifest changed")
    require(contract.get("blocks") == schedule(manifest["circuits"]), "prescribed block order changed")
    hashes = contract.get("runner_sha256", {})
    require(set(hashes) == set(SNAPSHOT_FILES), "runner dependency set changed")
    require(read(root / "runner_snapshot.json") == {"schema_version": 1, "files_sha256": hashes},
            "snapshot inventory mismatch")
    for name, hashed in hashes.items():
        require(digest(bound(root, "runner_snapshot/" + name)) == hashed, "worker source changed")
    require(inventory(root / "runner_snapshot") == hashes, "unexpected worker dependency in snapshot")
    expected_seal = {"contract.json", "manifest.json", "baseline_p2_contract.json", "runner_snapshot.json"}
    expected_seal |= {"runner_snapshot/" + n for n in SNAPSHOT_FILES}
    expected_seal |= {f"{folder}/{s['id']}.{ext}" for s in manifest["circuits"]
                      for folder, ext in (("inputs", "json"), ("circuits", "qasm"))}
    require(set(sealed["files_sha256"]) == expected_seal, "preparation seal omits required files")
    return root, contract, manifest


def prepare(run_dir, baseline_path):
    require(sys.platform == "linux", "prepare/run require the pinned Linux/WSL environment")
    require(platform.python_version() == "3.11.15", "prepare using the pinned P2 Python 3.11.15")
    root = Path(run_dir).resolve()
    require(not root.exists(), "preparation requires a new directory, including after failure")
    baseline_path = Path(baseline_path).resolve()
    baseline = read(baseline_path)
    root.mkdir(parents=True)
    snapshot = root / "runner_snapshot"
    snapshot.mkdir()
    for name in SNAPSHOT_FILES:
        shutil.copyfile(HERE / name, snapshot / name)
    hashes = {name: digest(snapshot / name) for name in SNAPSHOT_FILES}
    write_new(root / "runner_snapshot.json", {"schema_version": 1, "files_sha256": hashes})
    shutil.copyfile(baseline_path, root / "baseline_p2_contract.json")
    # QASM generation imports Qiskit, but never imports Aer or executes a circuit.
    from run_e2_numerical_correctness_pilot import rendered_manifest, build_circuit
    from qiskit import qasm2
    manifest = rendered_manifest({"schema_version": 1,
        "purpose": "S1 supplementary fixed-input map; descriptive, not independent-input confirmation",
        "circuits": recipes()})
    write_new(root / "manifest.json", manifest)
    for spec in manifest["circuits"]:
        write_new(root / "inputs" / (spec["id"] + ".json"), single_manifest(spec))
        path = root / "circuits" / (spec["id"] + ".qasm")
        path.parent.mkdir(exist_ok=True)
        with path.open("xb") as stream:
            stream.write(qasm2.dumps(build_circuit(spec)).encode("utf-8"))
    contract = {"schema_version": 1, "stage": "S1_FIXED_INPUT_MAP", "prepared_at": stamp(), "run_id": root.name,
        "protocol": PROTOCOL, "runtime_versions": VERSIONS, "python_version": "3.11.15",
        "python_executable_sha256": digest(Path(sys.executable).resolve()),
        "cpu_affinity": AFFINITY, "candidates": baseline["candidates"],
        "seed_simulator": SEED, "seed_transpiler": SEED, "manifest_sha256": manifest["manifest_sha256"],
        "runner_sha256": hashes, "baseline_contract_sha256": digest(root / "baseline_p2_contract.json"),
        "blocks": schedule(manifest["circuits"]), "cell_timeout_seconds": 3600, "probe_timeout_seconds": 1800,
        "inference": "one fixed input per workload; two block ratios; descriptive min/max only; no confidence intervals",
        "hardware": {"cpu_model_contains": "i5-12400F", "gpu_name_contains": "RTX 4060 Ti", "driver_version": "591.86"}}
    write_new(root / "contract.json", contract)
    write_new(root / "PREPARED.json", {"status": "PREPARED", "files_sha256": inventory(root)})
    validate_frozen(root)
    print(json.dumps({"status": "PREPARED", "run_dir": str(root), "input_count": 26}))


def jobs(contract, manifest, probe=False):
    specs = manifest["circuits"]
    if probe:
        specs = [s for s in specs if s["kind"] == "brickwork" and s["qubits"] == 22]
    prefix = "probe" if probe else "cells"
    result = []
    for spec in specs:
        for candidate in CANDIDATES:
            result.append({"path": f"{prefix}/correctness/{spec['id']}/{candidate}",
                           "mode": "correctness", "input_id": spec["id"], "candidate_id": candidate,
                           "probe": probe, "block": None})
    if probe:
        for candidate in CANDIDATES:
            result.append({"path": f"probe/timing/{specs[0]['id']}/{candidate}", "mode": "probe_timing",
                           "input_id": specs[0]["id"], "candidate_id": candidate, "probe": True, "block": None})
    else:
        for spec in specs:
            result.append({"path": f"cells/diagnostic/{spec['id']}/custom_gpu_lapack",
                           "mode": "diagnostic", "input_id": spec["id"],
                           "candidate_id": "custom_gpu_lapack", "probe": False, "block": None})
        for block, order in enumerate(contract["blocks"]):
            for cid in order["input_order"]:
                for candidate in order["candidate_orders"][cid]:
                    result.append({"path": f"cells/timing/block_{block}/{cid}/{candidate}", "mode": "timing",
                                   "input_id": cid, "candidate_id": candidate, "probe": False, "block": block})
    return result


def inactive_environment(active=(), reconstruction=False):
    return {"diagnostic_paths_enabled": {k: k in active for k in PATH_KEYS},
            "reconstruction_checks_enabled": {k: reconstruction for k in RECON_KEYS},
            "dispatch_threshold_elements": 8401}


def finite(value, positive=False):
    return type(value) in (int, float) and math.isfinite(value) and (value > 0 if positive else True)


def timestamp(value):
    parsed = datetime.fromisoformat(value)
    require(parsed.tzinfo is not None and parsed.utcoffset().total_seconds() == 0, "timestamps must be UTC")
    return parsed.timestamp()


def validate_runtime(runtime, candidate, contract):
    require(runtime.get("extension_sha256") == EXTENSION_SHA and runtime.get("source_revision") == REVISION
            and runtime.get("source_clean") is True, "runtime binary/source mismatch")
    require(runtime.get("package_versions") == VERSIONS and runtime.get("python_version") == "3.11.15"
            and runtime.get("python_executable_sha256") == contract["python_executable_sha256"],
            "runtime interpreter/package mismatch")
    require(runtime.get("cpu_affinity") == AFFINITY and
            runtime.get("thread_environment") == {k: "6" for k in THREAD_KEYS}, "runtime thread/affinity mismatch")
    pools = runtime.get("thread_pools", [])
    require(pools and all(p["num_threads"] == 6 for p in pools if p["user_api"] in ("blas", "openmp")),
            "runtime BLAS/OpenMP pool mismatch")
    require(runtime.get("loader_injection_present") == {"LD_PRELOAD": False, "LD_AUDIT": False},
            "loader instrumentation present")
    require(runtime.get("omp_controls") == {"OMP_DYNAMIC": "FALSE", "OMP_PROC_BIND": "FALSE", "OMP_PLACES": None},
            "OMP binding controls differ")
    hw = runtime.get("hardware", {})
    require("i5-12400F" in hw.get("cpu_model", "") and "RTX 4060 Ti" in hw.get("gpu_name", "")
            and hw.get("driver_version") == "591.86", "recorded hardware differs from registered node")


def validate_config(config, candidate, shots):
    expected = {"method": "matrix_product_state", "device": "GPU" if candidate["backend"] == "custom_gpu" else "CPU",
                "precision": "double", "shots": shots, "max_bond_dimension": 2048,
                "truncation_threshold": 0.0, "seed_transpiler": SEED, "mps_lapack": True}
    if shots == 100:
        expected["seed_simulator"] = SEED
    require(all(config.get(k) == v for k, v in expected.items()), "simulation configuration mismatch")


def validate_metadata(metadata, candidate):
    require(metadata.get("method") == "matrix_product_state" and
            metadata.get("device") == ("GPU" if candidate["backend"] == "custom_gpu" else "CPU") and
            metadata.get("matrix_product_state_lapack") is True and
            1 <= metadata.get("parallel_state_update", 1) <= 6, "Aer metadata does not confirm configuration")


def jsonl(path, allow_missing=False):
    if allow_missing and not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    require(all(line.strip() for line in lines), "blank line in S1 JSONL")
    return [decode(line) for line in lines]


def event_count(path, event, keys):
    records = jsonl(path, allow_missing=True)
    require(not path.exists() or records, "empty recorder file is not valid absence evidence")
    for record in records:
        require(isinstance(record, dict) and record.get("event") == event and
                all(type(record.get(k)) is int and record[k] > 0 for k in keys), "malformed native event")
    return len(records)


def validate_cell(root, contract, manifest, job, compiled=None):
    directory = bound(root, job["path"])
    receipt = read(directory / "COMPLETE.json")
    require(receipt.get("status") == "PASS" and receipt.get("job") == job, "cell incomplete or failed")
    require(receipt.get("contract_sha256") == digest(root / "contract.json"), "cell contract binding mismatch")
    verify_inventory(directory, receipt["files_sha256"], ("COMPLETE.json",))
    exit_state = read(directory / "process_exit.json")
    require(exit_state.get("returncode") == 0 and exit_state.get("timed_out") is False
            and exit_state.get("interrupted") is False
            and exit_state.get("timeout_seconds") == (1800 if job["probe"] else 3600),
            "worker did not exit successfully within registered process contract")
    duration = timestamp(exit_state["finished_at"]) - timestamp(exit_state["started_at"])
    require(0 <= duration <= exit_state["timeout_seconds"] + 30, "worker duration is outside process cap")
    candidate = next(c for c in contract["candidates"] if c["id"] == job["candidate_id"])
    spec = next(s for s in manifest["circuits"] if s["id"] == job["input_id"])
    task = read(directory / "task.json")
    require(task.get("job") == job and task.get("contract_sha256") == digest(root / "contract.json")
            and task.get("manifest_sha256") == manifest["manifest_sha256"], "task identity mismatch")
    report = read(directory / "report.json")
    require(report.get("status") == "PASS" and report.get("candidate_id") == candidate["id"]
            and report.get("contract_sha256") == task["contract_sha256"]
            and report.get("manifest_sha256") == single_manifest(spec)["manifest_sha256"]
            and report.get("backend") == candidate["backend"], "worker report identity mismatch")
    validate_runtime(report["runtime"], candidate, contract)
    if job["mode"] == "correctness":
        validate_config(report["simulation_config"], candidate, 1)
        require(report.get("svd_reconstruction_validation") is True, "correctness reconstruction checks missing")
        require(report.get("effective_environment") == inactive_environment(
            ("AER_CUTENSOR_SVD_EVENTS_PATH",) if candidate["backend"] == "custom_gpu" else (), True),
            "correctness environment changed")
        require(len(report["records"]) == 1, "correctness must contain one input")
        record = report["records"][0]
        require(record.get("status") == "PASS" and record.get("circuit_id") == spec["id"]
                and record.get("qasm_sha256") == spec["qasm_sha256"], "correctness input mismatch")
        numerical = record["mps"]
        require(numerical.get("fidelity_min") == 1 - 1e-10 and numerical.get("norm_error_max") == 1e-10
                and record["reference"].get("fidelity_min") == 1 - 1e-12, "numerical thresholds changed")
        require(finite(numerical["fidelity"]) and numerical["fidelity"] >= 1 - 1e-10 and
                finite(numerical["norm_error"]) and 0 <= numerical["norm_error"] <= 1e-10 and
                finite(record["reference"]["fidelity"]) and record["reference"]["fidelity"] >= 1 - 1e-12
                and finite(numerical["phase_invariant_l2"]) and numerical["phase_invariant_l2"] >= 0,
                "numerical correctness gate failed")
        validate_metadata(numerical["metadata"], candidate)
        require(len(record.get("compiled_qasm_sha256", "")) == 64, "missing measured graph hash")
        return record["compiled_qasm_sha256"]
    require(compiled and task.get("compiled_qasm_sha256") == compiled, "timing lacks prior correctness graph")
    validate_config(report["simulation_config"], candidate, 100)
    if job["mode"] == "diagnostic":
        require(report.get("warmup_count") == 0 and report.get("executions") == 1
                and report.get("performance_claims_permitted") is False
                and report.get("compiled_qasm_sha256") == compiled
                and report.get("qasm_sha256") == spec["qasm_sha256"], "invalid diagnostic scope")
        require(report.get("effective_environment") == inactive_environment(
            ("AER_CUTENSOR_SVD_EVENTS_PATH", "AER_CUBLAS_EVENTS_PATH")), "diagnostic recorders not active")
        validate_metadata(report["result_metadata"], candidate)
        counts = {"svd_submitted_calls": event_count(directory / "svd.events.jsonl", "cutensor_csvd_wrapper", ("rows", "columns")),
                  "cublas_submitted_calls": event_count(directory / "cublas.events.jsonl", "cublas_zgemm", ("rows", "inner", "columns"))}
        require(report.get("recorded_calls") == counts, "diagnostic counts differ from native logs")
        return counts
    warm, retained = (0, 1) if job["probe"] else (5, 10)
    require(report.get("warmup_count") == warm and report.get("timed_repetition_count") == retained
            and report.get("instrumentation_mode") == "none"
            and report.get("effective_environment") == inactive_environment()
            and report.get("statevector_extraction") is False, "timing protocol/instrumentation mismatch")
    samples = []
    for filename, count, is_warm in (("warmups.jsonl", warm, True), ("timings.jsonl", retained, False)):
        records = jsonl(directory / filename, allow_missing=(count == 0))
        require(len(records) == count and [r["sample_index"] for r in records] == list(range(count)),
                "missing/extra/reordered timing samples")
        for record in records:
            require(record.get("is_warmup") is is_warm and record.get("circuit_id") == spec["id"]
                    and record.get("backend") == candidate["backend"] and record.get("run_id") == contract["run_id"]
                    and record.get("qasm_sha256") == spec["qasm_sha256"]
                    and record.get("compiled_qasm_sha256") == compiled
                    and record.get("instrumentation_mode") == "none"
                    and record.get("effective_environment") == inactive_environment()
                    and finite(record.get("elapsed_seconds"), True), "invalid timing observation")
            validate_config(record["simulation_config"], candidate, 100)
            validate_metadata(record["result_metadata"], candidate)
        if not is_warm:
            samples = [r["elapsed_seconds"] for r in records]
    return samples


def scan_jobs(root, contract, manifest, probe=False, complete=False, stop_at_incomplete=False):
    ordered = jobs(contract, manifest, probe)
    allowed = {j["path"] for j in ordered}
    folder = root / ("probe" if probe else "cells")
    if folder.exists():
        require({p.parent.relative_to(root).as_posix() for p in folder.rglob("task.json")} <= allowed,
                "unregistered worker directory")
        require(all(any(p.relative_to(root).as_posix().startswith(name + "/") for name in allowed)
                    for p in folder.rglob("*") if p.is_file()), "unregistered file outside a scheduled cell")
    compiled, results, missing, previous_finish = {}, {}, False, None
    if not probe:
        last_probe = bound(root, jobs(contract, manifest, True)[-1]["path"])
        if (last_probe / "COMPLETE.json").exists():
            previous_finish = timestamp(read(last_probe / "process_exit.json")["finished_at"])
    for job in ordered:
        path = bound(root, job["path"])
        if not path.exists():
            missing = True
            require(not complete, "campaign incomplete: " + job["path"])
            continue
        require(not missing, "completed cells are not a prefix of the frozen schedule")
        if stop_at_incomplete and not (path / "COMPLETE.json").exists() and not (path / "FAILED.json").exists():
            # Monitoring alone may observe a worker before its receipt is sealed.
            # Execution/resume/summary never enable this observational exception.
            missing = True
            continue
        value = validate_cell(root, contract, manifest, job, compiled.get(job["input_id"]))
        exit_state = read(path / "process_exit.json")
        started = timestamp(exit_state["started_at"])
        require(previous_finish is None or started >= previous_finish,
                "actual worker chronology violates prescribed serial schedule")
        previous_finish = timestamp(exit_state["finished_at"])
        if job["mode"] == "correctness":
            prior = compiled.setdefault(job["input_id"], value)
            require(prior == value, "CPU/GPU correctness compiled graphs differ")
        results[job["path"]] = value
    return ordered, compiled, results


def summarize(run_dir):
    """Recompute complete accepted S1 results offline; never writes an artifact."""
    root, contract, manifest = validate_frozen(run_dir)
    scan_jobs(root, contract, manifest, probe=True, complete=True)
    ordered, _, values = scan_jobs(root, contract, manifest, complete=True)
    rows = []
    for spec in manifest["circuits"]:
        cid = spec["id"]
        medians = {candidate: [statistics.median(values[f"cells/timing/block_{b}/{cid}/{candidate}"])
                              for b in range(2)] for candidate in CANDIDATES}
        cpu, gpu = (medians[c] for c in CANDIDATES)
        ratios = [c / g for c, g in zip(cpu, gpu)]
        gm = lambda v: math.exp(statistics.mean(math.log(x) for x in v))
        counts = values[f"cells/diagnostic/{cid}/custom_gpu_lapack"]
        rows.append({"circuit_id": cid, "kind": spec["kind"], "qubits": spec["qubits"], "independent_inputs": 1,
            "cpu_seconds": gm(cpu), "gpu_seconds": gm(gpu), "cpu_gpu_ratio": gm(ratios),
            "block_cpu_medians": cpu, "block_gpu_medians": gpu, "block_cpu_gpu_ratios": ratios,
            "block_ratio_min": min(ratios), "block_ratio_max": max(ratios), **counts,
            "diagnostic_call_scope": "one separate 100-shot call; zero warmups"})
    return {"schema_version": 1, "stage": "S1_FIXED_INPUT_MAP", "status": "PASS",
        "run_id": contract["run_id"], "contract_sha256": digest(root / "contract.json"),
        "manifest_sha256": manifest["manifest_sha256"], "runner_sha256": contract["runner_sha256"],
        "protocol": PROTOCOL, "input_count": 26, "timing_cell_count": 104,
        "discarded_warmups": 520, "retained_calls": 1040, "correctness_cell_count": 52,
        "diagnostic_cell_count": 26, "probe_calls_included": False,
        "inference": contract["inference"], "range_interpretation": "min/max of two block ratios, not a confidence interval",
        "rows": rows}


def observed_runtime(candidate, contract):
    from run_scientific_cpu_pilot import runtime_state, verify_candidate
    verify_candidate(candidate)
    runtime = runtime_state(candidate)
    import numpy
    import threadpoolctl
    runtime.update({"package_versions": {"qiskit": runtime["qiskit_version"], "qiskit_aer": runtime["aer_version"],
                       "numpy": numpy.__version__, "threadpoolctl": threadpoolctl.__version__},
        "python_version": platform.python_version(), "python_executable_sha256": digest(Path(sys.executable).resolve()),
        "source_revision": candidate["source_revision"], "source_clean": True,
        "loader_injection_present": {k: k in os.environ for k in ("LD_PRELOAD", "LD_AUDIT")},
        "omp_controls": {k: os.environ.get(k) for k in ("OMP_DYNAMIC", "OMP_PROC_BIND", "OMP_PLACES")},
        "platform": platform.platform()})
    cpu = next(line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines()
               if line.startswith("model name"))
    gpu = subprocess.check_output(["nvidia-smi", "--query-gpu=name,driver_version,memory.total,pci.bus_id",
                                   "--format=csv,noheader,nounits"], text=True, timeout=15).strip().splitlines()
    require(len(gpu) == 1, "S1 requires the single registered GPU")
    name, driver, memory, pci = [v.strip() for v in gpu[0].split(",")]
    runtime["hardware"] = {"cpu_model": cpu, "gpu_name": name, "driver_version": driver,
                           "gpu_memory_mib": int(memory), "gpu_pci_bus_id": pci}
    validate_runtime(runtime, candidate, contract)
    return runtime


def diagnostic_worker(directory, single, compiled_hash):
    """P3's explicit two-recorder pattern; E3 clears the cuBLAS control.

    This unretained call has no performance timer. Ordinary timed calls remain
    exclusively in unchanged E3.execute_cell; no environment monkeypatching.
    """
    from mps_execution_environment import prepare_mps_environment, assert_execution_environment
    from run_e2_numerical_correctness_pilot import build_circuit, qasm_sha256
    prepare_mps_environment(dispatch_threshold=8401)
    os.environ["AER_ENABLE_CUTENSORNET"] = "1"
    os.environ["AER_THRUST_BACKEND"] = "CUDA"
    paths = {"AER_CUTENSOR_SVD_EVENTS_PATH": str((directory / "svd.events.jsonl").resolve()),
             "AER_CUBLAS_EVENTS_PATH": str((directory / "cublas.events.jsonl").resolve())}
    os.environ.update(paths)
    from qiskit import transpile
    from qiskit_aer import AerSimulator
    backend = AerSimulator(method="matrix_product_state", device="GPU", precision="double", mps_lapack=True,
                           matrix_product_state_max_bond_dimension=2048, matrix_product_state_truncation_threshold=0.0)
    spec = single["circuits"][0]
    circuit = build_circuit(spec)
    require(qasm_sha256(circuit) == spec["qasm_sha256"], "diagnostic source QASM differs")
    circuit.measure_all()
    compiled = transpile(circuit, backend, optimization_level=0, seed_transpiler=SEED)
    require(qasm_sha256(compiled) == compiled_hash, "diagnostic measured graph differs from correctness")
    effective = assert_execution_environment(dispatch_threshold=8401, diagnostic_paths=paths)
    result = backend.run(compiled, shots=100, seed_simulator=SEED).result()
    require(result.success, "diagnostic simulator failed")
    require(assert_execution_environment(dispatch_threshold=8401, diagnostic_paths=paths) == effective,
            "diagnostic environment changed during execution")
    return {"status": "PASS", "backend": "custom_gpu", "warmup_count": 0, "executions": 1,
            "performance_claims_permitted": False, "effective_environment": effective,
            "qasm_sha256": spec["qasm_sha256"], "compiled_qasm_sha256": compiled_hash,
            "simulation_config": {"method": "matrix_product_state", "device": "GPU", "precision": "double",
                "shots": 100, "mps_lapack": True, "max_bond_dimension": 2048, "truncation_threshold": 0.0,
                "seed_simulator": SEED, "seed_transpiler": SEED},
            "result_metadata": dict(result.results[0].metadata),
            "recorded_calls": {"svd_submitted_calls": event_count(directory / "svd.events.jsonl", "cutensor_csvd_wrapper", ("rows", "columns")),
                               "cublas_submitted_calls": event_count(directory / "cublas.events.jsonl", "cublas_zgemm", ("rows", "inner", "columns"))}}


def worker(run_dir, task_relative):
    root, contract, manifest = validate_frozen(run_dir)
    require(HERE == root / "runner_snapshot", "workers must execute frozen sources")
    task = read(bound(root, task_relative))
    job = task["job"]
    require(job in jobs(contract, manifest, job["probe"]) and
            task["contract_sha256"] == digest(root / "contract.json"), "invalid dispatched task")
    require(task_relative == job["path"] + "/task.json", "task location mismatch")
    directory = bound(root, job["path"])
    candidate = next(c for c in contract["candidates"] if c["id"] == job["candidate_id"])
    from run_scientific_cpu_pilot import verify_candidate
    verify_candidate(candidate)
    require(digest(Path(sys.executable).resolve()) == contract["python_executable_sha256"], "worker interpreter differs")
    os.sched_setaffinity(0, AFFINITY)
    require(sorted(os.sched_getaffinity(0)) == AFFINITY, "worker affinity failed")
    # No address-space cap: CUDA reserves virtual addresses unrelated to RAM.
    # N<=22, chi<=2048, fixed counts, wall timeout and output cap bound this run.
    import resource
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024**3, 1024**3))
    single = read(bound(root, "inputs/" + job["input_id"] + ".json"))
    if job["mode"] == "correctness":
        from run_e2_numerical_correctness_pilot import run_pilot
        report = run_pilot(single, candidate["backend"], 2048, 0.0, SEED,
            directory / "correctness.events.jsonl" if candidate["backend"] == "custom_gpu" else None,
            offload_required=False, mps_lapack=True, dispatch_threshold=8401, validate_svd_result=True)
    elif job["mode"] == "diagnostic":
        report = diagnostic_worker(directory, single, task["compiled_qasm_sha256"])
    else:
        from run_e3_timing_cell import execute_cell
        checked_runtime = []
        def checkpoint(record):
            if not checked_runtime:
                checked_runtime.append(observed_runtime(candidate, contract))
            name = "warmups.jsonl" if record["is_warmup"] else "timings.jsonl"
            with (directory / name).open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
        _, _, report = execute_cell(manifest=single, backend=candidate["backend"], run_id=contract["run_id"],
            warmups=0 if job["probe"] else 5, timed_repetitions=1 if job["probe"] else 10, shots=100,
            max_bond_dimension=2048, truncation_threshold=0.0, seed_simulator=SEED, seed_transpiler=SEED,
            events_dir=None, dispatch_threshold=8401, mps_lapack=True,
            expected_compiled_hashes={job["input_id"]: task["compiled_qasm_sha256"]},
            allow_uninstrumented_gpu_timing=True,
            cell_wall_time_seconds=1800 if job["probe"] else 3600, progress_callback=checkpoint)
    report.update({"runtime": observed_runtime(candidate, contract), "contract_sha256": task["contract_sha256"],
                   "candidate_id": candidate["id"], "manifest_sha256": single["manifest_sha256"]})
    write_new(directory / "report.json", report)
    require(report["status"] == "PASS", "worker gate failed")


def launch(root, contract, manifest, job, compiled):
    from run_scientific_cpu_pilot import controlled_environment
    active = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid,process_name",
                                      "--format=csv,noheader,nounits"], text=True, timeout=15).strip()
    require(not active, "another GPU compute process is active; no S1 worker launched")
    directory = bound(root, job["path"])
    require(not directory.exists(), "refusing to retry any existing cell, including failure")
    directory.mkdir(parents=True)
    task = {"job": job, "contract_sha256": digest(root / "contract.json"),
            "manifest_sha256": manifest["manifest_sha256"], "compiled_qasm_sha256": compiled}
    write_new(directory / "task.json", task)
    candidate = next(c for c in contract["candidates"] if c["id"] == job["candidate_id"])
    environment = controlled_environment(candidate)
    for key in ("LD_PRELOAD", "LD_AUDIT", *PATH_KEYS, *RECON_KEYS, "AER_CUTENSOR_SVD_MIN_ELEMENTS"):
        environment.pop(key, None)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    cap = 1800 if job["probe"] else 3600
    command = [candidate["python"], str(root / "runner_snapshot" / ENTRY), "--run-dir", str(root),
               "--_worker-task", job["path"] + "/task.json"]
    print("[S1] " + job["path"], flush=True)
    started = stamp()
    timed_out, interrupted, code = False, False, None
    with (directory / "process.log").open("x", encoding="utf-8") as log:
        process = subprocess.Popen(command, env=environment, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            code = process.wait(timeout=cap)
        except BaseException as error:
            timed_out = isinstance(error, subprocess.TimeoutExpired)
            interrupted = not timed_out
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=15)
    write_new(directory / "process_exit.json", {"returncode": code, "timed_out": timed_out,
        "interrupted": interrupted, "started_at": started, "finished_at": stamp(), "timeout_seconds": cap,
        "gpu_compute_processes_before_worker": 0})
    if code != 0 or timed_out or interrupted:
        write_new(directory / "FAILED.json", {"status": "FAIL", "job": job,
                  "reason": "worker failure/timeout/interruption; no in-place retry", "files_sha256": inventory(directory)})
        raise RuntimeError("S1 stopped with preserved failed cell: " + job["path"])
    receipt = {"status": "PASS", "job": job, "contract_sha256": task["contract_sha256"],
               "files_sha256": inventory(directory)}
    write_new(directory / "COMPLETE.json", receipt)
    try:
        validate_cell(root, contract, manifest, job, compiled)
    except Exception as error:
        write_new(directory / "FAILED.json", {"status": "FAIL", "job": job, "reason": str(error)})
        raise


def execute(run_dir, probe=False, resume=False):
    require(sys.platform == "linux", "execution requires pinned Linux/WSL")
    root, contract, manifest = validate_frozen(run_dir)
    if not probe:
        scan_jobs(root, contract, manifest, probe=True, complete=True)
    if not resume:
        require(not (root / ("probe" if probe else "cells")).exists(), "use --resume for a completed prefix")
    ordered, compiled, results = scan_jobs(root, contract, manifest, probe=probe)
    for job in ordered:
        if job["path"] in results:
            continue
        launch(root, contract, manifest, job, compiled.get(job["input_id"]))
        value = validate_cell(root, contract, manifest, job, compiled.get(job["input_id"]))
        if job["mode"] == "correctness":
            previous = compiled.setdefault(job["input_id"], value)
            require(previous == value, "CPU/GPU compiled QASM mismatch; timing blocked")
    scan_jobs(root, contract, manifest, probe=probe, complete=True)
    if probe:
        print(json.dumps({"status": "PASS", "scope": "BW22 feasibility probe only; no retained observations"}))
    else:
        result = summarize(root)
        if (root / "analysis.json").exists():
            require(read(root / "analysis.json") == result, "stored summary differs from raw data")
        else:
            write_new(root / "analysis.json", result)
        print(json.dumps(result, indent=2))


@contextmanager
def node_lock():
    """Use the common Article 2 GPU lock without altering any evidence."""
    import fcntl
    lock_path = Path("/tmp/article2_gpu_workload.lock")
    with lock_path.open("a") as stream:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError("another Article 2 campaign holds the node lock") from error
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def status(run_dir):
    root, contract, manifest = validate_frozen(run_dir)
    value = {"stage": "S1_FIXED_INPUT_MAP", "status": "PREPARED", "completed": 0,
             "expected_production_cells": 182, "expected_probe_cells": 4, "failures": [],
             "unverified_cells": [], "monitoring_is_acceptance": False}
    for probe in (True, False):
        try:
            ordered, _, done = scan_jobs(root, contract, manifest, probe=probe, stop_at_incomplete=True)
            value["completed_probe_cells" if probe else "completed_production_cells"] = len(done)
            value["completed"] += len(done)
            for job in ordered:
                path = bound(root, job["path"])
                if not path.exists() or job["path"] in done:
                    continue
                counts = {}
                for name in ("warmups.jsonl", "timings.jsonl"):
                    raw = path / name
                    if raw.exists():
                        with raw.open(encoding="utf-8") as stream:
                            counts[name] = sum(bool(line.strip()) for line in stream)
                    else:
                        counts[name] = 0
                value["unverified_cells"].append({"job": job, "observed_raw_line_counts": counts,
                    "process_exit_recorded": (path / "process_exit.json").exists(),
                    "note": "May be active or interrupted; no completed receipt, no observations accepted."})
        except Exception as error:
            value["failures"].append(str(error))
    if value["failures"]:
        value["status"] = "FAIL"
    elif value["unverified_cells"]:
        value["status"] = "PARTIAL_UNVERIFIED"
    elif value["completed"] == 186:
        value["status"] = "COMPLETE" if (root / "analysis.json").is_file() else "READY_TO_SUMMARIZE"
    elif value["completed"]:
        value["status"] = "PARTIAL"
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--baseline-contract", type=Path)
    parser.add_argument("--resume-probe", action="store_true", help="With --probe, continue only a completed probe prefix.")
    actions = parser.add_mutually_exclusive_group(required=True)
    for action in ("prepare", "probe", "run", "resume", "validate-only", "status"):
        actions.add_argument("--" + action, action="store_true")
    actions.add_argument("--_worker-task", help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    try:
        if args.prepare:
            require(args.baseline_contract is not None, "--prepare needs --baseline-contract from accepted P2")
            prepare(args.run_dir, args.baseline_contract)
        elif args._worker_task:
            worker(args.run_dir, args._worker_task)
        elif args.validate_only:
            result = summarize(args.run_dir)
            require(read(args.run_dir / "analysis.json") == result,
                    "stored analysis differs from revalidated raw data")
            print(json.dumps(result, indent=2))
        elif args.status:
            print(json.dumps(status(args.run_dir), indent=2))
        else:
            # Dispatch campaign orchestration through the frozen copy as well.
            root, _, _ = validate_frozen(args.run_dir)
            if HERE != root / "runner_snapshot":
                completed = subprocess.run([sys.executable, str(root / "runner_snapshot" / ENTRY), *(argv or sys.argv[1:])])
                return completed.returncode
            require(not args.resume_probe or args.probe, "--resume-probe requires --probe")
            with node_lock():
                execute(root, probe=args.probe, resume=args.resume or args.resume_probe)
        return 0
    except Exception as error:
        print(json.dumps({"status": "FAIL", "error": str(error)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
