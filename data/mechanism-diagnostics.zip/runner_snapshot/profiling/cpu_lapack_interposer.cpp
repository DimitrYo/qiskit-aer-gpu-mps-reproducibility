// Diagnostic-only Linux x86-64 LP64 OpenBLAS interposer. Never preload in timing.
#if !defined(__linux__) || !defined(__x86_64__)
#error "This diagnostic interposer supports Linux x86-64 LP64 OpenBLAS only."
#endif

#include <cerrno>
#include <complex>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <fcntl.h>
#include <iomanip>
#include <locale>
#include <mutex>
#include <sstream>
#include <string>
#include <sys/file.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

namespace {
using Integer = std::int32_t;
using Complex = std::complex<double>;
static_assert(sizeof(Integer) == 4, "LAPACK INTEGER must be LP64 (32 bits)");
static_assert(sizeof(Complex) == 2 * sizeof(double), "Complex ABI mismatch");

// Single-character LAPACK job arguments have length 1. Passing the trailing
// lengths also supports gfortran-built LAPACK; OpenBLAS builds not using them
// ignore these extra ABI arguments. Aer itself supplies the pointer arguments.
using Gesvd = void (*)(const char *, const char *, const Integer *,
                      const Integer *, Complex *, const Integer *, double *,
                      Complex *, const Integer *, Complex *, const Integer *,
                      Complex *, const Integer *, double *, Integer *,
                      std::size_t, std::size_t);
using Gesdd = void (*)(const char *, const Integer *, const Integer *, Complex *,
                      const Integer *, double *, Complex *, const Integer *,
                      Complex *, const Integer *, Complex *, const Integer *,
                      double *, Integer *, Integer *, std::size_t);

void diagnostic_write(const char *message, std::size_t length) noexcept {
  std::size_t offset = 0;
  while (offset < length) {
    const auto written = ::write(STDERR_FILENO, message + offset, length - offset);
    if (written < 0 && errno == EINTR)
      continue;
    if (written <= 0)
      return; // The recorder's fatal path must not recurse on stderr failure.
    offset += static_cast<std::size_t>(written);
  }
}

[[noreturn]] void fatal(const char *message) noexcept {
  static constexpr char prefix[] = "cpu_lapack_interposer: ";
  // Avoid iostream initialization, heap allocation and any LAPACK/BLAS calls.
  diagnostic_write(prefix, sizeof(prefix) - 1);
  diagnostic_write(message, std::strlen(message));
  diagnostic_write("\n", 1);
  std::_Exit(86);
}

thread_local bool resolving = false;
thread_local unsigned int nesting = 0;

template <typename Function> Function resolve(const char *symbol) {
  if (resolving)
    fatal("recursive LAPACK symbol resolution");
  resolving = true;
  (void)::dlerror();
  void *address = ::dlsym(RTLD_NEXT, symbol);
  const char *error = ::dlerror();
  if (error != nullptr || address == nullptr) {
    diagnostic_write(symbol, std::strlen(symbol));
    diagnostic_write(": ", 2);
    fatal("cannot resolve original symbol via RTLD_NEXT; preload the absolute "
          "LP64 OpenBLAS library after this interposer");
  }
  resolving = false;
  return reinterpret_cast<Function>(address); // POSIX dlsym function ABI.
}

struct NestingGuard {
  NestingGuard() noexcept { ++nesting; }
  ~NestingGuard() noexcept { --nesting; }
  NestingGuard(const NestingGuard &) = delete;
  NestingGuard &operator=(const NestingGuard &) = delete;
};

struct Profile {
  int descriptor = -1;
  std::mutex mutex;
  std::uint64_t next_id = 0;

  Profile() {
    const char *path = std::getenv("AER_CPU_LAPACK_PROFILE_PATH");
    if (path == nullptr || path[0] == '\0')
      return;
    using OpenblasConfig = const char *(*)();
    const auto configuration = reinterpret_cast<OpenblasConfig>(
        ::dlsym(RTLD_NEXT, "openblas_get_config"));
    if (configuration == nullptr)
      fatal("profiling requires the system LP64 OpenBLAS configuration symbol");
    const char *settings = configuration();
    if (settings == nullptr || std::strstr(settings, "USE64BITINT") != nullptr)
      fatal("profiling requires LP64 OpenBLAS; ILP64 is unsupported");
    descriptor = ::open(path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    if (descriptor < 0)
      fatal("cannot open AER_CPU_LAPACK_PROFILE_PATH for append");
  }
  ~Profile() noexcept {
    if (descriptor >= 0)
      (void)::close(descriptor);
  }
};

Profile &profile() {
  try {
    static Profile instance;
    return instance;
  } catch (...) {
    fatal("cannot initialize diagnostic recorder");
  }
}

timespec now() noexcept {
  timespec value{};
  if (::clock_gettime(CLOCK_MONOTONIC, &value) != 0)
    fatal("CLOCK_MONOTONIC failed");
  return value;
}

void integer_json(std::ostream &out, const Integer *value) {
  if (value == nullptr)
    out << "null";
  else
    out << *value;
}

void job_json(std::ostream &out, const char *job) {
  if (job == nullptr) {
    out << "null";
    return;
  }
  // Encode exactly the first byte, including unusual jobs, without invalid JSON.
  static constexpr char hex[] = "0123456789abcdef";
  const auto value = static_cast<unsigned char>(*job);
  out << "\"\\u00" << hex[value >> 4] << hex[value & 15] << "\"";
}

void record(Profile &sink, const char *routine, const char *jobu,
            const char *jobvt, const char *jobz, const Integer *m,
            const Integer *n, const Integer *lda, const Integer *ldu,
            const Integer *ldvt, const Integer *lwork, const Integer *info,
            const timespec &start, const timespec &finish) noexcept {
  try {
    std::lock_guard<std::mutex> lock(sink.mutex);
    const double seconds = static_cast<double>(finish.tv_sec - start.tv_sec) +
                           static_cast<double>(finish.tv_nsec - start.tv_nsec) *
                               1.0e-9;
    if (seconds < 0.0)
      fatal("negative monotonic LAPACK interval");
    std::ostringstream out;
    out.imbue(std::locale::classic());
    out << std::setprecision(17)
        << "{\"schema_version\":1,\"event\":\"cpu_lapack_call\",\"routine\":\""
        << routine << "\",\"call_id\":" << ++sink.next_id
        << ",\"pid\":" << ::getpid() << ",\"tid\":"
        << ::syscall(SYS_gettid) << ",\"m\":";
    integer_json(out, m);
    out << ",\"n\":";
    integer_json(out, n);
    out << ",\"lda\":";
    integer_json(out, lda);
    out << ",\"ldu\":";
    integer_json(out, ldu);
    out << ",\"ldvt\":";
    integer_json(out, ldvt);
    out << ",\"jobu\":";
    job_json(out, jobu);
    out << ",\"jobvt\":";
    job_json(out, jobvt);
    out << ",\"jobz\":";
    job_json(out, jobz);
    out << ",\"lwork\":";
    integer_json(out, lwork);
    out << ",\"phase\":\""
        << ((lwork != nullptr && *lwork == -1) ? "workspace_query"
                                              : "factorization")
        << "\",\"info\":";
    integer_json(out, info);
    out << ",\"host_wall_seconds\":" << seconds
        << ",\"clock\":\"CLOCK_MONOTONIC\",\"nested_calls_suppressed\":true}\n";
    const std::string line = out.str();
    int result;
    do {
      result = ::flock(sink.descriptor, LOCK_EX);
    } while (result < 0 && errno == EINTR);
    if (result < 0)
      fatal("cannot lock diagnostic output");
    std::size_t offset = 0;
    while (offset < line.size()) {
      const auto written = ::write(sink.descriptor, line.data() + offset,
                                   line.size() - offset);
      if (written < 0 && errno == EINTR)
        continue;
      if (written <= 0)
        fatal("cannot write complete diagnostic event");
      offset += static_cast<std::size_t>(written);
    }
    do {
      result = ::flock(sink.descriptor, LOCK_UN);
    } while (result < 0 && errno == EINTR);
    if (result < 0)
      fatal("cannot unlock diagnostic output");
  } catch (...) {
    fatal("cannot serialize diagnostic event");
  }
}

template <typename Call>
void dispatch(Call call, int entry_errno, const char *routine, const char *jobu,
              const char *jobvt, const char *jobz, const Integer *m,
              const Integer *n, const Integer *lda, const Integer *ldu,
              const Integer *ldvt, const Integer *lwork, const Integer *info) {
  // A nested original implementation is part of its outer LAPACK phase. Avoid
  // double-counting it and prevent recursion through the recorder itself.
  if (nesting != 0) {
    errno = entry_errno;
    call();
    return;
  }
  NestingGuard guard;
  Profile &sink = profile();
  if (sink.descriptor < 0) {
    errno = entry_errno;
    call();
    return;
  }
  const timespec start = now();
  errno = entry_errno;
  call(); // Keep original arguments, outputs, info and exception behavior.
  const int result_errno = errno;
  const timespec finish = now();
  record(sink, routine, jobu, jobvt, jobz, m, n, lda, ldu, ldvt, lwork,
         info, start, finish);
  errno = result_errno;
}
} // namespace

extern "C" __attribute__((visibility("default"))) void
zgesvd_(const char *jobu, const char *jobvt, const Integer *m, const Integer *n,
        Complex *a, const Integer *lda, double *s, Complex *u,
        const Integer *ldu, Complex *vt, const Integer *ldvt, Complex *work,
        const Integer *lwork, double *rwork, Integer *info) {
  const int entry_errno = errno;
  if (resolving)
    fatal("recursive zgesvd_ symbol resolution");
  static const Gesvd original = resolve<Gesvd>("zgesvd_");
  dispatch([&] { original(jobu, jobvt, m, n, a, lda, s, u, ldu, vt, ldvt, work,
                          lwork, rwork, info, 1, 1); },
           entry_errno, "zgesvd_", jobu, jobvt, nullptr, m, n, lda, ldu, ldvt,
           lwork, info);
}

extern "C" __attribute__((visibility("default"))) void
zgesdd_(const char *jobz, const Integer *m, const Integer *n, Complex *a,
        const Integer *lda, double *s, Complex *u, const Integer *ldu,
        Complex *vt, const Integer *ldvt, Complex *work, const Integer *lwork,
        double *rwork, Integer *iwork, Integer *info) {
  const int entry_errno = errno;
  if (resolving)
    fatal("recursive zgesdd_ symbol resolution");
  static const Gesdd original = resolve<Gesdd>("zgesdd_");
  dispatch([&] { original(jobz, m, n, a, lda, s, u, ldu, vt, ldvt, work, lwork,
                          rwork, iwork, info, 1); },
           entry_errno, "zgesdd_", nullptr, nullptr, jobz, m, n, lda, ldu, ldvt,
           lwork, info);
}
