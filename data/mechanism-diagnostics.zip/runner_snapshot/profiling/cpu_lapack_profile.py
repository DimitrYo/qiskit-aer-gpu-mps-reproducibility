#!/usr/bin/env python3
"""Build and verify the optional diagnostic interposer; no Aer benchmark runs.

The verification uses ctypes and scalar reconstruction, without NumPy/BLAS
validation calls. Both commands are deliberately explicit; importing does
nothing. Do not invoke either while a production timing experiment is active.
"""

from __future__ import annotations

import argparse
from collections import Counter
from collections.abc import Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
from threading import Barrier


SOURCE = Path(__file__).with_name("cpu_lapack_interposer.cpp")
PROFILE_VARIABLE = "AER_CPU_LAPACK_PROFILE_PATH"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def require_platform() -> None:
    if sys.platform != "linux" or platform.machine() not in {"x86_64", "AMD64"}:
        raise ValueError("diagnostic build/verification requires Linux x86-64 LP64 OpenBLAS")


def summarize_cpu_lapack_records(records, *, expected_factor_shapes=None) -> dict:
    """Validate observed P3 events, optionally reconcile the audited Aer policy.

    Passing expected_factor_shapes is a caller assertion that the source and
    circuit permit complete independent coverage: each supplied (m, n) is one
    native CPU csvd_wrapper decision, mps_lapack=True, and no unrecorded
    initialization path. The audited policy is GESDD query+factor for m,n>=64,
    otherwise GESVD factor only. Without this independent expectation, event
    coverage remains unverified, including when the observed stream is empty.
    """
    if not isinstance(records, Sequence) or isinstance(records, (str, bytes)):
        raise ValueError("records must be an explicit sequence")
    phases = ("workspace_query", "factorization")
    routines = ("zgesvd_", "zgesdd_")
    seen = set()
    process_ids = {}
    grouped = {}
    actual = Counter()

    def integer(value, name, minimum=1):
        if type(value) is not int or value < minimum:
            raise ValueError(f"{name} must be an integer >= {minimum}")
        return value

    for row in records:
        if not isinstance(row, Mapping):
            raise ValueError("each LAPACK event must be an object")
        if type(row.get("schema_version")) is not int or row["schema_version"] != 1 or row.get("event") != "cpu_lapack_call":
            raise ValueError("unsupported LAPACK event schema")
        routine, phase = row.get("routine"), row.get("phase")
        if routine not in routines or phase not in phases:
            raise ValueError("unsupported LAPACK routine or phase")
        m, n = integer(row.get("m"), "m"), integer(row.get("n"), "n")
        lda, ldu, ldvt = (integer(row.get(key), key) for key in ("lda", "ldu", "ldvt"))
        if lda < m:
            raise ValueError("LAPACK lda is smaller than m")
        lwork = row.get("lwork")
        if type(lwork) is not int or (lwork != -1 and lwork < 1):
            raise ValueError("lwork must be -1 (query) or a positive integer")
        if (lwork == -1) != (phase == "workspace_query"):
            raise ValueError("phase does not match lwork")
        if type(row.get("info")) is not int or row["info"] != 0:
            raise ValueError("production diagnostic LAPACK call did not return info=0")
        if row.get("clock") != "CLOCK_MONOTONIC" or row.get("nested_calls_suppressed") is not True:
            raise ValueError("unsupported LAPACK interval semantics")
        seconds = row.get("host_wall_seconds")
        if type(seconds) not in (int, float):
            raise ValueError("host wall duration must be finite and nonnegative")
        try:
            seconds = float(seconds)
        except OverflowError as error:
            raise ValueError("host wall duration is not representable") from error
        if not math.isfinite(seconds) or seconds < 0:
            raise ValueError("host wall duration must be finite and nonnegative")
        pid = integer(row.get("pid"), "pid")
        integer(row.get("tid"), "tid")
        call_id = integer(row.get("call_id"), "call_id")
        if (pid, call_id) in seen:
            raise ValueError("duplicate LAPACK pid/call_id")
        seen.add((pid, call_id))
        process_ids.setdefault(pid, []).append(call_id)
        jobs = ("jobu", "jobvt") if routine == "zgesvd_" else ("jobz",)
        unused = ("jobz",) if routine == "zgesvd_" else ("jobu", "jobvt")
        if any(key not in row for key in ("jobu", "jobvt", "jobz")):
            raise ValueError("LAPACK job fields must be explicitly present")
        if any(row.get(key) is not None for key in unused):
            raise ValueError("irrelevant LAPACK job fields must be null")
        if any(type(row.get(key)) is not str or len(row[key]) != 1 or
               row[key].upper() not in {"A", "S", "O", "N"} for key in jobs):
            raise ValueError("invalid LAPACK job option")
        if routine == "zgesvd_":
            if row["jobu"].upper() in {"A", "S"} and ldu < m:
                raise ValueError("LAPACK ldu is too small for requested U")
            required_vt = n if row["jobvt"].upper() == "A" else min(m, n)
            if row["jobvt"].upper() in {"A", "S"} and ldvt < required_vt:
                raise ValueError("LAPACK ldvt is too small for requested VT")
        elif row["jobz"].upper() in {"A", "S"}:
            required_vt = n if row["jobz"].upper() == "A" else min(m, n)
            if ldu < m or ldvt < required_vt:
                raise ValueError("GESDD output leading dimensions are too small")
        key = (routine, m, n, phase)
        actual[key] += 1
        grouped.setdefault(key, []).append(float(seconds))
    for ids in process_ids.values():
        if sorted(ids) != list(range(1, len(ids) + 1)):
            raise ValueError("LAPACK process-local call IDs are incomplete")

    coverage = "unverified_independent_coverage"
    if expected_factor_shapes is not None:
        if not isinstance(expected_factor_shapes, Sequence) or isinstance(expected_factor_shapes, (str, bytes)):
            raise ValueError("expected factor shapes must be an explicit sequence")
        expected = Counter()
        for shape in expected_factor_shapes:
            if not isinstance(shape, Sequence) or isinstance(shape, (str, bytes)) or len(shape) != 2:
                raise ValueError("each expected factor shape must contain m and n")
            m, n = integer(shape[0], "expected m"), integer(shape[1], "expected n")
            routine = "zgesdd_" if m >= 64 and n >= 64 else "zgesvd_"
            expected[(routine, m, n, "factorization")] += 1
            if routine == "zgesdd_":
                expected[(routine, m, n, "workspace_query")] += 1
        if actual != expected:
            raise ValueError("LAPACK routine/shape/phase counts differ from audited Aer decision coverage")
        coverage = "matched_to_independent_aer_decisions"
    try:
        phase_seconds = {phase: math.fsum(seconds for key, values in grouped.items()
                                         if key[3] == phase for seconds in values)
                         for phase in phases}
        shape_rows = [{"routine": routine, "m": m, "n": n, "phase": phase,
                       "count": len(values), "host_wall_seconds": math.fsum(values)}
                      for (routine, m, n, phase), values in sorted(grouped.items())]
    except OverflowError as error:
        raise ValueError("LAPACK interval sum is not finite") from error
    return {
        "schema_version": 1, "measurement": "observed_cpu_lapack_host_wall",
        "coverage": coverage, "event_count": len(records),
        "factorization_count": sum(count for key, count in actual.items() if key[3] == "factorization"),
        "workspace_query_count": sum(count for key, count in actual.items() if key[3] == "workspace_query"),
        "process_count": len(process_ids),
        "routine_counts": {routine: {phase: sum(count for key, count in actual.items()
                                               if key[0] == routine and key[3] == phase)
                                     for phase in phases} for routine in routines},
        "phase_wall_seconds": phase_seconds, "shape_phases": shape_rows,
        "scope": "Observed LAPACK intervals only. Concurrent intervals may overlap; "
                 "sums are not process elapsed time. Empty logs without independent "
                 "coverage do not establish zero LAPACK work.",
    }


def build(output: Path, compiler: str) -> dict:
    require_platform()
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    compiler_path = shutil.which(compiler)
    if compiler_path is None:
        raise ValueError(f"compiler is unavailable: {compiler}")
    command = [compiler_path, "-std=c++17", "-O2", "-fPIC", "-shared", "-pthread",
               "-fvisibility=hidden", "-Wall", "-Wextra", "-Werror", str(SOURCE.resolve()),
               "-o", str(output), "-ldl"]
    subprocess.run(command, check=True)
    report = {
        "schema_version": 1, "artifact_kind": "diagnostic_only_cpu_lapack_interposer",
        "source": {"path": str(SOURCE.resolve()), "sha256": sha256(SOURCE)},
        "interposer": {"path": str(output), "sha256": sha256(output)},
        "build_command": command,
        "compiler_version": subprocess.run([compiler_path, "--version"], check=True,
                                           text=True, capture_output=True).stdout,
        "platform": platform.platform(), "lapack_integer_bits": 32,
        "timing_use_permitted": False,
    }
    write_json(output.with_suffix(output.suffix + ".build.json"), report)
    return report


class Complex(ctypes.Structure):
    _fields_ = [("real", ctypes.c_double), ("imag", ctypes.c_double)]


def _complex_array(values: list[complex]):
    return (Complex * len(values))(*(Complex(value.real, value.imag) for value in values))


def _value(value: Complex) -> complex:
    return complex(value.real, value.imag)


def _factor(library, routine: str, rows: int, cols: int, worker: int) -> dict:
    integer = ctypes.c_int32
    ptr_integer = ctypes.POINTER(integer)
    ptr_complex = ctypes.POINTER(Complex)
    ptr_double = ctypes.POINTER(ctypes.c_double)
    function = getattr(library, routine)
    common = [ptr_integer, ptr_integer, ptr_complex, ptr_integer, ptr_double,
              ptr_complex, ptr_integer, ptr_complex, ptr_integer, ptr_complex,
              ptr_integer, ptr_double]
    function.argtypes = ([ctypes.c_char_p, ctypes.c_char_p] + common +
                         [ptr_integer, ctypes.c_size_t, ctypes.c_size_t]
                         if routine == "zgesvd_" else
                         [ctypes.c_char_p] + common +
                         [ptr_integer, ptr_integer, ctypes.c_size_t])
    function.restype = None
    original = [complex((row + 1) * (col + 2) + (row == col),
                        (row - col) * 0.25 + worker * 0.125)
                for col in range(cols) for row in range(rows)]
    a = _complex_array(original)
    m, n, lda, ldu, ldvt = map(integer, [rows, cols, rows, rows, cols])
    minimum = min(rows, cols)
    s = (ctypes.c_double * minimum)()
    u = (Complex * (rows * rows))()
    vt = (Complex * (cols * cols))()
    rwork = (ctypes.c_double * 4096)()
    iwork = (integer * (8 * minimum))()
    lwork, info = integer(-1), integer(12345)
    work = (Complex * 1)()

    def invoke() -> None:
        args = [ctypes.byref(m), ctypes.byref(n), a, ctypes.byref(lda), s, u,
                ctypes.byref(ldu), vt, ctypes.byref(ldvt), work, ctypes.byref(lwork), rwork]
        if routine == "zgesvd_":
            function(b"A", b"A", *args, ctypes.byref(info), 1, 1)
        else:
            function(b"A", *args, iwork, ctypes.byref(info), 1)

    invoke()
    query_info = info.value
    if query_info != 0 or not math.isfinite(work[0].real) or work[0].real < 1:
        raise ValueError(f"invalid real LAPACK workspace query: {routine}, info={query_info}")
    lwork = integer(math.ceil(work[0].real))
    work = (Complex * lwork.value)()
    a = _complex_array(original)
    info = integer(12345)
    invoke()
    if info.value != 0:
        raise ValueError(f"real LAPACK factorization failed: {routine}, info={info.value}")
    error = max(abs(sum(_value(u[row + k * rows]) * s[k] *
                        _value(vt[k + col * cols]) for k in range(minimum)) -
                    original[row + col * rows])
                for col in range(cols) for row in range(rows))
    if error > 1e-10:
        raise ValueError(f"scalar SVD reconstruction failed: {routine}, max error={error}")
    return {"worker": worker, "routine": routine, "m": rows, "n": cols,
            "query_info": query_info, "factor_info": info.value, "lwork": lwork.value,
            "singular_values": list(s), "max_reconstruction_error": error}


def _invalid_query(library, routine: str) -> dict:
    # LAPACK must return its own negative INFO for an invalid M, unchanged by
    # the interposer. XERBLA may print; probe output is written to a JSON file.
    integer = ctypes.c_int32
    m, n, lda, ldu, ldvt = map(integer, [-1, 2, 1, 1, 2])
    a, u, vt, work = ((Complex * length)() for length in (2, 2, 4, 1))
    s, rwork = (ctypes.c_double * 2)(), (ctypes.c_double * 4096)()
    iwork, lwork, info = (integer * 16)(), integer(-1), integer(12345)
    args = [ctypes.byref(m), ctypes.byref(n), a, ctypes.byref(lda), s, u,
            ctypes.byref(ldu), vt, ctypes.byref(ldvt), work, ctypes.byref(lwork), rwork]
    function = getattr(library, routine) # Signature set by the valid cases.
    if routine == "zgesvd_":
        function(b"A", b"A", *args, ctypes.byref(info), 1, 1)
        expected_info = -3
    else:
        function(b"A", *args, iwork, ctypes.byref(info), 1)
        expected_info = -2
    if info.value != expected_info:
        raise ValueError(f"invalid LAPACK argument status changed: {routine}, info={info.value}")
    return {"routine": routine, "m": -1, "n": 2, "query_info": info.value}


def _probe(lapack: Path, output: Path) -> None:
    require_platform()
    # The target is already preloaded globally. CDLL(None) exercises the actual
    # interposition instead of resolving zgesvd_ directly on a LAPACK handle.
    library = ctypes.CDLL(None)
    config = library.openblas_get_config
    config.restype = ctypes.c_char_p
    config.argtypes = []
    configuration = config().decode("ascii", errors="strict")
    if "USE64BITINT" in configuration.upper():
        raise ValueError("ILP64 OpenBLAS is unsupported; require 32-bit Fortran INTEGER")
    barrier = Barrier(2)

    def worker_cases(worker):
        barrier.wait()
        return [_factor(library, routine, rows, cols, worker)
                for routine in ("zgesvd_", "zgesdd_")
                for rows, cols in ((3, 2), (2, 3))]

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = [row for group in pool.map(worker_cases, range(2)) for row in group]
    write_json(output, {"lapack_library": str(lapack), "openblas_config": configuration,
                        "results": results,
                        "invalid_argument_results": [_invalid_query(library, routine)
                                                     for routine in ("zgesvd_", "zgesdd_")]})


def _run_probe(lapack: Path, output: Path, interposer: Path | None,
               profile_path: Path | None, *, empty_flag: bool = False) -> dict:
    environment = os.environ.copy()
    # Controlled child only; no shell interpolation and no ambient preload.
    environment.pop("LD_PRELOAD", None)
    environment.pop(PROFILE_VARIABLE, None)
    environment["LD_PRELOAD"] = (f"{interposer}:{lapack}" if interposer else str(lapack))
    environment.update({"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1",
                        "GOTO_NUM_THREADS": "1"})
    if profile_path is not None:
        environment[PROFILE_VARIABLE] = str(profile_path)
    elif empty_flag:
        environment[PROFILE_VARIABLE] = ""
    process = subprocess.run([sys.executable, str(Path(__file__).resolve()), "_probe",
                              "--lapack-library", str(lapack), "--output", str(output)],
                             env=environment, capture_output=True, text=True)
    if process.returncode:
        raise ValueError(f"LAPACK probe failed ({process.returncode}): {process.stderr}")
    return json.loads(output.read_text(encoding="utf-8"))


def verify(interposer: Path, lapack: Path, output: Path) -> dict:
    require_platform()
    interposer, lapack = interposer.resolve(strict=True), lapack.resolve(strict=True)
    if any(":" in str(path) or any(char.isspace() for char in str(path))
           for path in (interposer, lapack)):
        raise ValueError("LD_PRELOAD library paths must not contain colon or whitespace")
    build_manifest_path = interposer.with_suffix(interposer.suffix + ".build.json")
    build_manifest = json.loads(build_manifest_path.read_text(encoding="utf-8"))
    if build_manifest["source"]["sha256"] != sha256(SOURCE):
        raise ValueError("interposer source changed since build")
    if build_manifest["interposer"]["sha256"] != sha256(interposer):
        raise ValueError("interposer library hash differs from build manifest")
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="lapack_profile_verify_", dir=output.parent) as temp:
        work = Path(temp)
        baseline = _run_probe(lapack, work / "baseline.json", None, None)
        disabled = _run_probe(lapack, work / "disabled.json", interposer, None)
        empty = _run_probe(lapack, work / "empty.json", interposer, None, empty_flag=True)
        events_path = work / "events.jsonl"
        enabled = _run_probe(lapack, work / "enabled.json", interposer, events_path)
        for name, observed in (("disabled", disabled), ("empty", empty), ("enabled", enabled)):
            if observed != baseline:
                raise ValueError(f"interposer changed real LAPACK outputs in {name} mode")
        events = [json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines()]
        if len(events) != 18:
            raise ValueError(f"expected 18 real LAPACK events, found {len(events)}")
        if sorted(event["call_id"] for event in events) != list(range(1, 19)):
            raise ValueError("interposer call IDs are missing or duplicated")
        if len({event["tid"] for event in events if event["m"] > 0}) != 2:
            raise ValueError("real LAPACK verification did not cover two calling threads")
        expected = Counter((routine, m, n, phase)
                           for _ in range(2) for routine in ("zgesvd_", "zgesdd_")
                           for m, n in ((3, 2), (2, 3))
                           for phase in ("workspace_query", "factorization"))
        expected.update((routine, -1, 2, "workspace_query")
                        for routine in ("zgesvd_", "zgesdd_"))
        actual = Counter((row["routine"], row["m"], row["n"], row["phase"]) for row in events)
        if actual != expected:
            raise ValueError("LAPACK event routine/shape/phase counts differ from actual calls")
        for row in events:
            expected_info = (-3 if row["routine"] == "zgesvd_" else -2) if row["m"] == -1 else 0
            leading_rows = max(1, row["m"])
            if row["info"] != expected_info or row["lda"] != leading_rows or row["ldu"] != leading_rows or row["ldvt"] != row["n"]:
                raise ValueError("LAPACK event status or leading dimensions are incorrect")
            seconds = row["host_wall_seconds"]
            if not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or seconds < 0:
                raise ValueError("LAPACK event duration must be finite and nonnegative")
            if (row["lwork"] == -1) != (row["phase"] == "workspace_query"):
                raise ValueError("workspace query is mislabeled")
            if row["routine"] == "zgesvd_" and (row["jobu"], row["jobvt"], row["jobz"]) != ("A", "A", None):
                raise ValueError("GESVD job metadata is incorrect")
            if row["routine"] == "zgesdd_" and (row["jobu"], row["jobvt"], row["jobz"]) != (None, None, "A"):
                raise ValueError("GESDD job metadata is incorrect")
        event_output = output.with_suffix(".events.jsonl")
        shutil.copyfile(events_path, event_output)
    report = {
        "schema_version": 1, "verification": "PASS", "production_benchmark": False,
        "build_manifest": {"path": str(build_manifest_path), "sha256": sha256(build_manifest_path)},
        "source": {"path": str(SOURCE.resolve()), "sha256": sha256(SOURCE)},
        "verification_driver": {"path": str(Path(__file__).resolve()), "sha256": sha256(Path(__file__))},
        "interposer": {"path": str(interposer), "sha256": sha256(interposer)},
        "lapack_library": {"path": str(lapack), "sha256": sha256(lapack)},
        "openblas_config": baseline["openblas_config"],
        "original_outputs_unchanged": True, "disabled_and_empty_flag_verified": True,
        "two_calling_threads_verified": True,
        "event_count": len(events), "expected_event_count": 18,
        "thread_ids": sorted({row["tid"] for row in events}),
        "status_counts": dict(Counter(str(row["info"]) for row in events)),
        "phase_wall_seconds": {phase: math.fsum(row["host_wall_seconds"] for row in events
                                               if row["phase"] == phase)
                               for phase in ("workspace_query", "factorization")},
        "events": {"path": str(event_output), "sha256": sha256(event_output)},
        "cases": baseline["results"],
        "invalid_argument_cases": baseline["invalid_argument_results"],
        "scope": "Tiny real LAPACK integration check only; no Aer performance claim. "
                 "Concurrent call sums can overlap and are not process elapsed time.",
    }
    write_json(output, report)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build_parser = commands.add_parser("build")
    build_parser.add_argument("--output", required=True, type=Path)
    build_parser.add_argument("--compiler", default="c++")
    verify_parser = commands.add_parser("verify")
    verify_parser.add_argument("--interposer", required=True, type=Path)
    verify_parser.add_argument("--lapack-library", required=True, type=Path)
    verify_parser.add_argument("--output", required=True, type=Path)
    probe_parser = commands.add_parser("_probe", help=argparse.SUPPRESS)
    probe_parser.add_argument("--lapack-library", required=True, type=Path)
    probe_parser.add_argument("--output", required=True, type=Path)
    arguments = parser.parse_args()
    if arguments.command == "build":
        result = build(arguments.output, arguments.compiler)
    elif arguments.command == "verify":
        result = verify(arguments.interposer, arguments.lapack_library, arguments.output)
    else:
        _probe(arguments.lapack_library, arguments.output)
        return
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
