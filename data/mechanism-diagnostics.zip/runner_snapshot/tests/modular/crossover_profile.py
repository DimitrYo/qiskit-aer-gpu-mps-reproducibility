"""Validation and deterministic summaries for opt-in cuTensorNet SVD profiles."""

from __future__ import annotations

import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


PROFILE_EVENT = "cutensor_csvd_profile"
TIMING_FIELDS = ("host_to_device_ms", "svd_ms", "device_to_host_ms", "synchronize_ms")
BOOLEAN_FIELDS = ("matrix_buffers_grew", "device_workspace_grew", "host_workspace_grew")


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path}:{number} is not a JSON object")
        records.append(value)
    return records


def validate_records(records: list[dict[str, Any]], *, threshold: int) -> list[str]:
    errors: list[str] = []
    if not records:
        return ["profile contains no records"]
    for number, record in enumerate(records, start=1):
        prefix = f"profile record {number}"
        if record.get("event") != PROFILE_EVENT:
            errors.append(f"{prefix} has an unexpected event")
        for field in ("rows", "columns", "matrix_buffer_capacity_bytes", "device_workspace_bytes", "host_workspace_bytes", "dispatch_threshold_elements"):
            value = record.get(field)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                errors.append(f"{prefix} lacks non-negative integer {field}")
        if isinstance(record.get("rows"), int) and int(record["rows"]) < 1:
            errors.append(f"{prefix} rows must be positive")
        if isinstance(record.get("columns"), int) and int(record["columns"]) < 1:
            errors.append(f"{prefix} columns must be positive")
        if record.get("dispatch_threshold_elements") != threshold:
            errors.append(f"{prefix} has a mismatched dispatch threshold")
        for field in TIMING_FIELDS:
            value = record.get(field)
            if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)) or float(value) < 0:
                errors.append(f"{prefix} lacks non-negative finite {field}")
        for field in BOOLEAN_FIELDS:
            if not isinstance(record.get(field), bool):
                errors.append(f"{prefix} lacks boolean {field}")
        if record.get("algorithm") not in {"GESVD", "GESVDR"}:
            errors.append(f"{prefix} has an unknown TensorSVD algorithm")
    return errors


def _distribution(values: list[float]) -> dict[str, float | int]:
    return {
        "count": len(values),
        "median_ms": statistics.median(values),
        "mean_ms": statistics.fmean(values),
        "minimum_ms": min(values),
        "maximum_ms": max(values),
        "sample_standard_deviation_ms": statistics.stdev(values) if len(values) > 1 else 0.0,
    }


def summarize(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize phase costs by exact matrix shape without fabricating calls."""
    groups: dict[tuple[int, int], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        groups[(int(record["rows"]), int(record["columns"]))].append(record)
    shapes: list[dict[str, Any]] = []
    for (rows, columns), group in sorted(groups.items()):
        phases = {field: _distribution([float(record[field]) for record in group]) for field in TIMING_FIELDS}
        boundary = [
            float(record["host_to_device_ms"]) + float(record["device_to_host_ms"])
            + float(record["synchronize_ms"])
            for record in group
        ]
        measured = [boundary_value + float(record["svd_ms"])
                    for boundary_value, record in zip(boundary, group)]
        shapes.append({
            "rows": rows, "columns": columns, "profile_record_count": len(group),
            "phases": phases,
            "gpu_boundary_overhead_ms": _distribution(boundary),
            "measured_gpu_phase_ms": _distribution(measured),
            "median_boundary_fraction_of_measured_gpu_phase": (
                statistics.median(value / total for value, total in zip(boundary, measured))
                if measured else 0.0
            ),
            "matrix_buffer_growth_count": sum(bool(record["matrix_buffers_grew"]) for record in group),
            "device_workspace_growth_count": sum(bool(record["device_workspace_grew"]) for record in group),
            "host_workspace_growth_count": sum(bool(record["host_workspace_grew"]) for record in group),
            "algorithms": sorted({str(record["algorithm"]) for record in group}),
            "dispatch_threshold_elements": sorted({int(record["dispatch_threshold_elements"]) for record in group}),
        })
    phase_totals = {field: sum(float(record[field]) for record in records) for field in TIMING_FIELDS}
    boundary_total = (phase_totals["host_to_device_ms"] + phase_totals["device_to_host_ms"]
                      + phase_totals["synchronize_ms"])
    measured_total = boundary_total + phase_totals["svd_ms"]
    return {
        "profile_record_count": len(records),
        "matrix_shapes": shapes,
        "algorithms": sorted({str(record["algorithm"]) for record in records}),
        "dispatch_threshold_elements": sorted({int(record["dispatch_threshold_elements"]) for record in records}),
        "phase_totals_ms": phase_totals,
        "gpu_boundary_overhead": {
            "definition": "host_to_device_ms + device_to_host_ms + synchronize_ms",
            "total_ms": boundary_total,
            "fraction_of_measured_gpu_phase": boundary_total / measured_total if measured_total else 0.0,
            "interpretation": "Instrumented diagnostic composition only; not an end-to-end timing sample.",
        },
    }
