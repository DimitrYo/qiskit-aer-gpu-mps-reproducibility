#!/usr/bin/env python3
"""Freeze and collect the separate sixteen-call P3 diagnostic campaign.

Preparation archives inputs and code without executing Aer. Collection invokes
only the archived single-call driver, sequentially, in new output directories.
Run this outside every P1/P2 timing session. Recorded-data validation is a
separate pure operation and needs no GPU or original absolute library paths.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys

HERE = Path(__file__).resolve().parent
EXPERIMENT = HERE.parents[1]
PINNED_SOURCE = "a1242579272784330b217085fe11b7e1481922ad"
INPUT_IDS = ("bw_n14_pilot_s100000", "bw_n16_pilot_s102000",
             "pqft_n16_pilot_s104000", "bw_n18_pilot_s103000")
RUNNERS = ("run_scientific_profile_campaign.py", "run_scientific_mps_profile.py",
           "validate_scientific_mps_profile.py", "run_e2_numerical_correctness_pilot.py",
           "mps_execution_environment.py", "scientific_circuit_inputs.py", "crossover_profile.py")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def prepare(pilot_dir, run_dir, verification_path):
    from run_scientific_mps_profile import SOURCE_FILES, verify_source
    from scientific_circuit_inputs import load_scientific_manifest

    if run_dir.exists():
        raise RuntimeError("refusing to overwrite a P3 campaign or failed attempt")
    p2 = read(pilot_dir / "contract.json")
    gate = read(pilot_dir / "correctness_gate.json")
    if (p2["stage"] != "P2_PILOT" or gate["status"] != "PASS"
            or gate["contract_sha256"] != digest(pilot_dir / "contract.json")):
        raise RuntimeError("P3 needs the frozen P2 pilot with a passing correctness gate")
    manifest = load_scientific_manifest(pilot_dir / "manifest.json", expected_stage="pilot")
    if manifest["manifest_sha256"] != p2["manifest_sha256"]:
        raise RuntimeError("pilot manifest differs from its frozen P2 contract")
    selected = [spec for spec in manifest["circuits"] if spec["id"] in INPUT_IDS]
    if len(selected) != 4 or any(spec["ensemble_index"] != 0 for spec in selected):
        raise RuntimeError("preselected pilot inputs are missing")
    candidate = next(c for c in p2["candidates"] if c["role"] == "gpu")
    if candidate["source_revision"] != PINNED_SOURCE or not candidate["mps_lapack"]:
        raise RuntimeError("P3 source and LAPACK policy must match P2")
    source = verify_source(candidate["source_directory"])
    if digest(candidate["extension"]) != candidate["extension_sha256"]:
        raise RuntimeError("P3 candidate binary differs from P2")
    verification = read(verification_path)
    if verification.get("verification") != "PASS":
        raise RuntimeError("CPU LAPACK interposer verification has not passed")
    for key in ("source", "verification_driver", "build_manifest", "interposer", "lapack_library", "events"):
        if digest(verification[key]["path"]) != verification[key]["sha256"]:
            raise RuntimeError("interposer verification inputs changed: " + key)
    # Check every required source before creating even a partial preparation.
    for name in RUNNERS:
        if not (HERE / name).is_file():
            raise RuntimeError("missing P3 runner source: " + name)
    compiled = read(pilot_dir / "compiled_hashes.json")
    if any(input_id not in compiled for input_id in INPUT_IDS):
        raise RuntimeError("missing frozen P2 measured-graph hashes")
    run_dir.mkdir(parents=True)
    shutil.copyfile(pilot_dir / "manifest.json", run_dir / "manifest.json")
    p2_files = ("contract.json", "correctness_gate.json", "compiled_hashes.json")
    (run_dir / "p2_binding").mkdir()
    for name in p2_files:
        shutil.copyfile(pilot_dir / name, run_dir / "p2_binding" / name)
    files = [(HERE / name, "tests/modular/" + name) for name in RUNNERS]
    files += [(EXPERIMENT / "profiling" / name, "profiling/" + name)
              for name in ("cpu_lapack_profile.py", "cpu_lapack_interposer.cpp")]
    for src, relative in files:
        dst = run_dir / "runner_snapshot" / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    for name in SOURCE_FILES:
        dst = run_dir / "source_snapshot" / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(Path(candidate["source_directory"]) / name, dst)
    verification_files = {"verification": "cpu_lapack_verification.json",
                          "build": "interposer.build.json", "events": "cpu_lapack_verification.events.jsonl"}
    for key, src in (("verification", verification_path), ("build", verification["build_manifest"]["path"]),
                     ("events", verification["events"]["path"])):
        dst = run_dir / "profiler_verification" / verification_files[key]
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    policy = {"precision": "double", "max_bond_dimension": 1024, "truncation_threshold": 0.0,
              "mps_lapack": True, "threads": 6, "cpu_affinity": p2["cpu_affinity"],
              "seed_simulator": p2["seed_simulator"], "seed_transpiler": p2["seed_transpiler"],
              "runtime_versions": p2["runtime_versions"], "cpu_lapack_profile_devices": ["CPU", "GPU"]}
    campaign = {"schema_version": 1, "kind": "article2_p3_diagnostics",
        "prepared_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_revision": PINNED_SOURCE, "source_files_sha256": source["files_sha256"],
        "extension_sha256": candidate["extension_sha256"], "execution_candidate": candidate,
        "manifest_sha256": digest(run_dir / "manifest.json"),
        "scientific_manifest_sha256": manifest["manifest_sha256"],
        "p2_files_sha256": {name: digest(run_dir / "p2_binding" / name) for name in p2_files},
        "runner_files_sha256": {rel: digest(run_dir / "runner_snapshot" / rel) for _, rel in files},
        "profiler_verification_files": verification_files,
        "profiler_files_sha256": {name: digest(run_dir / "profiler_verification" / name)
                                  for name in verification_files.values()},
        "inputs": list(INPUT_IDS), "policy": policy,
        "expected_compiled_qasm_sha256": {key: compiled[key] for key in INPUT_IDS},
        "cells": [{"input_id": input_id, "device": device, "mode": mode,
                   "directory": f"cells/{input_id}/{device.lower()}_{mode}"}
                  for input_id in INPUT_IDS for mode in ("evolution", "shots100") for device in ("CPU", "GPU")],
        "performance_claims_permitted": False}
    write_new(run_dir / "campaign.json", campaign)
    print("PREPARED: P3 frozen; no diagnostic or timing executed")


def collect(run_dir, expected_campaign_sha256):
    if digest(run_dir / "campaign.json") != expected_campaign_sha256:
        raise RuntimeError("P3 campaign differs from its frozen launch hash")
    campaign = read(run_dir / "campaign.json")
    if (run_dir / "collection_manifest.json").exists() or (run_dir / "cells").exists():
        raise RuntimeError("refusing to reuse a started or completed diagnostic collection")
    for name, expected in campaign["runner_files_sha256"].items():
        if digest(run_dir / "runner_snapshot" / name) != expected:
            raise RuntimeError("archived P3 code changed: " + name)
    archived = run_dir / "runner_snapshot/tests/modular" / Path(__file__).name
    if Path(__file__).resolve() != archived.resolve():
        return subprocess.run([sys.executable, str(archived), "--collect", "--run-dir", str(run_dir),
                               "--expected-campaign-sha256", expected_campaign_sha256]).returncode
    candidate, policy = campaign["execution_candidate"], campaign["policy"]
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPATH"] = candidate["pythonpath"]
    env["LD_LIBRARY_PATH"] = ":".join(candidate["library_search_paths"])
    for key in ("LD_PRELOAD", "LD_AUDIT"):
        env.pop(key, None)
    (run_dir / "cells").mkdir()
    for cell in campaign["cells"]:
        output = run_dir / cell["directory"]
        output.parent.mkdir(parents=True, exist_ok=True)
        command = [candidate["python"], str(archived.parent / "run_scientific_mps_profile.py"),
            "--manifest", str(run_dir / "manifest.json"), "--input-ensemble", "independent",
            "--circuit-id", cell["input_id"], "--source", candidate["source_directory"],
            "--extension-path", candidate["extension"], "--extension-sha256", candidate["extension_sha256"],
            "--output", str(output), "--mode", cell["mode"], "--device", cell["device"],
            "--mps-lapack", "--threads", str(policy["threads"]),
            "--cpu-affinity", *map(str, policy["cpu_affinity"]),
            "--seed-simulator", str(policy["seed_simulator"]), "--seed-transpiler", str(policy["seed_transpiler"]),
            "--cpu-lapack-verification", str(run_dir / "profiler_verification" / campaign["profiler_verification_files"]["verification"]),
            "--cpu-lapack-profile-path", str(output / "cpu_lapack.jsonl")]
        print("[P3]", cell["input_id"], cell["device"], cell["mode"], flush=True)
        log_path = output.parent / (output.name + ".process.log")
        failure_reason = None
        returncode = 1
        try:
            with log_path.open("x", encoding="utf-8") as log:
                # The single-call driver itself launches the preloaded Aer child.
                # Keep both in a dedicated session so timeout cannot orphan it.
                process = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                                           start_new_session=True)
                try:
                    returncode = process.wait(timeout=3600)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait(timeout=5)
                    failure_reason = "3600-second diagnostic limit; dedicated process group terminated"
                    returncode = 124
        except OSError as error:
            failure_reason = str(error)
        if returncode:
            write_new(run_dir / "collection_failure.json", {"status": "FAIL", "cell": cell,
                      "returncode": returncode, "reason": failure_reason or "diagnostic process failed",
                      "performance_claims_permitted": False})
            return returncode
    write_new(run_dir / "collection_manifest.json", {
        "schema_version": 1,
        "campaign_sha256": digest(run_dir / "campaign.json"),
        "files_sha256": {path.relative_to(run_dir).as_posix(): digest(path)
                         for path in sorted(run_dir.rglob("*")) if path.is_file()
                         and path.name not in {"campaign.json", "collection_manifest.json", "validation.json"}
                         and "__pycache__" not in path.parts}})
    # Python cache files are not scientific output and are never inventoried.
    result = subprocess.run([candidate["python"], str(archived.parent / "validate_scientific_mps_profile.py"),
                             "--run-dir", str(run_dir)], text=True, capture_output=True)
    if result.returncode:
        print(result.stderr or result.stdout, file=sys.stderr)
        return result.returncode
    write_new(run_dir / "validation.json", json.loads(result.stdout))
    print("PASS: all sixteen P3 diagnostic calls and recorded-data validation completed")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--collect", action="store_true")
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--pilot-run-dir", type=Path)
    parser.add_argument("--cpu-lapack-verification", type=Path)
    parser.add_argument("--expected-campaign-sha256", help="required for collection; exact hash reviewed at preparation")
    args = parser.parse_args()
    try:
        if args.prepare:
            if args.pilot_run_dir is None or args.cpu_lapack_verification is None:
                raise RuntimeError("preparation requires pilot run and verified CPU profiler")
            prepare(args.pilot_run_dir.resolve(), args.run_dir.resolve(), args.cpu_lapack_verification.resolve())
            return 0
        if args.expected_campaign_sha256 is None:
            raise RuntimeError("collection requires the exact frozen --expected-campaign-sha256")
        return collect(args.run_dir.resolve(), args.expected_campaign_sha256)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        print("FAIL:", error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
