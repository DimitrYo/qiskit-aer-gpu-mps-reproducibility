#!/usr/bin/env python3
"""P3 diagnostics only: one source-bound circuit in one fresh process.

Evolution mode uses the existing non-mutating MPS bond-dimension log. It does
not insert MPS snapshots: those sort the live register and change its work.
Logical payload and requested-copy bytes are source-derived quantities, not
allocation, RSS, GPU utilization, or PCIe traffic measurements. No duration
from this driver is admissible as a P1/P2 timing sample or speedup estimate.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
from importlib import import_module
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys

from crossover_profile import TIMING_FIELDS, validate_records
from mps_execution_environment import DIAGNOSTIC_PATH_KEYS, prepare_mps_environment, assert_execution_environment
from run_e2_numerical_correctness_pilot import build_circuit, load_manifest, qasm_sha256

PINNED_REVISION = "a1242579272784330b217085fe11b7e1481922ad"
SOURCE_FILES = (
    "src/simulators/matrix_product_state/svd.cpp",
    "src/simulators/matrix_product_state/matrix_product_state.hpp",
    "src/simulators/matrix_product_state/matrix_product_state_internal.cpp",
    "src/simulators/matrix_product_state/matrix_product_state_tensor.hpp",
    "src/simulators/circuit_executor.hpp",
)
THREAD_KEYS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
PROFILE_SCOPES = (("brickwork", 14), ("brickwork", 16), ("qft_prepared", 16), ("brickwork", 18))
CPU_PROFILE_KEY = "AER_CPU_LAPACK_PROFILE_PATH"
LOG_TOKEN = re.compile(
    r"(?:(?:I(?P<number>\d+):(?P<name>[A-Za-z0-9_]+)|(?P<swap>internal_swap))"
    r" on qubits (?P<qubits>\d+(?:,\d+)*), BD=\[(?P<ranks>\d+(?: \d+)*)\],\s*"
    r"|discarded_value=(?P<discarded>[0-9.eE+\-]+),\s*)")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def verify_source(source):
    source = Path(source).resolve()
    revision = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
    dirty = subprocess.check_output(
        ["git", "-C", str(source), "status", "--porcelain", "--untracked-files=no"], text=True).strip()
    if revision != PINNED_REVISION or dirty:
        raise RuntimeError("P3 requires the clean pinned P0 source " + PINNED_REVISION)
    return {"directory": str(source), "revision": revision,
            "files_sha256": {name: digest(source / name) for name in SOURCE_FILES}}


def select_input(manifest, circuit_id, input_ensemble):
    candidates = [spec for spec in manifest["circuits"] if spec["id"] == circuit_id]
    if len(candidates) != 1:
        raise RuntimeError("select exactly one frozen circuit per fresh process")
    spec = candidates[0]
    if (spec["kind"], spec["qubits"]) not in PROFILE_SCOPES:
        raise RuntimeError("P3 scope is BW-14/16/18 and prepared-QFT-16")
    if input_ensemble == "independent":
        if (manifest.get("ensemble_stage") != "pilot" or spec.get("ensemble_stage") != "pilot"
                or spec.get("ensemble_index") != 0):
            raise RuntimeError("P3 independent inputs are preselected pilot index zero in each scope")
    elif input_ensemble != "historical":
        raise RuntimeError("unknown diagnostic input ensemble")
    return spec


def input_manifest_and_builder(path, input_ensemble):
    if input_ensemble == "independent":
        from scientific_circuit_inputs import load_scientific_manifest, build_scientific_circuit
        return load_scientific_manifest(path, expected_stage="pilot"), build_scientific_circuit
    if input_ensemble != "historical":
        raise RuntimeError("unknown diagnostic input ensemble")
    return load_manifest(path), build_circuit


def cpu_profile_helper():
    path = Path(__file__).resolve().parents[2] / "profiling/cpu_lapack_profile.py"
    spec = importlib.util.spec_from_file_location("article2_cpu_lapack_profile", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verified_cpu_preload(args):
    """Bind optional diagnostics to verified libraries and the original BLAS link."""
    requested = (args.cpu_lapack_verification is not None, args.cpu_lapack_profile_path is not None)
    if not any(requested):
        return None
    if not all(requested) or not args.mps_lapack or args.extension_path is None:
        raise RuntimeError("CPU profiling requires LAPACK, verification, a fresh log path and extension path")
    path = args.cpu_lapack_profile_path.resolve()
    try:
        path.relative_to(args.output.resolve())
    except ValueError as error:
        raise RuntimeError("CPU LAPACK log must be inside this diagnostic output directory") from error
    if path.parent != args.output.resolve() or path.exists():
        raise RuntimeError("CPU LAPACK log must be a new top-level diagnostic output file")
    if path.suffix != ".jsonl" or path.name in {
            "svd.events.jsonl", "svd.profiles.jsonl", "svd.decisions.jsonl", "cublas.events.jsonl"}:
        raise RuntimeError("CPU LAPACK log must use a separate JSONL filename")
    verification = json.loads(args.cpu_lapack_verification.read_text(encoding="utf-8"))
    if (verification.get("verification") != "PASS"
            or verification.get("production_benchmark") is not False
            or verification.get("original_outputs_unchanged") is not True
            or verification.get("disabled_and_empty_flag_verified") is not True
            or "USE64BITINT" in verification.get("openblas_config", "").upper()):
        raise RuntimeError("a passing LP64 interposer integration verification is required")
    for key in ("source", "verification_driver", "build_manifest", "interposer", "lapack_library", "events"):
        record = verification[key]
        if digest(record["path"]) != record["sha256"]:
            raise RuntimeError(f"CPU LAPACK verification input changed: {key}")
    helper = cpu_profile_helper()
    if (digest(helper.SOURCE) != verification["source"]["sha256"]
            or digest(helper.__file__) != verification["verification_driver"]["sha256"]):
        raise RuntimeError("CPU LAPACK helper differs from its verified source")
    interposer = Path(verification["interposer"]["path"]).resolve()
    lapack = Path(verification["lapack_library"]["path"]).resolve()
    if any(char in str(library) for library in (interposer, lapack) for char in (":", " ", "\n", "\t")):
        raise RuntimeError("preload library paths must not contain separators or whitespace")
    if digest(args.extension_path) != args.extension_sha256:
        raise RuntimeError("extension path differs from the pinned diagnostic binary")
    # Resolve the extension's normal dependencies with ambient preload removed:
    # introducing a different BLAS just for P3 would invalidate the comparison.
    environment = os.environ.copy()
    environment.pop("LD_PRELOAD", None)
    environment.pop("LD_AUDIT", None)
    linked = subprocess.check_output(["ldd", str(args.extension_path.resolve())],
                                     env=environment, text=True)
    linked_paths = [Path(value).resolve() for value in re.findall(r"=>\s+(/\S+)\s+\(", linked)]
    if lapack not in linked_paths:
        raise RuntimeError("verified LAPACK library is not the candidate's original resolved dependency")
    return {"verification_path": str(args.cpu_lapack_verification.resolve()),
            "verification_sha256": digest(args.cpu_lapack_verification),
            "interposer": verification["interposer"], "lapack_library": verification["lapack_library"],
            "preload": f"{interposer}:{lapack}", "profile_path": str(path),
            "candidate_dependency_check": "verified_library_matches_unpreloaded_ldd",
            "performance_claims_permitted": False}


def launch_environment(args, preload):
    """Set controls before the fresh interpreter/preloaded BLAS initializes."""
    environment = os.environ.copy()
    environment.update({key: str(args.threads) for key in THREAD_KEYS})
    environment.update({"GOTO_NUM_THREADS": str(args.threads), "OMP_DYNAMIC": "FALSE", "OMP_PROC_BIND": "FALSE"})
    environment.pop("OMP_PLACES", None)
    environment.pop("LD_PRELOAD", None)
    environment.pop("LD_AUDIT", None)
    environment.pop(CPU_PROFILE_KEY, None)
    if preload:
        environment["LD_PRELOAD"] = preload["preload"]
        environment[CPU_PROFILE_KEY] = preload["profile_path"]
    return environment


def runtime_policy(threads):
    from threadpoolctl import threadpool_info

    pools = threadpool_info()
    relevant = [pool for pool in pools if pool.get("user_api") in {"blas", "openmp"}]
    if not relevant or any(pool["num_threads"] != threads for pool in relevant):
        raise RuntimeError("diagnostic native thread pools do not match the launch policy")
    return {"thread_pools": pools, "cpu_affinity": sorted(os.sched_getaffinity(0)),
            "thread_environment": {key: os.environ.get(key) for key in THREAD_KEYS},
            "scope": "native pool limits and process affinity; not active worker utilization"}


def runtime_versions():
    """Identify imported code, including source-tree Aer without dist-info.

    Distribution metadata may be absent or belong to a different installed
    wheel. The already source/binary-checked Aer module is authoritative.
    Keep imports lazy so saved-record validation needs no numerical packages.
    """
    versions = {}
    for name in ("qiskit", "qiskit_aer", "numpy", "threadpoolctl"):
        value = getattr(import_module(name), "__version__", None)
        if not isinstance(value, str) or not value.strip():
            raise RuntimeError("loaded module lacks an explicit version: " + name)
        versions[name] = value
    return versions


def logical_payload(ranks, qubits):
    if len(ranks) != qubits - 1 or any(type(rank) is not int or rank < 1 for rank in ranks):
        raise RuntimeError("invalid native bond-dimension vector")
    boundaries = [1, *ranks, 1]
    gamma_elements = 2 * sum(a * b for a, b in zip(boundaries, boundaries[1:]))
    gamma_bytes, lambda_bytes = 16 * gamma_elements, 8 * sum(ranks)
    return {"bond_dimensions": list(ranks), "max_bond_dimension": max(ranks, default=1),
            "derived_gamma_payload_bytes": gamma_bytes,
            "derived_lambda_payload_bytes": lambda_bytes,
            "derived_logical_payload_bytes": gamma_bytes + lambda_bytes}


def parse_native_log(raw, qubits):
    """Consume every character; malformed, partial and unknown records fail."""
    if not isinstance(raw, str) or not raw.startswith("{") or not raw.endswith("}"):
        raise RuntimeError("missing or malformed MPS_log_data envelope")
    body = raw[1:-1]
    cursor, records = 0, []
    while cursor < len(body):
        match = LOG_TOKEN.match(body, cursor)
        if not match:
            raise RuntimeError(f"unparsed native MPS log at character {cursor}: {body[cursor:cursor+80]!r}")
        cursor = match.end()
        if match["discarded"] is not None:
            weight = float(match["discarded"])
            if not math.isfinite(weight) or weight < 0:
                raise RuntimeError("invalid reported discarded weight")
            records.append({"kind": "reported_discarded_weight", "value": weight})
            continue
        ranks = [int(value) for value in match["ranks"].split()]
        logical_payload(ranks, qubits)
        targets = [int(value) for value in match["qubits"].split(",")]
        if any(target >= qubits for target in targets) or len(set(targets)) != len(targets):
            raise RuntimeError("invalid native log qubit indices")
        records.append({"kind": "internal_swap" if match["swap"] else "gate",
                        "native_instruction_number": None if match["swap"] else int(match["number"]),
                        "name": "internal_swap" if match["swap"] else match["name"],
                        "qubits": targets, "ranks": ranks})
    return records


def align_gate_progress(operations, records, qubits):
    """Only one-qubit unitary gates may inherit unchanged dimensions."""
    ranks = [1] * (qubits - 1)
    progress = [{"compiled_gate_index": -1, "name": "initial_zero_state",
                 "rank_evidence": "known_product_initial_state", **logical_payload(ranks, qubits)}]
    internal, discarded, cursor, native_number = [], [], 0, 0
    for index, operation in enumerate(operations):
        if operation["name"] in {"barrier", "measure", "reset", "initialize", "unitary", "diagonal"}:
            raise RuntimeError("evolution progress requires the supported measurement-free gate recipe")
        if len(operation["qubits"]) == 1:
            evidence = "derived_carry_forward_single_qubit_unitary"
        else:
            while cursor < len(records) and records[cursor]["kind"] != "gate":
                record = records[cursor]
                if record["kind"] == "internal_swap":
                    internal.append({"during_compiled_gate_index": index, "qubits": record["qubits"],
                                     "rank_evidence": "observed_after_internal_swap",
                                     **logical_payload(record["ranks"], qubits)})
                else:
                    discarded.append({"during_compiled_gate_index": index,
                                      "reported_discarded_weight": record["value"]})
                cursor += 1
            if cursor == len(records):
                raise RuntimeError(f"missing native multi-qubit record for compiled gate {index}")
            record = records[cursor]
            if (record["native_instruction_number"] != native_number or
                    record["name"] != operation["name"] or record["qubits"] != operation["qubits"]):
                raise RuntimeError(f"native/compiled gate mismatch at compiled gate {index}")
            ranks = record["ranks"]
            evidence = "observed_after_multi_qubit_gate"
            cursor += 1
            native_number += 1
        progress.append({"compiled_gate_index": index, **operation,
                         "rank_evidence": evidence, **logical_payload(ranks, qubits)})
    if cursor != len(records):
        raise RuntimeError("extra native records: repeated executions or an unmatched operation")
    return {"gate_progress": progress, "internal_swap_progress": internal,
            "reported_discarded_weights": discarded,
            "rank_order": "native internal MPS chain; not fixed logical-qubit bipartitions",
            "payload_basis": "two complex128 matrices per Gamma; float64 Lambda vectors",
            "payload_excludes": ["capacity/reserve", "temporary contractions and SVD factors",
                                 "CUDA resources/workspaces", "Python/result copies", "allocator overhead", "RSS"],
            "discarded_weight_scope": "only entries above the native json_chop_threshold are logged"}


def load_events(path, event):
    if not path.exists():
        return []
    records = []
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            raise RuntimeError(f"blank event record at {path}:{index}")
        value = json.loads(line)
        if not isinstance(value, dict) or value.get("event") != event:
            raise RuntimeError(f"invalid event at {path}:{index}")
        records.append(value)
    return records


def dimensions(record, fields):
    values = [record.get(field) for field in fields]
    if any(type(value) is not int or value < 1 for value in values):
        raise RuntimeError("event dimensions must be positive integers")
    return values


def summarize_gpu_records(events, profiles, gemms, decisions, *, require_ordered_shapes=True):
    shapes = [dimensions(record, ("rows", "columns")) for record in events]
    if profiles:
        errors = validate_records(profiles, threshold=8401)
        if errors:
            raise RuntimeError("; ".join(errors))
    completed_shapes = [dimensions(record, ("rows", "columns")) for record in profiles]
    if Counter(map(tuple, shapes)) != Counter(map(tuple, completed_shapes)):
        raise RuntimeError("SVD submitted/profile counts or shape multisets differ")
    if require_ordered_shapes and shapes != completed_shapes:
        raise RuntimeError("SVD submitted/profile ordered shapes differ")
    for record in decisions:
        dimensions(record, ("num_qubits", "rows", "columns", "min_matrix_elements"))
        if record.get("decision") not in {"cutensor_csvd_wrapper", "csvd_wrapper"}:
            raise RuntimeError("unknown native SVD decision")
        if record["min_matrix_elements"] != 8401 or record.get("device") not in {"CPU", "GPU"}:
            raise RuntimeError("SVD decision threshold or device differs from the pinned policy")
        reason = ("num_qubits_not_above_13" if record["num_qubits"] <= 13 else
                  "device_not_gpu" if record["device"] != "GPU" else
                  "matrix_elements_not_above_threshold" if record["rows"] * record["columns"] <= 8401 else
                  "eligible")
        expected_decision = "cutensor_csvd_wrapper" if reason == "eligible" else "csvd_wrapper"
        if record.get("reason") != reason or record["decision"] != expected_decision:
            raise RuntimeError("SVD decision contradicts pinned source eligibility")
    svd_h2d = sum(16 * rows * cols for rows, cols in shapes)
    svd_d2h = sum(16 * (max(rows, cols) * min(rows, cols) + min(rows, cols)**2)
                  + 8 * min(rows, cols) for rows, cols in shapes)
    gemm_shapes = [dimensions(record, ("rows", "inner", "columns")) for record in gemms]
    groups = defaultdict(list)
    for record in profiles:
        groups[(record["rows"], record["columns"])].append(record)
    phase_shapes = []
    for (rows, cols), group in sorted(groups.items()):
        phase_shapes.append({"rows": rows, "columns": cols, "count": len(group),
            "recorded_intervals_ms": {field: {
                "sum": math.fsum(record[field] for record in group),
                "median": statistics.median(record[field] for record in group),
                "minimum": min(record[field] for record in group),
                "maximum": max(record[field] for record in group)} for field in TIMING_FIELDS}})
    return {
        "svd_submitted_calls": len(events), "svd_completed_profile_records": len(profiles),
        "svd_event_profile_comparison": "ordered_shapes" if require_ordered_shapes else "shape_multisets_concurrent_sampling",
        "svd_profile_shapes": phase_shapes, "successful_cublas_calls": len(gemms),
        "cublas_shapes": [{"rows": m, "inner": k, "columns": n, "count": count}
                          for (m, k, n), count in sorted(Counter(map(tuple, gemm_shapes)).items())],
        "svd_decision_counts": dict(Counter(record["decision"] for record in decisions)),
        "source_derived_requested_copy_bytes": {
            "svd_h2d": svd_h2d, "svd_d2h": svd_d2h,
            "cublas_h2d": sum(16 * (m*k + k*n) for m, k, n in gemm_shapes),
            "cublas_d2h": sum(16 * m*n for m, k, n in gemm_shapes)},
        "copy_bytes_scope": "successful recorded wrappers; requested memcpy payload, not measured PCIe traffic",
        "recorded_workspace_maxima_bytes": {
            field: max((record[field] for record in profiles), default=None)
            for field in ("matrix_buffer_capacity_bytes", "device_workspace_bytes", "host_workspace_bytes")},
        "workspace_scope": "per-wrapper cached capacities; not simultaneous or total device allocations",
        "recorded_growth_counts": {field: sum(record[field] for record in profiles)
            for field in ("matrix_buffers_grew", "device_workspace_grew", "host_workspace_grew")},
        "interval_limitations": "host and CUDA-event boundaries overlap and include setup/journal gaps; do not add them as disjoint phases or subtract from P1/P2 times",
        "unmeasured": ["CPU SVD phase time", "cuBLAS phase time", "hardware transfer counters", "GPU utilization"]}


def execute(args):
    if args.output.exists():
        raise RuntimeError("refusing to reuse diagnostic output, including a failed run")
    if not re.fullmatch(r"[0-9a-f]{64}", args.extension_sha256):
        raise RuntimeError("an exact expected Aer extension SHA-256 is required")
    if args.threads < 1:
        raise RuntimeError("threads must be positive")
    if args.input_ensemble == "independent" and not args.mps_lapack:
        raise RuntimeError("independent P3 CPU/GPU diagnostics require the matched P2 mps_lapack=True setting")
    if any(os.environ.get(key) != str(args.threads) for key in THREAD_KEYS):
        raise RuntimeError("thread policy must be set by the launcher before native libraries initialize")
    if args.cpu_affinity is not None and sorted(os.sched_getaffinity(0)) != sorted(args.cpu_affinity):
        raise RuntimeError("diagnostic CPU affinity differs from the launch contract")
    preload = verified_cpu_preload(args)
    if os.environ.get("LD_PRELOAD") != (preload["preload"] if preload else None):
        raise RuntimeError("unexpected diagnostic preload configuration")
    source = verify_source(args.source)
    manifest, circuit_builder = input_manifest_and_builder(args.manifest, args.input_ensemble)
    spec = select_input(manifest, args.circuit_id, args.input_ensemble)
    args.output.mkdir(parents=True)
    loader_policy = {"LD_PRELOAD": preload["preload"]} if preload else None
    setup = prepare_mps_environment(dispatch_threshold=8401,
                                    expected_loader_environment=loader_policy)
    os.environ["AER_ENABLE_CUTENSORNET"] = "1"
    os.environ["AER_THRUST_BACKEND"] = "CUDA"
    paths = {key: str((args.output / name).resolve()) for key, name in (
        ("AER_CUTENSOR_SVD_EVENTS_PATH", "svd.events.jsonl"),
        ("AER_CUTENSOR_SVD_PROFILE_PATH", "svd.profiles.jsonl"),
        ("AER_CUTENSOR_SVD_DECISIONS_PATH", "svd.decisions.jsonl"),
        ("AER_CUBLAS_EVENTS_PATH", "cublas.events.jsonl"))}
    os.environ.update(paths)
    # The P1-frozen helper initially does not know this new optional key. Keep
    # it unchanged; P3 explicitly enables/verifies the path after preparation.
    os.environ.pop(CPU_PROFILE_KEY, None)
    if preload:
        os.environ[CPU_PROFILE_KEY] = preload["profile_path"]
        if CPU_PROFILE_KEY in DIAGNOSTIC_PATH_KEYS:
            paths[CPU_PROFILE_KEY] = preload["profile_path"]
    import qiskit
    import qiskit_aer
    from qiskit import transpile
    from qiskit_aer import AerSimulator
    from qiskit_aer.backends import controller_wrappers
    actual_extension = Path(controller_wrappers.__file__).resolve()
    if (digest(actual_extension) != args.extension_sha256 or
            args.source.resolve() not in Path(qiskit_aer.__file__).resolve().parents):
        raise RuntimeError("loaded Aer binary/source differs from the pinned diagnostic build")
    if args.extension_path is not None and actual_extension != args.extension_path.resolve():
        raise RuntimeError("loaded extension path differs from the diagnostic launch target")
    circuit = circuit_builder(spec)
    if qasm_sha256(circuit) != spec["qasm_sha256"]:
        raise RuntimeError("input QASM differs from the frozen circuit")
    evolution = args.mode == "evolution"
    if not evolution:
        circuit.measure_all()
    shots = 1 if evolution else 100
    backend = AerSimulator(method="matrix_product_state", device=args.device,
        precision="double",
        mps_lapack=args.mps_lapack, mps_log_data=evolution,
        matrix_product_state_max_bond_dimension=1024,
        matrix_product_state_truncation_threshold=0.0,
        max_parallel_threads=args.threads, max_parallel_experiments=1,
        # MPS disables fusion in circuit_executor.hpp before config overrides.
        # Match the timing runner's nominal default anyway. Measurement-free
        # mode must preserve qubits without requiring output instructions.
        fusion_enable=True, enable_truncation=not evolution)
    compiled = transpile(circuit, backend, optimization_level=0, seed_transpiler=args.seed_transpiler)
    operations = [{"name": item.operation.name,
                   "qubits": [compiled.find_bit(qubit).index for qubit in item.qubits]}
                  for item in compiled.data]
    effective = assert_execution_environment(dispatch_threshold=8401, diagnostic_paths=paths,
                                              expected_loader_environment=loader_policy)
    if os.environ.get(CPU_PROFILE_KEY) != (preload["profile_path"] if preload else None):
        raise RuntimeError("CPU LAPACK profile path changed after diagnostic setup")
    runtime_before = runtime_policy(args.threads)
    helper_names = ["run_e2_numerical_correctness_pilot.py", "mps_execution_environment.py", "crossover_profile.py"]
    if args.input_ensemble == "independent":
        helper_names.append("scientific_circuit_inputs.py")
    contract = {"schema_version": 1, "source": source, "extension_sha256": args.extension_sha256,
        "extension_path": str(actual_extension), "driver_sha256": digest(__file__),
        "helper_sha256": {name: digest(Path(__file__).parent / name) for name in helper_names},
        "manifest_sha256": manifest["manifest_sha256"], "circuit": spec,
        "input_ensemble": args.input_ensemble,
        "input_selection_policy": ("predeclared pilot index zero in each BW14/BW16/pQFT16/BW18 scope"
                                   if args.input_ensemble == "independent" else "explicit historical frozen circuit"),
        "compiled_qasm_sha256": qasm_sha256(compiled), "compiled_operations": operations,
        "mode": args.mode, "device": args.device, "mps_lapack": args.mps_lapack,
        "precision": "double",
        "shots": shots, "warmups": 0, "executions": 1, "threads": args.threads,
        "max_bond_dimension": 1024, "truncation_threshold": 0.0,
        "seed_simulator": args.seed_simulator, "seed_transpiler": args.seed_transpiler,
        "fusion_enable": True, "fusion_effective": "disabled_by_pinned_MPS_executor",
        "enable_truncation": not evolution,
        "truncation_option_reason": "preserve measurement-free qubits; shots100 matches timing default",
        "qiskit_version": qiskit.__version__, "aer_version": qiskit_aer.__version__,
        "runtime_versions": runtime_versions(),
        "environment_setup": setup, "effective_environment": effective,
        "runtime_before_execution": runtime_before, "requested_cpu_affinity": args.cpu_affinity,
        "diagnostic_cpu_lapack_preload": preload, "child_command": [sys.executable, *sys.argv],
        "performance_claims_permitted": False}
    write_new(args.output / "contract.json", contract)
    result = backend.run(compiled, shots=shots, seed_simulator=args.seed_simulator).result()
    if not result.success:
        raise RuntimeError("diagnostic Aer execution failed: " + str(result.status))
    metadata = dict(result.results[0].metadata)
    write_new(args.output / "result_metadata.json", metadata)
    if (metadata.get("device") != args.device or metadata.get("num_qubits") != spec["qubits"] or
            metadata.get("matrix_product_state_lapack") != args.mps_lapack):
        raise RuntimeError("actual device, qubit count, or LAPACK setting differs from contract")
    progress = None
    if evolution:
        raw_log = metadata.get("MPS_log_data")
        progress = align_gate_progress(operations, parse_native_log(raw_log, spec["qubits"]), spec["qubits"])
        write_new(args.output / "logical_mps_progress.json", progress)
    events = load_events(args.output / "svd.events.jsonl", "cutensor_csvd_wrapper")
    profiles = load_events(args.output / "svd.profiles.jsonl", "cutensor_csvd_profile")
    gemms = load_events(args.output / "cublas.events.jsonl", "cublas_zgemm")
    decisions = load_events(args.output / "svd.decisions.jsonl", "cutensor_svd_decision")
    if args.device == "GPU" and spec.get("offload_required", False) and not events:
        raise RuntimeError("the frozen input requires actual GPU SVD; no event was recorded")
    summary = summarize_gpu_records(events, profiles, gemms, decisions,
                                    require_ordered_shapes=evolution)
    if preload:
        cpu_records = load_events(Path(preload["profile_path"]), "cpu_lapack_call")
        if not decisions:
            raise RuntimeError("CPU LAPACK completeness requires native CUDA-build dispatch decisions")
        # These source-pinned gate recipes start in |0>; there is no separate
        # statevector-initialization decomposition bypassing decision logging.
        expected_shapes = [dimensions(record, ("rows", "columns")) for record in decisions
                           if record["decision"] == "csvd_wrapper"]
        summary["cpu_lapack"] = cpu_profile_helper().summarize_cpu_lapack_records(
            cpu_records, expected_factor_shapes=expected_shapes)
        summary["cpu_lapack"]["coverage_basis"] = (
            "source-pinned CUDA dispatch decisions with mps_lapack=True; standard zero-state gate inputs; no direct statevector initialization")
        summary["unmeasured"] = [item for item in summary["unmeasured"] if item != "CPU SVD phase time"]
        summary["unmeasured"].append("CPU SVD caller-side packing/allocation/reconstruction/truncation")
    else:
        summary["cpu_lapack"] = {"status": "UNMEASURED", "reason": (
            "selected custom non-LAPACK SVD has no LAPACK entry-point coverage" if not args.mps_lapack
            else "no verified CPU LAPACK interposer requested")}
    sample_time = metadata.get("sample_measure_time")
    if sample_time is not None and (not isinstance(sample_time, (int, float)) or
                                   not math.isfinite(sample_time) or sample_time < 0):
        raise RuntimeError("invalid sample_measure_time metadata")
    summary.update({"schema_version": 1, "status": "PASS", "mode": args.mode,
        "contract_sha256": digest(args.output / "contract.json"),
        "runtime_after_execution": runtime_policy(args.threads),
        "performance_claims_permitted": False, "sample_measure_time_seconds": sample_time,
        "sample_measure_time_scope": "native sample_measure() call only, when metadata is available; not total measurement handling",
        "call_scope": "single measurement-free evolution" if evolution else "one 100-shot call including terminal sampling",
        "gate_correlation": "native rank log aligns to compiled gates; SVD/cuBLAS streams have no gate IDs and are not joined to particular gates",
        "files_sha256": {path.name: digest(path) for path in sorted(args.output.iterdir()) if path.is_file()}})
    write_new(args.output / "summary.json", summary)
    print(f"PASS: separate {args.mode} diagnostic saved to {args.output}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--input-ensemble", choices=("historical", "independent"), default="historical")
    parser.add_argument("--circuit-id", required=True)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--extension-sha256", required=True)
    parser.add_argument("--extension-path", type=Path,
                        help="required for CPU profiling to verify the candidate's original BLAS dependency")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--mode", choices=("evolution", "shots100"), default="evolution")
    parser.add_argument("--device", choices=("CPU", "GPU"), default="GPU")
    parser.add_argument("--mps-lapack", action="store_true")
    parser.add_argument("--threads", type=int, default=6)
    parser.add_argument("--cpu-affinity", type=int, nargs="+",
                        help="optional CPU IDs applied by taskset before Python/preload initialization")
    parser.add_argument("--cpu-lapack-verification", type=Path,
                        help="passing interposer verification JSON; diagnostics only")
    parser.add_argument("--cpu-lapack-profile-path", type=Path,
                        help="fresh JSONL path directly inside --output; requires verified LAPACK interposition")
    parser.add_argument("--_diagnostic-child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--seed-simulator", type=int, default=20260722)
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    args = parser.parse_args()
    existed_before = args.output.exists()
    try:
        if args._diagnostic_child:
            execute(args)
            return 0
        if existed_before:
            raise RuntimeError("refusing to reuse diagnostic output, including a failed run")
        if args.threads < 1:
            raise RuntimeError("threads must be positive")
        if args.cpu_affinity is not None and (not args.cpu_affinity
                or len(set(args.cpu_affinity)) != len(args.cpu_affinity)
                or any(cpu < 0 for cpu in args.cpu_affinity)):
            raise RuntimeError("CPU affinity must contain distinct nonnegative CPU IDs")
        preload = verified_cpu_preload(args)
        command = [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:], "--_diagnostic-child"]
        if args.cpu_affinity is not None:
            command = ["taskset", "--cpu-list", ",".join(map(str, args.cpu_affinity)), *command]
        result = subprocess.run(command, env=launch_environment(args, preload))
        return result.returncode
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        if not existed_before and args.output.is_dir() and not (args.output / "summary.json").exists():
            failure = args.output / "failure.json"
            if not failure.exists():
                write_new(failure, {"status": "FAIL", "error": str(error), "performance_claims_permitted": False})
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
