#!/usr/bin/env python3
"""Read-only, standard-library P3 collection validation. Never import Aer.

The archived driver's pure parsers recompute results; no recorded absolute
source/library path is opened and no circuit, simulator, compiler or subprocess
is invoked. Capture stdout as validation.json only after a complete collection.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import re
import sys


PINNED_REVISION = "a1242579272784330b217085fe11b7e1481922ad"
SOURCE_HASHES = {
    "src/simulators/matrix_product_state/svd.cpp": "f83ae90be1062b3eb20db314a4959326a96b51730cb0ad2c2b8f8581d5ae672e",
    "src/simulators/matrix_product_state/matrix_product_state.hpp": "0fbca6ee66ee4905f707d2abb8612f2a4480ab19baef9ef009274df10406348a",
    "src/simulators/matrix_product_state/matrix_product_state_internal.cpp": "642240f56575f1c7509ecb7d84b5331af889339f22c31efcce96fc71d71a564a",
    "src/simulators/matrix_product_state/matrix_product_state_tensor.hpp": "9a55bf7a55212f47204575ce76a915495050473545e98fadc25abf1961acf044",
    "src/simulators/circuit_executor.hpp": "78950a1ea67e30844678d5116b3e7a8da55056ad70d33960daa4dabf8914213e",
}
THREAD_KEYS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
SCOPES = (("brickwork", 14), ("brickwork", 16), ("qft_prepared", 16), ("brickwork", 18))
HELPERS = ("run_e2_numerical_correctness_pilot.py", "mps_execution_environment.py",
           "scientific_circuit_inputs.py", "crossover_profile.py")
RUNNER_FILES = {"tests/modular/" + name for name in
                (*HELPERS, "run_scientific_mps_profile.py", "validate_scientific_mps_profile.py")} | {
                    "profiling/cpu_lapack_profile.py", "profiling/cpu_lapack_interposer.cpp"}
POLICY = {"precision": "double", "max_bond_dimension": 1024, "truncation_threshold": 0.0,
          "mps_lapack": True, "threads": 6, "cpu_affinity": [0, 2, 4, 6, 8, 10],
          "seed_simulator": 20260907, "seed_transpiler": 20260907,
          "cpu_lapack_profile_devices": ["CPU", "GPU"],
          "runtime_versions": {"qiskit": "2.5.0", "qiskit_aer": "0.17.2",
                               "numpy": "2.4.6", "threadpoolctl": "3.6.0"}}
CPU_COVERAGE_BASIS = ("source-pinned CUDA dispatch decisions with mps_lapack=True; "
                      "standard zero-state gate inputs; no direct statevector initialization")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def same(actual, expected, message):
    require(canonical(actual) == canonical(expected), message)


def _pairs(items):
    value = {}
    for key, item in items:
        require(key not in value, "duplicate JSON object key: " + key)
        value[key] = item
    return value


def parse_json(text):
    return json.loads(text, object_pairs_hook=_pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON: " + value)))


def read_json(path):
    value = parse_json(Path(path).read_text(encoding="utf-8"))
    require(isinstance(value, dict), "JSON root must be an object: " + Path(path).name)
    return value


def relative_path(root, name):
    require(isinstance(name, str) and bool(name) and "\\" not in name and ":" not in name,
            "inventory paths must be relative POSIX paths")
    path = PurePosixPath(name)
    require(not path.is_absolute() and all(part not in {"", ".", ".."} for part in path.parts)
            and path.as_posix() == name, "unsafe or noncanonical inventory path")
    result = Path(root).joinpath(*path.parts)
    require(not result.is_symlink(), "symlinked evidence is unsupported")
    require(result.resolve().is_relative_to(Path(root).resolve()), "evidence path escapes collection")
    return result


def hash_inventory(root, records, *, expected_names=None):
    require(isinstance(records, dict) and records, "missing hash inventory")
    if expected_names is not None:
        require(set(records) == set(expected_names), "hash inventory has missing or unexpected files")
    require(len({name.casefold() for name in records}) == len(records), "case-colliding inventory paths")
    for name, expected in records.items():
        require(isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected), "invalid SHA-256")
        path = relative_path(root, name)
        require(path.is_file() and sha256(path) == expected, "file missing or hash changed: " + name)


def read_events(path, expected_event):
    if not path.is_file():
        return []
    result = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        require(bool(line.strip()), f"blank JSONL record: {path.name}:{number}")
        record = parse_json(line)
        require(isinstance(record, dict) and record.get("event") == expected_event,
                f"unexpected JSONL record: {path.name}:{number}")
        result.append(record)
    return result


@contextmanager
def archived_helpers(root):
    """Load only the frozen Python modules; disable bytecode writes and restore imports."""
    names = ("mps_execution_environment", "run_e2_numerical_correctness_pilot", "crossover_profile",
             "scientific_circuit_inputs", "article2_p3_archived_driver", "article2_cpu_lapack_profile")
    saved = {name: sys.modules.get(name) for name in names}
    original_write = sys.dont_write_bytecode
    sys.dont_write_bytecode = True

    def load(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    try:
        modular = root / "runner_snapshot/tests/modular"
        for name in names[:4]:
            load(name, modular / (name + ".py"))
        driver = load(names[4], modular / "run_scientific_mps_profile.py")
        cpu = load(names[5], root / "runner_snapshot/profiling/cpu_lapack_profile.py")
        yield driver, sys.modules[names[1]], sys.modules[names[3]], cpu
    finally:
        sys.dont_write_bytecode = original_write
        for name, previous in saved.items():
            if previous is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous


def validate_manifest(manifest, e2, independent):
    require(not e2.validate_manifest_structure(manifest), "invalid canonical input/recipe manifest")
    require(manifest.get("ensemble_stage") == "pilot" and manifest.get("ensemble_design") == independent.DESIGN_ID,
            "P3 requires the complete independent P2 pilot manifest")
    same(manifest.get("primary_scope"), {"kind": "brickwork", "qubits": 16}, "wrong primary input scope")
    circuits = manifest["circuits"]
    for spec in circuits:
        independent._validated_angles(spec)  # pure scalar validation; never build a Qiskit circuit
        require(spec.get("ensemble_stage") == "pilot", "mixed pilot/confirmation inputs")
        require(re.fullmatch(r"[0-9a-f]{64}", str(spec.get("qasm_sha256", ""))), "invalid input QASM hash")
    schedule = independent.seed_schedule("pilot")
    expected = {(kind, qubits, seed) for (kind, qubits), seeds in schedule.items() for seed in seeds}
    actual = {(spec["kind"], spec["qubits"], spec["seed"]) for spec in circuits}
    require(len(circuits) == 25 and actual == expected and len({s["id"] for s in circuits}) == 25,
            "pilot manifest must retain all 25 distinct registered inputs")
    same(manifest.get("seed_schedule"), [{"kind": kind, "qubits": qubits, "seeds": list(seeds)}
                                         for (kind, qubits), seeds in schedule.items()], "seed schedule changed")
    selected = []
    for scope in SCOPES:
        matches = [s for s in circuits if (s["kind"], s["qubits"]) == scope and s["ensemble_index"] == 0]
        require(len(matches) == 1, "missing preselected index-zero diagnostic input")
        selected.append(matches[0])
    return selected


def expected_operations(spec, mode):
    operations = []
    def add(name, *qubits):
        operations.append({"name": name, "qubits": list(qubits)})
    n = spec["qubits"]
    if spec["kind"] == "brickwork":
        for layer in range(spec["depth"]):
            for q in range(n):
                add("ry", q)
                add("rz", q)
            for q in range(layer % 2, n - 1, 2):
                add("cx", q, q + 1)
    else:
        for q in range(n):
            add("ry", q)
            add("rz", q)
        for target in range(n):
            add("h", target)
            for control in range(target + 1, n):
                add("cp", control, target)
        for q in range(n // 2):
            add("swap", q, n - q - 1)
    if mode == "shots100":
        add("barrier", *range(n))
        for q in range(n):
            add("measure", q)
    return operations


def validate_operation_graph(operations, expected, qubits):
    # Even optimization_level=0 can topologically reorder disjoint gates.
    # Preserve each wire's ordered operations and every multi-qubit operand
    # tuple; do not require an arbitrary total ordering across independent wires.
    require(isinstance(operations, list) and len(operations) == len(expected), "compiled operation inventory differs")
    for operation in operations:
        require(isinstance(operation, dict) and set(operation) == {"name", "qubits"}
                and isinstance(operation["name"], str) and isinstance(operation["qubits"], list)
                and operation["qubits"] and len(set(operation["qubits"])) == len(operation["qubits"])
                and all(type(q) is int and 0 <= q < qubits for q in operation["qubits"]),
                "invalid compiled gate operands")
    for qubit in range(qubits):
        actual_wire = [op for op in operations if qubit in op["qubits"]]
        expected_wire = [op for op in expected if qubit in op["qubits"]]
        same(actual_wire, expected_wire, "compiled per-qubit gate order differs from the zero-state recipe")


def validate_runtime(runtime):
    same(runtime.get("cpu_affinity"), POLICY["cpu_affinity"], "recorded CPU affinity differs")
    same(runtime.get("thread_environment"), {key: "6" for key in THREAD_KEYS}, "recorded six-variable thread policy differs")
    pools = runtime.get("thread_pools")
    require(isinstance(pools, list) and pools, "missing observed native thread pools")
    relevant = [pool for pool in pools if pool.get("user_api") in {"blas", "openmp"}]
    require(relevant and all(type(pool.get("num_threads")) is int and pool["num_threads"] == 6 for pool in relevant),
            "observed native thread-pool limit differs from six")
    require(any(pool.get("internal_api") == "openblas" and pool.get("version") == "0.3.26" for pool in relevant),
            "selected system OpenBLAS was not recorded")


def validate_p2_binding(root, campaign, manifest, selected_ids):
    """Bind archived graph receipts, without claiming to revalidate P2 raw runs."""
    names = {"contract.json", "correctness_gate.json", "compiled_hashes.json"}
    hashes = campaign.get("p2_files_sha256")
    folder = root / "p2_binding"
    hash_inventory(folder, hashes, expected_names=names)
    contract = read_json(folder / "contract.json")
    gate = read_json(folder / "correctness_gate.json")
    compiled = read_json(folder / "compiled_hashes.json")
    require(contract.get("schema_version") == 1 and contract.get("stage") == "P2_PILOT",
            "P3 graph receipts must come from the P2 pilot")
    require(gate.get("status") == "PASS" and gate.get("errors") == []
            and gate.get("contract_sha256") == hashes["contract.json"],
            "P2 correctness receipt is not a passing receipt for this contract")
    require(contract.get("manifest_sha256") == manifest["manifest_sha256"],
            "P2 graph receipt input manifest differs from P3")
    expected_protocol = {"warmups": 5, "timed_repetitions": 20, "shots": 100,
                         "threads": 6, "max_bond_dimension": 1024,
                         "truncation_threshold": 0.0, "precision": "double",
                         "dispatch_threshold_elements": 8401}
    same(contract.get("protocol"), expected_protocol, "P2 measurement protocol differs")
    for key in ("runtime_versions", "cpu_affinity", "seed_simulator", "seed_transpiler"):
        same(contract.get(key), POLICY[key], "P2 runtime policy differs: " + key)
    candidates = contract.get("candidates")
    require(isinstance(candidates, list) and len(candidates) in (2, 3)
            and all(isinstance(candidate, dict) for candidate in candidates), "invalid P2 candidate inventory")
    roles = [candidate.get("role") for candidate in candidates]
    require(len(set(roles)) == len(roles) and {"selected_cpu", "gpu"} <= set(roles)
            and set(roles) <= {"selected_cpu", "gpu", "internal_cpu"}, "invalid P2 candidate roles")
    require(len({candidate.get("id") for candidate in candidates}) == len(candidates), "duplicate P2 candidate identities")
    by_role = {candidate["role"]: candidate for candidate in candidates}
    for role, backend in (("selected_cpu", "custom_cpu"), ("gpu", "custom_gpu")):
        candidate = by_role[role]
        require(candidate.get("source_revision") == PINNED_REVISION
                and candidate.get("extension_sha256") == campaign["extension_sha256"]
                and candidate.get("mps_lapack") is True and candidate.get("backend") == backend
                and candidate.get("stock_lapack_reconstruction") is False,
                "P2 selected CPU/GPU source, binary or LAPACK policy differs from P3")
    same(campaign.get("execution_candidate"), by_role["gpu"], "P3 execution candidate differs from the P2 GPU receipt")
    all_ids = {spec["id"] for spec in manifest["circuits"]}
    require(set(compiled) == all_ids and all(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
                                           for value in compiled.values()), "P2 graph receipt must retain all 25 input hashes")
    same(campaign.get("expected_compiled_qasm_sha256"), {key: compiled[key] for key in selected_ids},
         "P3 expected graphs differ from the four selected P2 graph receipts")
    return {"files_sha256": hashes, "correctness_gate_status": "PASS",
            "selected_cpu_candidate": by_role["selected_cpu"]["id"], "gpu_candidate": by_role["gpu"]["id"],
            "scope": "Archived P2 contract, passing correctness receipt and compiled-graph hashes only; "
                     "complete P2 raw evidence is validated separately."}


def validate_profiler(root, campaign):
    mapping = campaign.get("profiler_verification_files")
    require(isinstance(mapping, dict) and set(mapping) == {"verification", "build", "events"},
            "profiler verification file mapping is required")
    require(len(set(mapping.values())) == 3, "profiler file mapping contains aliases")
    directory = root / "profiler_verification"
    hash_inventory(directory, campaign["profiler_files_sha256"], expected_names=mapping.values())
    verification_path = relative_path(directory, mapping["verification"])
    verification = read_json(verification_path)
    build = read_json(relative_path(directory, mapping["build"]))
    for key, expected in (("verification", "PASS"), ("production_benchmark", False),
                          ("original_outputs_unchanged", True), ("disabled_and_empty_flag_verified", True),
                          ("two_calling_threads_verified", True), ("event_count", 18), ("expected_event_count", 18)):
        same(verification.get(key), expected, "invalid interposer verification status: " + key)
    require("OpenBLAS 0.3.26" in verification.get("openblas_config", "")
            and "USE64BITINT" not in verification["openblas_config"], "wrong profiler LAPACK ABI")
    for key, relative in (("source", "profiling/cpu_lapack_interposer.cpp"),
                          ("verification_driver", "profiling/cpu_lapack_profile.py")):
        require(verification[key]["sha256"] == campaign["runner_files_sha256"][relative], "profiler source hash mismatch")
    require(verification["build_manifest"]["sha256"] == campaign["profiler_files_sha256"][mapping["build"]], "profiler build manifest changed")
    require(verification["events"]["sha256"] == campaign["profiler_files_sha256"][mapping["events"]], "profiler verification events changed")
    same(build.get("interposer"), verification["interposer"], "profiler binary identity differs")
    same(build.get("source"), verification["source"], "profiler build source identity differs")
    require(build.get("lapack_integer_bits") == 32 and build.get("timing_use_permitted") is False,
            "profiler build policy differs")
    for key in ("interposer", "lapack_library"):
        require(re.fullmatch(r"[0-9a-f]{64}", str(verification[key].get("sha256", ""))), "invalid library fingerprint")
    records = read_events(relative_path(directory, mapping["events"]), "cpu_lapack_call")
    require(len(records) == 18 and sorted(row["call_id"] for row in records) == list(range(1, 19)), "incomplete interposer integration events")
    for row in records:
        require(type(row.get("call_id")) is int and type(row.get("info")) is int
                and row.get("schema_version") == 1 and row.get("clock") == "CLOCK_MONOTONIC"
                and row.get("nested_calls_suppressed") is True, "invalid interposer integration metadata")
        duration = row.get("host_wall_seconds")
        require(type(duration) in (int, float) and math.isfinite(duration) and duration >= 0,
                "invalid interposer integration interval")
        require((row.get("lwork") == -1) == (row["phase"] == "workspace_query"),
                "interposer integration query phase is inconsistent")
    require(len({row["tid"] for row in records if row["m"] > 0}) == 2,
            "interposer integration did not record two calling threads")
    expected = Counter((routine, m, n, phase, 0) for _ in range(2)
                       for routine in ("zgesvd_", "zgesdd_") for m, n in ((3, 2), (2, 3))
                       for phase in ("workspace_query", "factorization"))
    expected.update([("zgesvd_", -1, 2, "workspace_query", -3), ("zgesdd_", -1, 2, "workspace_query", -2)])
    same(dict(Counter(str(row["info"]) for row in records)), verification["status_counts"], "interposer verification status counts changed")
    require(Counter((r["routine"], r["m"], r["n"], r["phase"], r["info"]) for r in records) == expected,
            "interposer verification shapes/phases/statuses changed")
    same({phase: math.fsum(row["host_wall_seconds"] for row in records if row["phase"] == phase)
          for phase in ("workspace_query", "factorization")}, verification["phase_wall_seconds"], "interposer verification interval sums changed")
    return verification, sha256(verification_path)


def validate_cell(root, entry, spec, campaign, driver, cpu, verification, verification_hash):
    directory = relative_path(root, entry["directory"])
    contract, summary = read_json(directory / "contract.json"), read_json(directory / "summary.json")
    metadata = read_json(directory / "result_metadata.json")
    mode, device = entry["mode"], entry["device"]
    evolution = mode == "evolution"
    files = {path.name for path in directory.iterdir() if path.is_file() and path.name != "summary.json"}
    require(all(path.is_file() for path in directory.iterdir()), "unexpected nested cell artifact")
    hash_inventory(directory, summary.get("files_sha256"), expected_names=files)
    require({"contract.json", "result_metadata.json", "svd.decisions.jsonl", "cpu_lapack.jsonl"} <= files,
            "cell is missing mandatory raw diagnostic files")
    require(files <= {"contract.json", "result_metadata.json", "logical_mps_progress.json", "svd.decisions.jsonl",
                       "cpu_lapack.jsonl", "svd.events.jsonl", "svd.profiles.jsonl", "cublas.events.jsonl"}, "unexpected cell output")
    require(("logical_mps_progress.json" in files) == evolution, "logical progress exists in the wrong mode")
    same(contract.get("source", {}).get("revision"), PINNED_REVISION, "cell source revision differs")
    same(contract["source"].get("files_sha256"), SOURCE_HASHES, "cell source files differ")
    same(contract.get("circuit"), spec, "cell uses a different frozen input")
    require(contract.get("manifest_sha256") == campaign["scientific_manifest_sha256"], "cell manifest fingerprint differs")
    require(contract.get("extension_sha256") == campaign["extension_sha256"], "cell binary fingerprint differs")
    require(contract.get("driver_sha256") == campaign["runner_files_sha256"]["tests/modular/run_scientific_mps_profile.py"], "cell driver fingerprint differs")
    same(contract.get("helper_sha256"), {name: campaign["runner_files_sha256"]["tests/modular/" + name] for name in HELPERS}, "cell helper fingerprints differ")
    for key in ("precision", "mps_lapack", "threads", "max_bond_dimension", "truncation_threshold",
                "seed_simulator", "seed_transpiler", "runtime_versions"):
        same(contract.get(key), POLICY[key], "cell runtime policy differs: " + key)
    expected_contract = {"schema_version": 1, "input_ensemble": "independent", "mode": mode, "device": device,
                         "shots": 1 if evolution else 100, "warmups": 0, "executions": 1,
                         "fusion_enable": True, "fusion_effective": "disabled_by_pinned_MPS_executor",
                         "enable_truncation": not evolution, "performance_claims_permitted": False,
                         "requested_cpu_affinity": POLICY["cpu_affinity"], "qiskit_version": "2.5.0", "aer_version": "0.17.2"}
    for key, value in expected_contract.items():
        same(contract.get(key), value, "cell contract differs: " + key)
    operations = contract.get("compiled_operations")
    validate_operation_graph(operations, expected_operations(spec, mode), spec["qubits"])
    compiled = contract.get("compiled_qasm_sha256")
    require(isinstance(compiled, str) and re.fullmatch(r"[0-9a-f]{64}", compiled), "invalid compiled QASM hash")
    if not evolution and campaign.get("expected_compiled_qasm_sha256") is not None:
        require(compiled == campaign["expected_compiled_qasm_sha256"][spec["id"]], "shots100 graph differs from frozen P2 measurement graph")
    for runtime in (contract["runtime_before_execution"], summary["runtime_after_execution"]):
        validate_runtime(runtime)
    for key, expected in (("device", device), ("num_qubits", spec["qubits"]), ("method", "matrix_product_state"),
                          ("matrix_product_state_lapack", True), ("matrix_product_state_max_bond_dimension", 1024),
                          ("matrix_product_state_truncation_threshold", 0.0), ("parallel_state_update", 6)):
        same(metadata.get(key), expected, "observed Aer metadata differs: " + key)
    require(metadata.get("fusion", {}).get("enabled") is False, "MPS fusion was not disabled")
    effective = contract.get("effective_environment", {})
    same(effective.get("dispatch_threshold_elements"), 8401, "dispatch threshold changed")
    same(effective.get("diagnostic_paths_enabled"), {key: True for key in (
        "AER_CUTENSOR_SVD_EVENTS_PATH", "AER_CUTENSOR_SVD_PROFILE_PATH", "AER_CUTENSOR_SVD_DECISIONS_PATH",
        "AER_CUBLAS_EVENTS_PATH", "AER_CPU_LAPACK_PROFILE_PATH")}, "diagnostic paths were not all enabled")
    same(effective.get("reconstruction_checks_enabled"), {
        "AER_CUTENSOR_SVD_VALIDATE_RESULT": False, "AER_MPS_SVD_VALIDATE_RESULT": False}, "reconstruction checks contaminated phase diagnostics")
    setup = contract.get("environment_setup", {})
    require(setup.get("policy") == "reset_known_controls_before_aer_import"
            and setup.get("dispatch_threshold_source") == "explicit_argument"
            and setup.get("dispatch_threshold_elements") == 8401, "diagnostic environment was not explicitly prepared")
    expected_before = {"dispatch_threshold_elements": 8401,
                       "diagnostic_paths_enabled": {key: False for key in effective["diagnostic_paths_enabled"]},
                       "reconstruction_checks_enabled": effective["reconstruction_checks_enabled"]}
    same(setup.get("pre_import_effective_state"), expected_before, "inherited diagnostics were not cleared before import")
    preload = contract.get("diagnostic_cpu_lapack_preload")
    require(isinstance(preload, dict), "both devices require verified CPU LAPACK fallback profiling")
    require(preload.get("verification_sha256") == verification_hash, "cell profiler verification differs")
    for key in ("interposer", "lapack_library"):
        same(preload.get(key), verification[key], "cell profiler library identity differs: " + key)
    require(preload.get("preload") == verification["interposer"]["path"] + ":" + verification["lapack_library"]["path"], "unexpected preload libraries")
    require(preload.get("candidate_dependency_check") == "verified_library_matches_unpreloaded_ldd"
            and preload.get("performance_claims_permitted") is False, "profiler lacks candidate dependency verification")
    require(str(preload.get("profile_path", "")).replace("\\", "/").rsplit("/", 1)[-1] == "cpu_lapack.jsonl", "unexpected CPU log filename")
    events = read_events(directory / "svd.events.jsonl", "cutensor_csvd_wrapper")
    profiles = read_events(directory / "svd.profiles.jsonl", "cutensor_csvd_profile")
    decisions = read_events(directory / "svd.decisions.jsonl", "cutensor_svd_decision")
    gemms = read_events(directory / "cublas.events.jsonl", "cublas_zgemm")
    require(bool(decisions), "missing independent CPU/GPU dispatch decisions")
    require(all(row.get("device") == device and row.get("num_qubits") == spec["qubits"] for row in decisions), "decision device/input mismatch")
    require(Counter((r["rows"], r["columns"]) for r in decisions if r.get("decision") == "cutensor_csvd_wrapper")
            == Counter((r["rows"], r["columns"]) for r in events), "GPU submissions differ from eligible decisions")
    require(all(row.get("algorithm") == "GESVD" for row in profiles), "unregistered SVD algorithm")
    if device == "CPU" or spec["qubits"] <= 16:
        require(not gemms, "cuBLAS event violates source device/qubit eligibility")
    require(all(all(value > 128 for value in driver.dimensions(row, ("rows", "inner", "columns"))) for row in gemms), "cuBLAS matrix eligibility violated")
    recomputed = driver.summarize_gpu_records(events, profiles, gemms, decisions, require_ordered_shapes=evolution)
    cpu_records = read_events(directory / "cpu_lapack.jsonl", "cpu_lapack_call")
    expected_shapes = [driver.dimensions(row, ("rows", "columns")) for row in decisions if row["decision"] == "csvd_wrapper"]
    recomputed["cpu_lapack"] = cpu.summarize_cpu_lapack_records(cpu_records, expected_factor_shapes=expected_shapes)
    recomputed["cpu_lapack"]["coverage_basis"] = CPU_COVERAGE_BASIS
    recomputed["unmeasured"] = [item for item in recomputed["unmeasured"] if item != "CPU SVD phase time"]
    recomputed["unmeasured"].append("CPU SVD caller-side packing/allocation/reconstruction/truncation")
    progress = None
    if evolution:
        progress = driver.align_gate_progress(operations, driver.parse_native_log(metadata.get("MPS_log_data"), spec["qubits"]), spec["qubits"])
        require(all(row["max_bond_dimension"] <= 1024 for row in
                    (*progress["gate_progress"], *progress["internal_swap_progress"])), "native bond dimension exceeds the configured cap")
        same(read_json(directory / "logical_mps_progress.json"), progress, "saved logical MPS progress differs from native log")
    sample = metadata.get("sample_measure_time")
    require(sample is None or (type(sample) in (int, float) and math.isfinite(sample) and sample >= 0), "invalid native sampling interval")
    recomputed.update({"schema_version": 1, "status": "PASS", "mode": mode,
        "contract_sha256": sha256(directory / "contract.json"),
        "runtime_after_execution": summary["runtime_after_execution"], "performance_claims_permitted": False,
        "sample_measure_time_seconds": sample,
        "sample_measure_time_scope": "native sample_measure() call only, when metadata is available; not total measurement handling",
        "call_scope": "single measurement-free evolution" if evolution else "one 100-shot call including terminal sampling",
        "gate_correlation": "native rank log aligns to compiled gates; SVD/cuBLAS streams have no gate IDs and are not joined to particular gates",
        "files_sha256": {name: sha256(directory / name) for name in sorted(files)}})
    same(summary, recomputed, "saved P3 summary differs from recomputed raw evidence")
    return {"input_id": spec["id"], "workload": f"BW-{spec['qubits']}" if spec["kind"] == "brickwork" else "pQFT-16",
            "device": device, "mode": mode, "directory": entry["directory"],
            "compiled_qasm_sha256": compiled, "contract_sha256": sha256(directory / "contract.json"),
            "summary_sha256": sha256(directory / "summary.json"), "recomputed_summary": recomputed,
            "logical_mps_progress": progress}


def validate_run(run_dir):
    root = Path(run_dir).resolve()
    campaign = read_json(root / "campaign.json")
    require(campaign.get("schema_version") == 1 and campaign.get("kind") == "article2_p3_diagnostics", "unsupported P3 campaign")
    require(campaign.get("performance_claims_permitted") is False, "diagnostic campaign cannot authorize performance claims")
    same(campaign.get("policy"), POLICY, "P3 campaign policy differs from the approved experiment")
    require(campaign.get("source_revision") == PINNED_REVISION, "P3 campaign source revision differs")
    same(campaign.get("source_files_sha256"), SOURCE_HASHES, "P3 source fingerprints differ from audited a124257")
    require(re.fullmatch(r"[0-9a-f]{64}", str(campaign.get("extension_sha256", ""))), "invalid extension fingerprint")
    collection = read_json(root / "collection_manifest.json")
    campaign_hash = sha256(root / "campaign.json")
    require(collection.get("schema_version") == 1 and collection.get("campaign_sha256") == campaign_hash,
            "collection does not bind this frozen campaign")
    all_paths = list(root.rglob("*"))
    require(not any(path.is_symlink() for path in all_paths), "collection contains a symlink")
    actual_files = {path.relative_to(root).as_posix() for path in all_paths if path.is_file()
                    and "__pycache__" not in path.parts and path.suffix != ".pyc"}
    expected_files = actual_files - {"campaign.json", "collection_manifest.json", "validation.json"}
    hash_inventory(root, collection.get("files_sha256"), expected_names=expected_files)
    require(isinstance(campaign.get("runner_files_sha256"), dict)
            and RUNNER_FILES <= set(campaign["runner_files_sha256"]), "required runner snapshot files are missing")
    hash_inventory(root / "runner_snapshot", campaign["runner_files_sha256"])
    hash_inventory(root / "source_snapshot", campaign.get("source_files_sha256"), expected_names=SOURCE_HASHES)
    require(sha256(root / "manifest.json") == campaign.get("manifest_sha256"), "frozen pilot manifest file changed")
    manifest = read_json(root / "manifest.json")
    require(manifest.get("manifest_sha256") == campaign.get("scientific_manifest_sha256"), "canonical pilot manifest fingerprint differs")
    verification, verification_hash = validate_profiler(root, campaign)
    with archived_helpers(root) as (driver, e2, independent, cpu):
        require(driver.PINNED_REVISION == PINNED_REVISION and set(driver.SOURCE_FILES) == set(SOURCE_HASHES), "archived driver source contract differs")
        selected = validate_manifest(manifest, e2, independent)
        ids = [spec["id"] for spec in selected]
        same(campaign.get("inputs"), ids, "P3 selected input order or index differs")
        p2_binding = validate_p2_binding(root, campaign, manifest, ids)
        cells = campaign.get("cells")
        require(isinstance(cells, list) and len(cells) == 16, "P3 requires all 16 preselected cells")
        expected = {(input_id, device, mode) for input_id in ids for device in ("CPU", "GPU") for mode in ("evolution", "shots100")}
        require(all(isinstance(entry, dict) and set(entry) == {"input_id", "device", "mode", "directory"} for entry in cells), "invalid P3 cell inventory")
        observed = [(entry["input_id"], entry["device"], entry["mode"]) for entry in cells]
        require(len(set(observed)) == 16 and set(observed) == expected, "P3 cell inventory is missing, duplicated or out of scope")
        directories = [entry["directory"] for entry in cells]
        require(len(set(directories)) == 16 and len({name.casefold() for name in directories}) == 16, "duplicate cell directory")
        for name in directories:
            require(name.startswith("cells/") and relative_path(root, name).is_dir(), "cell directory must exist under cells/")
        linked = campaign.get("expected_compiled_qasm_sha256")
        if linked is not None:
            require(isinstance(linked, dict) and set(linked) == set(ids) and all(re.fullmatch(r"[0-9a-f]{64}", str(value)) for value in linked.values()), "P2 compiled-graph mapping must cover exactly the four inputs")
        by_id = {spec["id"]: spec for spec in selected}
        result = [validate_cell(root, entry, by_id[entry["input_id"]], campaign, driver, cpu,
                                verification, verification_hash) for entry in cells]
    for input_id in ids:
        for mode in ("evolution", "shots100"):
            require(len({cell["compiled_qasm_sha256"] for cell in result if cell["input_id"] == input_id and cell["mode"] == mode}) == 1,
                    "CPU/GPU compiled graphs differ")
    return {"schema_version": 1, "status": "PASS", "kind": "P3", "campaign_sha256": campaign_hash,
            "collection_manifest_sha256": sha256(root / "collection_manifest.json"), "source_revision": PINNED_REVISION,
            "cell_count": 16, "inputs": ids, "policy": POLICY,
            "measurement_graph_binding": "matched_to_archived_P2_graph_receipt", "p2_binding": p2_binding,
            "performance_claims_permitted": False, "cells": result,
            "scope": "Revalidated recorded diagnostics only; no Aer/GPU execution, library loading or speedup inference. "
                     "Payloads and copy bytes are source-derived; recorded phase boundaries overlap."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = validate_run(args.run_dir)
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, OverflowError) as error:
        print(json.dumps({"schema_version": 1, "status": "FAIL", "kind": "P3", "error": str(error)}, allow_nan=False))
        return 1
    print(json.dumps(report, sort_keys=True, separators=(",", ":"), allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
