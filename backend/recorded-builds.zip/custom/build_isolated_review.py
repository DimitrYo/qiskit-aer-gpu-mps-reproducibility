#!/usr/bin/env python3
"""Build one pinned Aer checkout without installing into the dependency venv.

Linux/WSL only. The destination must not exist. Failed builds and logs are kept.
The dependency environment is read-only input; the importable output is source/.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--dependencies", required=True, type=Path)
    parser.add_argument("--destination", required=True, type=Path)
    parser.add_argument("--cuda-arch", default="89")
    parser.add_argument("--backend", choices=("CUDA", "OMP"), default="CUDA")
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    if sys.platform != "linux" or args.jobs < 1:
        parser.error("Linux/WSL and positive jobs are required")
    source, deps, destination = (p.resolve() for p in
                                (args.source, args.dependencies, args.destination))
    python = deps / "bin/python"
    if not python.is_file() or destination.exists():
        parser.error("dependency interpreter must exist and destination must be new")
    revision = subprocess.check_output(
        ["git", "-C", str(source), "rev-parse", f"{args.revision}^{{commit}}"], text=True).strip()
    if len(revision) != 40:
        parser.error("revision did not resolve to a full commit SHA")
    destination.mkdir(parents=True)
    commands = []
    state = {"schema_version": 1, "status": "BUILDING", "source_revision": revision,
             "dependency_environment": str(deps), "destination": str(destination),
             "builder_sha256": sha256(Path(__file__)), "backend": args.backend, "commands": commands}
    record = destination / "isolated_build.json"

    def save():
        record.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")

    def run(command, log_name):
        command = [str(part) for part in command]
        commands.append({"argv": command, "log": log_name})
        save()
        print(f"[BUILD] {log_name}", flush=True)
        with (destination / log_name).open("w", encoding="utf-8") as stream:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"{log_name}: exit {result.returncode}")

    try:
        checkout = destination / "source"
        run(["git", "clone", "--no-hardlinks", "--no-checkout", source, checkout], "clone.log")
        run(["git", "-C", checkout, "checkout", "--detach", revision], "checkout.log")
        paths = json.loads(subprocess.check_output([str(python), "-c",
            "import json,sysconfig,pybind11; print(json.dumps({"
            "'include':sysconfig.get_path('include'),'libdir':sysconfig.get_config_var('LIBDIR'),"
            "'library':sysconfig.get_config_var('LDLIBRARY'),'site':sysconfig.get_path('purelib'),"
            "'pybind':pybind11.get_cmake_dir()}))"], text=True))
        libraries = [Path(paths["site"]) / "cuquantum/lib", Path("/usr/local/cuda/lib64")]
        rpath = ";".join(str(p) for p in libraries)
        build = destination / "cmake"
        configure = ["cmake", "-S", checkout, "-B", build, "-G", "Ninja",
            "-DCMAKE_BUILD_TYPE=Release", f"-DAER_THRUST_BACKEND={args.backend}", "-DDISABLE_CONAN=ON",
            f"-DPYTHON_EXECUTABLE={python}", f"-DPython_EXECUTABLE={python}",
            f"-DPYTHON_INCLUDE_DIR={paths['include']}",
            f"-DPYTHON_LIBRARY={Path(paths['libdir']) / paths['library']}",
            f"-Dpybind11_DIR={paths['pybind']}", f"-DCMAKE_BUILD_RPATH={rpath}",
            f"-DCMAKE_INSTALL_RPATH={rpath}", f"-DCMAKE_INSTALL_PREFIX={destination / 'install'}"]
        if args.backend == "CUDA":
            configure.extend(["-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc",
                f"-DCMAKE_CUDA_ARCHITECTURES={args.cuda_arch}",
                f"-DAER_CUDA_ARCH={args.cuda_arch[:-1]}.{args.cuda_arch[-1]}",
                f"-DAER_PYTHON_CUDA_ROOT={deps}"])
        run(configure, "configure.log")
        run(["cmake", "--build", build, "-j", args.jobs], "compile.log")
        extensions = list((build / "qiskit_aer/backends/wrappers").glob("controller_wrappers*.so"))
        if len(extensions) != 1:
            raise RuntimeError(f"expected one compiled extension, found {len(extensions)}")
        imported_extension = checkout / "qiskit_aer/backends" / extensions[0].name
        shutil.copy2(extensions[0], imported_extension)
        state.update({"status": "PASS", "source_directory": str(checkout),
                      "source_tree": subprocess.check_output(
                          ["git", "-C", str(checkout), "rev-parse", "HEAD^{tree}"], text=True).strip(),
                      "extension": str(imported_extension), "extension_sha256": sha256(imported_extension),
                      "cmake_cache_sha256": sha256(build / "CMakeCache.txt"),
                      "library_search_paths": [str(p) for p in libraries]})
        run(["ldd", imported_extension], "extension_ldd.log")
        save()
        print(f"PASS: {record}", flush=True)
        return 0
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        state.update({"status": "FAIL", "error": str(error)})
        save()
        print(f"FAIL: {error}; retained {destination}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
