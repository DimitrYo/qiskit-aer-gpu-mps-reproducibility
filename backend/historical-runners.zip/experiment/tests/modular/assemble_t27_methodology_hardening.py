#!/usr/bin/env python3
"""Assemble block-specific T27 results without pooling with T26."""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path
from typing import Any

from assemble_l4_evidence_bundle import comparison
from evidence_paths import resolve_frozen_manifest, resolve_run_local
from run_e2_numerical_correctness_pilot import load_manifest
from t27_interpretation import publication_interpretation


MANIFESTS_DIR = Path(__file__).resolve().parents[2] / "manifests"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path} must contain a JSON object")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def values(path: Path, circuit_id: str) -> list[float]:
    records = load_jsonl(path)
    selected = [
        float(record["elapsed_seconds"])
        for record in records
        if record.get("circuit_id") == circuit_id
    ]
    if len(selected) != 20:
        raise RuntimeError(f"{path} has {len(selected)} retained samples for {circuit_id}")
    return selected


def assemble(run_dir: Path) -> dict[str, Any]:
    run_dir = run_dir.resolve()
    output = run_dir / "t27_aggregate.json"
    if output.exists():
        raise RuntimeError(f"refusing to overwrite derived evidence: {output}")
    executor = load_json(run_dir / "t27_executor.json")
    if executor.get("task") != "T27" or executor.get("run_id") != run_dir.name:
        raise RuntimeError("T27 executor identity mismatch")
    manifest = load_manifest(
        resolve_frozen_manifest(
            executor["manifest_path"],
            executor["manifest_sha256"],
            manifests_dir=MANIFESTS_DIR,
            load_manifest=load_manifest,
        )
    )
    circuit_ids = [str(spec["id"]) for spec in manifest["circuits"]]

    thread_sensitivity: list[dict[str, Any]] = []
    sensitivity_id = "brickwork_n16_d24_s20260724"
    for item in executor["thread_sensitivity"]:
        threads = int(item["threads"])
        path = resolve_run_local(
            item["destination"],
            run_dir,
            Path("thread_sensitivity") / f"threads_{threads:02d}",
        ) / "custom_cpu.timings.jsonl"
        samples = values(path, sensitivity_id)
        thread_sensitivity.append(
            {
                "threads": threads,
                "sample_count": len(samples),
                "median_seconds": statistics.median(samples),
                "minimum_seconds": min(samples),
                "maximum_seconds": max(samples),
            }
        )

    per_repetition: list[dict[str, Any]] = []
    by_circuit: dict[str, list[dict[str, Any]]] = {
        circuit_id: [] for circuit_id in circuit_ids
    }
    for repetition in executor["primary_repetitions"]:
        index = int(repetition["repetition"])
        destination = resolve_run_local(
            repetition["destination"],
            run_dir,
            Path("primary") / f"repetition_{index:02d}",
        )
        order = list(repetition["backend_order"])
        for circuit_offset, circuit_id in enumerate(circuit_ids):
            cpu = values(destination / "custom_cpu.timings.jsonl", circuit_id)
            gpu = values(destination / "custom_gpu.timings.jsonl", circuit_id)
            result = {
                "repetition": index,
                "backend_order": order,
                "circuit_id": circuit_id,
                "cpu_median_seconds": statistics.median(cpu),
                "gpu_median_seconds": statistics.median(gpu),
                **comparison(
                    cpu,
                    gpu,
                    seed=20260725 + 100 * index + circuit_offset,
                ),
            }
            per_repetition.append(result)
            by_circuit[circuit_id].append(result)

    summaries: list[dict[str, Any]] = []
    for circuit_id, repetitions in by_circuit.items():
        ratios = [float(item["point_estimate"]) for item in repetitions]
        cpu_first = [
            float(item["point_estimate"])
            for item in repetitions
            if item["backend_order"][0] == "custom_cpu"
        ]
        gpu_first = [
            float(item["point_estimate"])
            for item in repetitions
            if item["backend_order"][0] == "custom_gpu"
        ]
        summaries.append(
            {
                "circuit_id": circuit_id,
                "repetition_count": len(repetitions),
                "gpu_cpu_ratio_median_across_repetitions": statistics.median(ratios),
                "gpu_cpu_ratio_range_across_repetitions": [min(ratios), max(ratios)],
                "cpu_gpu_speedup_median_across_repetitions": statistics.median(
                    1.0 / ratio for ratio in ratios
                ),
                "cpu_first_ratio_median": statistics.median(cpu_first),
                "gpu_first_ratio_median": statistics.median(gpu_first),
                "publication_interpretation": publication_interpretation(repetitions),
                "decision_rule": (
                    "All four within-campaign block-specific 95% interval "
                    "upper bounds below one confirm a GPU advantage; all four "
                    "lower bounds above one confirm a CPU advantage; all other "
                    "outcomes are inconclusive."
                ),
            }
        )

    diagnostic_report = load_json(
        resolve_run_local(
            executor["diagnostic"]["destination"],
            run_dir,
            Path("diagnostic"),
        )
        / "custom_gpu.report.json"
    )
    offload = {
        str(item["circuit_id"]): int(item["cutensor_csvd_wrapper_calls"])
        for item in diagnostic_report.get("offload_cells", [])
    }
    aggregate = {
        "schema_version": 2,
        "task": "T27",
        "run_id": run_dir.name,
        "analysis_policy": (
            "T27 within-campaign timing blocks are analyzed separately; T26 "
            "and T27 samples are not pooled."
        ),
        "thread_sensitivity": thread_sensitivity,
        "per_repetition": per_repetition,
        "circuit_summaries": summaries,
        "diagnostic_offload_calls": offload,
    }
    output.write_text(json.dumps(aggregate, indent=2) + "\n", encoding="utf-8")
    return aggregate


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        aggregate = assemble(args.run_dir)
        statuses = {
            item["circuit_id"]: item["publication_interpretation"]
            for item in aggregate["circuit_summaries"]
        }
        print(f"PASS: assembled T27 evidence: {statuses}")
        return 0
    except (OSError, KeyError, TypeError, ValueError, RuntimeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
