#!/usr/bin/env python3
"""Validate a complete T18 approximate-MPS accuracy study without timing it.

The validator accepts both passing and rejected accuracy cells, provided every
preregistered cap/backend cell is present and internally consistent.  It never
converts an absent custom-GPU event into offload evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from run_e2_numerical_correctness_pilot import load_manifest
from evidence_paths import resolve_run_local
from validate_e2_correctness import imports_selected_custom_build


HERE = Path(__file__).resolve().parent
EXPERIMENTS = HERE.parents[1]
DEFAULT_MANIFEST = EXPERIMENTS / "manifests" / "t18_approx_brickwork_14_d14.json"
SUMMARY_NAME = "t18_collection.json"
CAPS = (32, 64, 128)
BACKENDS = ("custom_cpu", "custom_gpu", "upstream_cpu")
FIDELITY_MIN = 0.999999
NORM_ERROR_MAX = 1.0e-10
FROZEN_MANIFEST_SHA256 = "1c3be5daeaf07a43a2a9f250639b9397565eca2c13fcf77f9a6532c4830d783b"


def load_object(path: Path, errors: list[str]) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        errors.append(f"cannot read {path.name}: {error}")
        return None
    if not isinstance(value, dict):
        errors.append(f"{path.name}: root must be an object")
        return None
    return value


def expected_ids(manifest: dict[str, object]) -> set[str]:
    circuits = manifest.get("circuits")
    if not isinstance(circuits, list):
        return set()
    return {str(spec["id"]) for spec in circuits if isinstance(spec, dict) and spec.get("exact_reference")}


def validate_gpu_observation(report: dict[str, Any], cap_dir: Path, errors: list[str]) -> None:
    proof = report.get("offload_proof")
    observation = report.get("offload_observation")
    if proof is not None:
        if observation != "OBSERVED" or not isinstance(proof, dict):
            errors.append("custom_gpu: malformed observed-offload record")
            return
        try:
            path = resolve_run_local(
                proof.get("events_path", ""), cap_dir.parent,
                Path(cap_dir.name) / "e2_custom_gpu.events.jsonl",
                kind="file", require_run_name=True,
            )
        except (OSError, ValueError, RuntimeError):
            errors.append("custom_gpu: observed event log is missing or outside its cap directory")
            return
        payload = path.read_bytes()
        if not payload.splitlines() or proof.get("event_count") != len(payload.splitlines()):
            errors.append("custom_gpu: observed event count does not match the log")
        if proof.get("event_sha256") != hashlib.sha256(payload).hexdigest():
            errors.append("custom_gpu: observed event log hash mismatch")
    elif observation == "NOT_OBSERVED":
        expected = cap_dir / "e2_custom_gpu.events.jsonl"
        try:
            resolve_run_local(
                report.get("offload_expected_events_path"), cap_dir.parent,
                Path(cap_dir.name) / expected.name, kind="path", require_run_name=True,
            )
        except (OSError, ValueError, RuntimeError):
            errors.append("custom_gpu: absent-event control has an unexpected events path")
        if expected.exists():
            errors.append("custom_gpu: absent-event control unexpectedly has an event log")
    else:
        errors.append("custom_gpu: requires observed offload proof or explicit NOT_OBSERVED control")


def validate_report(report: dict[str, Any], *, backend: str, cap: int, cap_run_id: str,
                    cap_dir: Path, manifest_hash: str, circuit_ids: set[str]) -> list[str]:
    errors: list[str] = []
    if report.get("run_id") != cap_run_id or report.get("backend") != backend:
        errors.append(f"{backend}: cap run identity mismatch")
    if report.get("status") not in {"PASS", "FAIL"}:
        errors.append(f"{backend}: report status must be PASS or FAIL")
    if report.get("purpose") != "E2 numerical-correctness pilot only; no timing or performance claims.":
        errors.append(f"{backend}: report purpose permits a non-T18 claim")
    if report.get("performance_claims_permitted") is not False or report.get("manifest_sha256") != manifest_hash:
        errors.append(f"{backend}: provenance or performance boundary mismatch")
    driver_hash = report.get("driver_sha256")
    if not isinstance(driver_hash, str) or len(driver_hash) != 64:
        errors.append(f"{backend}: missing E2 driver hash")
    aer_path = Path(str(report.get("aer_path", "")))
    local = imports_selected_custom_build(aer_path)
    if backend.startswith("custom_") and not local:
        errors.append(f"{backend}: does not import the selected custom build")
    if backend == "upstream_cpu" and local:
        errors.append("upstream_cpu imports the selected custom build")
    config = report.get("simulation_config")
    if not isinstance(config, dict):
        errors.append(f"{backend}: missing simulation configuration")
    elif (config.get("method"), config.get("device"), config.get("max_bond_dimension"),
          config.get("truncation_threshold")) != ("matrix_product_state", "GPU" if backend == "custom_gpu" else "CPU", cap, 0.0):
        errors.append(f"{backend}: configuration differs from preregistered cap-only grid")
    records = report.get("records")
    seen: set[str] = set()
    statuses: list[str] = []
    if not isinstance(records, list) or not records:
        errors.append(f"{backend}: missing exact-reference records")
    else:
        for record in records:
            if not isinstance(record, dict):
                errors.append(f"{backend}: invalid record")
                continue
            circuit_id = record.get("circuit_id")
            if isinstance(circuit_id, str):
                seen.add(circuit_id)
            else:
                errors.append(f"{backend}: record lacks circuit ID")
            reference, mps = record.get("reference"), record.get("mps")
            if not isinstance(reference, dict) or not isinstance(mps, dict):
                errors.append(f"{backend}:{circuit_id}: missing reference or MPS metrics")
                continue
            try:
                if float(reference["fidelity"]) < float(reference["fidelity_min"]):
                    errors.append(f"{backend}:{circuit_id}: exact references disagree")
                if float(mps["fidelity_min"]) != FIDELITY_MIN or float(mps["norm_error_max"]) != NORM_ERROR_MAX:
                    errors.append(f"{backend}:{circuit_id}: acceptance threshold differs from T18")
                status = record.get("status")
                expected = (float(mps["fidelity"]) >= FIDELITY_MIN and
                            float(mps["norm_error"]) <= NORM_ERROR_MAX)
                if status != ("PASS" if expected else "FAIL"):
                    errors.append(f"{backend}:{circuit_id}: status does not match recorded T18 metrics")
                statuses.append(str(status))
            except (KeyError, TypeError, ValueError):
                errors.append(f"{backend}:{circuit_id}: invalid numerical metrics")
    if seen != circuit_ids:
        errors.append(f"{backend}: exact-reference circuit set differs from manifest")
    if statuses and report.get("status") != ("PASS" if all(item == "PASS" for item in statuses) else "FAIL"):
        errors.append(f"{backend}: report status does not match record statuses")
    if backend == "custom_gpu":
        validate_gpu_observation(report, cap_dir, errors)
    return errors


def validate(run_dir: Path, *, manifest_path: Path = DEFAULT_MANIFEST) -> list[str]:
    run_dir = run_dir.resolve()
    errors: list[str] = []
    manifest = load_manifest(manifest_path)
    summary = load_object(run_dir / SUMMARY_NAME, errors)
    if summary is None:
        return errors
    if summary.get("run_id") != run_dir.name:
        errors.append("collection summary run_id mismatch")
    if (manifest.get("manifest_sha256") != FROZEN_MANIFEST_SHA256 or
            summary.get("purpose") != "T18 preregistered approximate-MPS accuracy grid only; no timing or performance claims." or
            summary.get("performance_claims_permitted") is not False or
            summary.get("manifest_sha256") != manifest.get("manifest_sha256")):
        errors.append("collection summary has an invalid scope or manifest")
    collection_hash = summary.get("driver_sha256")
    if not isinstance(collection_hash, str) or len(collection_hash) != 64:
        errors.append("collection summary lacks a driver hash")
    if tuple(summary.get("caps", [])) != CAPS or summary.get("truncation_threshold") != 0.0:
        errors.append("collection summary differs from the preregistered cap-only grid")
    if (summary.get("mps_fidelity_min") != FIDELITY_MIN or
            summary.get("norm_error_max") != NORM_ERROR_MAX):
        errors.append("collection summary differs from the preregistered accuracy thresholds")
    if summary.get("custom_gpu_offload_policy") != (
            "NOT_OBSERVED is a retained control result, never offload evidence and never a timing authorization."):
        errors.append("collection summary has an invalid custom-GPU offload policy")
    cap_runs = summary.get("cap_runs")
    if not isinstance(cap_runs, list) or len(cap_runs) != len(CAPS):
        return errors + ["collection summary lacks one record per preregistered cap"]
    expected_circuits = expected_ids(manifest)
    e2_driver_hashes: set[str] = set()
    for cap, item in zip(CAPS, cap_runs, strict=True):
        if not isinstance(item, dict) or item.get("cap") != cap:
            errors.append(f"chi={cap}: malformed cap summary")
            continue
        cap_dir = run_dir / f"chi_{cap:03d}"
        cap_run_id = f"{run_dir.name}__chi{cap:03d}"
        if item.get("run_id") != cap_run_id or item.get("directory") != cap_dir.name:
            errors.append(f"chi={cap}: cap identity mismatch")
        results = item.get("backend_results")
        if not isinstance(results, list) or {result.get("backend") for result in results if isinstance(result, dict)} != set(BACKENDS):
            errors.append(f"chi={cap}: collection summary lacks a backend result")
        for backend in BACKENDS:
            report = load_object(cap_dir / f"e2_{backend}.json", errors)
            if report is not None:
                if isinstance(report.get("driver_sha256"), str):
                    e2_driver_hashes.add(report["driver_sha256"])
                errors.extend(validate_report(
                    report, backend=backend, cap=cap, cap_run_id=cap_run_id,
                    cap_dir=cap_dir, manifest_hash=str(manifest["manifest_sha256"]),
                    circuit_ids=expected_circuits,
                ))
    if len(e2_driver_hashes) != 1:
        errors.append("T18 reports were not produced by one E2 driver revision")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    args = parser.parse_args()
    try:
        errors = validate(args.run_dir, manifest_path=args.manifest)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        errors = [str(error)]
    if errors:
        print("BLOCKED: " + "; ".join(errors))
        return 1
    print(f"PASS: T18 accuracy evidence {args.run_dir.name} is complete and internally consistent; no timing claim is authorized.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
