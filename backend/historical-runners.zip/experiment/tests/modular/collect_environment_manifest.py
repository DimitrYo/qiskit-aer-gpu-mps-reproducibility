#!/usr/bin/env python3
"""Collect reproducibility metadata for one Article 2 run without third-party tools."""

from __future__ import annotations

import argparse
import importlib.metadata as metadata
import json
import os
import platform
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path


def command_output(command: list[str]) -> str | None:
    executable = shutil.which(command[0])
    if executable is None:
        return None
    result = subprocess.run([executable, *command[1:]], text=True, capture_output=True)
    return result.stdout.strip() if result.returncode == 0 else None


def package_version(name: str) -> str | None:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--backend", choices=("cpu", "gpu", "custom_gpu"), required=True)
    args = parser.parse_args()

    manifest = {
        "run_id": args.run_id,
        "backend": args.backend,
        "captured_at": datetime.now(UTC).isoformat(),
        "platform": platform.platform(),
        "kernel": platform.release(),
        "python": sys.version,
        "python_executable": sys.executable,
        "gpu": command_output(["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"]),
        "nvcc": command_output(["nvcc", "--version"]),
        "environment": {
            name: os.environ.get(name)
            for name in (
                "ARTICLE2_CUSTOM_ENV_NAME",
                "AER_THRUST_BACKEND",
                "AER_ENABLE_CUTENSORNET",
                "QISKIT_AER_PACKAGE_NAME",
                "OMP_NUM_THREADS",
            )
        },
        "packages": {
            name: package_version(name)
            for name in ("qiskit", "qiskit-aer", "qiskit-aer-gpu", "cuquantum-cu12")
        },
    }
    try:
        import qiskit_aer
        from qiskit_aer import AerSimulator

        manifest["aer"] = {
            "source_path": str(Path(qiskit_aer.__file__).resolve()),
            "version": qiskit_aer.__version__,
            "available_devices": AerSimulator().available_devices(),
        }
    except Exception as error:  # Manifest collection must still capture failed imports.
        manifest["aer"] = {"error": str(error)}

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
