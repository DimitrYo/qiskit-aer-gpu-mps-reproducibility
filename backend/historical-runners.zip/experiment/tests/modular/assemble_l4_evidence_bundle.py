#!/usr/bin/env python3
"""Assemble a validated, immutable Article 2 L4 evidence bundle.

This joins same-run E2 reports with a completed production E3 collection.  It
does not execute circuits and refuses smoke output, mismatched manifests, or
existing derived evidence.  The aggregate contains a predeclared, deterministic
bootstrap comparison: a GPU advantage is confirmed for a circuit only when the
two-sided 95% bootstrap interval for GPU-median / CPU-median is wholly below 1.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
import sys
from pathlib import Path
from typing import Any

from run_e2_numerical_correctness_pilot import load_manifest
from validate_e2_correctness import validate as validate_e2
from validate_run_evidence import validate_run_directory


REPORTS = {"custom_gpu": "e2_custom_gpu.json", "custom_cpu": "e2_custom_cpu.json", "upstream_cpu": "e2_upstream_cpu.json"}
DERIVED = ("correctness_raw.jsonl", "aggregate.json")
BOOTSTRAP_REPLICATIONS = 10_000
BOOTSTRAP_SEED = 20260722


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path.name} must contain an object")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    low, high = math.floor(position), math.ceil(position)
    return ordered[low] if low == high else ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def comparison(cpu: list[float], gpu: list[float], *, seed: int) -> dict[str, Any]:
    """Return independent-resampling bootstrap evidence for a single cell."""
    rng = random.Random(seed)
    ratios: list[float] = []
    for _ in range(BOOTSTRAP_REPLICATIONS):
        cpu_median = statistics.median(rng.choice(cpu) for _ in cpu)
        gpu_median = statistics.median(rng.choice(gpu) for _ in gpu)
        ratios.append(gpu_median / cpu_median)
    interval = [quantile(ratios, 0.025), quantile(ratios, 0.975)]
    point_ratio = statistics.median(gpu) / statistics.median(cpu)
    return {
        "metric": "gpu_median_seconds / cpu_median_seconds",
        "point_estimate": point_ratio,
        "bootstrap": {"method": "independent nonparametric resampling of each 20-sample cell", "replications": BOOTSTRAP_REPLICATIONS, "seed": seed, "confidence_level": 0.95, "interval": interval},
        "advantage_status": "CONFIRMED" if interval[1] < 1.0 else "NOT_CONFIRMED",
        "interpretation": "GPU is faster under this protocol only when the interval upper bound is below 1.",
    }


def aggregate_cell(circuit_id: str, backend: str, records: list[dict[str, Any]], warmups: list[dict[str, Any]]) -> dict[str, Any]:
    values = [float(record["elapsed_seconds"]) for record in records]
    return {
        "circuit_id": circuit_id, "backend": backend,
        "simulation_config": records[0]["simulation_config"],
        "warmup_sample_count": len(warmups), "timed_sample_count": len(values),
        "median_seconds": statistics.median(values), "mean_seconds": statistics.fmean(values),
        "sample_standard_deviation_seconds": statistics.stdev(values),
        "minimum_seconds": min(values), "maximum_seconds": max(values),
    }


def assemble(run_dir: Path, manifest_path: Path) -> None:
    run_dir, manifest_path = run_dir.resolve(), manifest_path.resolve()
    if not run_dir.is_dir():
        raise RuntimeError(f"run directory does not exist: {run_dir}")
    existing = [name for name in DERIVED if (run_dir / name).exists()]
    if existing:
        raise RuntimeError(f"refusing to overwrite derived evidence: {', '.join(existing)}")
    manifest = load_manifest(manifest_path)
    expected_circuits = {str(spec["id"]) for spec in manifest["circuits"]}
    if not all(bool(spec.get("exact_reference")) for spec in manifest["circuits"]):
        raise RuntimeError("L4 manifest must give every timed circuit an exact-reference E2 control")
    executor = load_json(run_dir / "e3_executor.json")
    if executor.get("run_id") != run_dir.name or executor.get("publication_evidence") is not True or executor.get("full_l4_validation_eligible") is not True:
        raise RuntimeError("E3 run is smoke/non-production or has a mismatched run_id")
    if executor.get("manifest_sha256") != manifest["manifest_sha256"]:
        raise RuntimeError("E3 manifest hash differs from the frozen L4 manifest")
    protocol = executor.get("protocol")
    if not isinstance(protocol, dict) or (protocol.get("warmups"), protocol.get("timed_repetitions")) != (5, 20):
        raise RuntimeError("E3 production protocol must be exactly five warm-ups and twenty timed repetitions")
    errors = validate_e2(run_dir)
    if errors:
        raise RuntimeError("invalid same-run E2 reports: " + "; ".join(errors))
    reports = {backend: load_json(run_dir / filename) for backend, filename in REPORTS.items()}
    if any(report.get("manifest_sha256") != manifest["manifest_sha256"] for report in reports.values()):
        raise RuntimeError("E2 manifest hash differs from the frozen L4 manifest")
    correctness: list[dict[str, Any]] = []
    for backend, report in reports.items():
        for record in report["records"]:
            if record["circuit_id"] not in expected_circuits:
                raise RuntimeError("E2 report contains a circuit outside the L4 manifest")
            correctness.append({"run_id": run_dir.name, "circuit_id": record["circuit_id"], "backend": backend,
                                "fidelity": record["mps"]["fidelity"], "norm_error": record["mps"]["norm_error"],
                                "qasm_sha256": record["qasm_sha256"], "source_report": REPORTS[backend]})
    if {item["circuit_id"] for item in correctness} != expected_circuits:
        raise RuntimeError("E2 reports do not cover exactly the frozen L4 timing circuits")
    timings, warmups = load_jsonl(run_dir / "timings_raw.jsonl"), load_jsonl(run_dir / "warmups_raw.jsonl")
    keys = {(str(item["circuit_id"]), str(item["backend"])) for item in timings}
    if {key[0] for key in keys} != expected_circuits:
        raise RuntimeError("E3 timing records do not cover exactly the frozen L4 circuits")
    cells: list[dict[str, Any]] = []
    comparisons: list[dict[str, Any]] = []
    for circuit_id in sorted(expected_circuits):
        values: dict[str, list[dict[str, Any]]] = {}
        for backend in ("custom_cpu", "custom_gpu"):
            values[backend] = [record for record in timings if record["circuit_id"] == circuit_id and record["backend"] == backend]
            cell_warmups = [record for record in warmups if record["circuit_id"] == circuit_id and record["backend"] == backend]
            cells.append(aggregate_cell(circuit_id, backend, values[backend], cell_warmups))
        comparisons.append({"circuit_id": circuit_id, **comparison([float(x["elapsed_seconds"]) for x in values["custom_cpu"]], [float(x["elapsed_seconds"]) for x in values["custom_gpu"]], seed=BOOTSTRAP_SEED + len(comparisons))})
    (run_dir / "correctness_raw.jsonl").write_text("".join(json.dumps(item, sort_keys=True) + "\n" for item in correctness), encoding="utf-8")
    aggregate = {"run_id": run_dir.name, "schema_version": 1, "cells": cells, "comparisons": comparisons,
                 "overall_gpu_advantage_status": "CONFIRMED" if comparisons and all(item["advantage_status"] == "CONFIRMED" for item in comparisons) else "NOT_CONFIRMED"}
    (run_dir / "aggregate.json").write_text(json.dumps(aggregate, indent=2), encoding="utf-8")
    status, diagnostics = validate_run_directory(run_dir)
    if status:
        # Do not leave an invalid bundle that could be mistaken for evidence.
        for name in DERIVED:
            (run_dir / name).unlink(missing_ok=True)
        raise RuntimeError("assembled bundle failed validation: " + "; ".join(diagnostics))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    try:
        assemble(args.run_dir, args.manifest)
        print(f"PASS: assembled L4 evidence bundle {args.run_dir.name}")
        return 0
    except (OSError, KeyError, TypeError, ValueError, RuntimeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
