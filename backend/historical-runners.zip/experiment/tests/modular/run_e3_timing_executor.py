#!/usr/bin/env python3
"""Run isolated E3 MPS timing cells and publish their raw run bundle.

The executor serializes environments, refusing an existing run directory so a
run identifier is immutable.  ``--smoke`` is intentionally non-publication:
it uses one warm-up and two samples, while the normal protocol is 5/20.
It produces raw records only; aggregation, figures, and Article claims stay
blocked until the redesigned L4 validator accepts the completed bundle.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from run_e2_numerical_correctness_pilot import DEFAULT_MANIFEST, load_manifest


TESTS_DIR = Path(__file__).resolve().parent
EXPERIMENTS_DIR = TESTS_DIR.parents[1]
CODE_DIR = EXPERIMENTS_DIR.parent
DEFAULT_RUNS_ROOT = Path(__file__).resolve().parents[2] / "new_runs"
CELL_DRIVER = TESTS_DIR / "run_e3_timing_cell.py"


def environment_python(environment: str) -> Path:
    candidate = EXPERIMENTS_DIR / environment / ("bin/python" if sys.platform.startswith("linux") else "Scripts/python.exe")
    if not candidate.is_file():
        raise RuntimeError(f"environment interpreter does not exist: {candidate}")
    return candidate


def concatenate_new(destination: Path, sources: list[Path]) -> None:
    if destination.exists():
        raise RuntimeError(f"refusing to overwrite evidence: {destination}")
    destination.write_bytes(b"".join(source.read_bytes() for source in sources))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument("--custom-environment", default=".venv_custom_gpu_pr2168_20260721")
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--timed-repetitions", type=int, default=20)
    parser.add_argument("--shots", type=int, default=100)
    parser.add_argument("--max-bond-dimension", type=int, default=128)
    parser.add_argument("--truncation-threshold", type=float, default=0.0)
    parser.add_argument("--seed-simulator", type=int, default=20260722)
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    parser.add_argument("--smoke", action="store_true", help="Use 1 warm-up and 2 timings; never publication evidence.")
    args = parser.parse_args()
    run_dir = args.runs_root / args.run_id
    try:
        if run_dir.exists():
            raise RuntimeError(f"refusing to reuse existing run directory: {run_dir}")
        if not args.run_id.replace("-", "").replace("_", "").replace(".", "").isalnum():
            raise RuntimeError("run_id may contain only letters, digits, dot, underscore, and hyphen")
        manifest = load_manifest(args.manifest)
        if args.smoke:
            if (args.warmups, args.timed_repetitions) != (5, 20):
                raise RuntimeError("--smoke cannot be combined with explicit non-default sample counts")
            args.warmups, args.timed_repetitions = 1, 2
        elif (args.warmups, args.timed_repetitions) != (5, 20):
            raise RuntimeError("production E3 requires exactly 5 warm-ups and 20 timed repetitions; use --smoke")
        if min(args.warmups, args.timed_repetitions, args.shots) < 1:
            raise RuntimeError("warmups, timed repetitions, and shots must be positive")
        custom_python = environment_python(args.custom_environment)
        run_dir.mkdir(parents=True)
        raw_dir = run_dir / "raw_cells"
        # E3 is a matched execution comparison inside the custom build.  The
        # upstream CPU environment remains an E2 integration/correctness
        # control, deliberately outside performance timing.
        backends = (("custom_cpu", custom_python), ("custom_gpu", custom_python))
        reports: list[dict[str, object]] = []
        for backend, python_bin in backends:
            warmups_path = raw_dir / f"{backend}.warmups.jsonl"
            timings_path = raw_dir / f"{backend}.timings.jsonl"
            report_path = raw_dir / f"{backend}.report.json"
            command = [str(python_bin), str(CELL_DRIVER), "--manifest", str(args.manifest.resolve()),
                       "--backend", backend, "--run-id", args.run_id,
                       "--warmups-output", str(warmups_path), "--timings-output", str(timings_path),
                       "--report-output", str(report_path), "--warmups", str(args.warmups),
                       "--timed-repetitions", str(args.timed_repetitions), "--shots", str(args.shots),
                       "--max-bond-dimension", str(args.max_bond_dimension),
                       "--truncation-threshold", str(args.truncation_threshold),
                       "--seed-simulator", str(args.seed_simulator), "--seed-transpiler", str(args.seed_transpiler)]
            if backend == "custom_gpu":
                command += ["--events-dir", str(run_dir / "cutensornet_events")]
            print("[E3]", backend, "via", python_bin, flush=True)
            result = subprocess.run(command, text=True)
            if result.returncode:
                raise RuntimeError(f"{backend} timing cell failed; preserved partial evidence in {run_dir}")
            reports.append(json.loads(report_path.read_text(encoding="utf-8")))
        concatenate_new(run_dir / "warmups_raw.jsonl", [raw_dir / f"{name}.warmups.jsonl" for name, _ in backends])
        concatenate_new(run_dir / "timings_raw.jsonl", [raw_dir / f"{name}.timings.jsonl" for name, _ in backends])
        custom_report = next(report for report in reports if report["backend"] == "custom_gpu")
        (run_dir / "offload_proof.json").write_text(json.dumps({
            "run_id": args.run_id, "status": "PASS", "cells": custom_report["offload_cells"],
        }, indent=2), encoding="utf-8")
        (run_dir / "e3_executor.json").write_text(json.dumps({
            "schema_version": 1, "run_id": args.run_id, "status": "PASS",
            "manifest_path": str(args.manifest.resolve()), "manifest_sha256": manifest["manifest_sha256"],
            "publication_evidence": not args.smoke,
            "full_l4_validation_eligible": not args.smoke,
            "protocol": {"warmups": args.warmups, "timed_repetitions": args.timed_repetitions, "shots": args.shots},
            "cells": reports,
        }, indent=2), encoding="utf-8")
        print(f"PASS: E3 raw evidence written to {run_dir}")
        return 0
    except RuntimeError as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
