#!/usr/bin/env python3
"""Validate one profiled GPU-MPS crossover calibration run.

This gate is intentionally narrower than Article 2 L4 publication evidence:
it validates exact-SVD phase diagnostics plus matched end-to-end timing, but
does not convert either metric into a general performance claim.
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from crossover_profile import load_jsonl, summarize, validate_records
from assemble_l4_evidence_bundle import comparison
from run_e2_numerical_correctness_pilot import load_manifest
from evidence_paths import resolve_frozen_manifest as resolve_manifest_by_hash, resolve_run_local
from validate_e2_correctness import validate as validate_e2
from validate_run_evidence import (
    COMPARABLE_CONFIG_FIELDS,
    TIMING_BACKENDS,
    load_json,
    stable_json,
    validate_measurement_records,
    validate_simulation_config,
)


MANIFESTS_DIR = Path(__file__).resolve().parents[2] / "manifests"


REQUIRED_FILES = (
    "crossover_executor.json", "environment_manifest.json", "build_manifest.json",
    "e2_custom_gpu.json", "e2_custom_cpu.json", "e2_upstream_cpu.json",
    "crossover_diagnostic.json", "offload_proof.json", "profile_summary.json", "warmups_raw.jsonl",
    "timings_raw.jsonl", "crossover_aggregate.json",
)


def resolve_frozen_manifest(recorded_path: str, expected_sha256: object) -> Path:
    """Resolve a frozen manifest after an evidence bundle is cloned elsewhere.

    The recorded absolute path remains provenance metadata.  If it is absent,
    revalidation may use one, and only one, repository manifest whose validated
    canonical hash equals the recorded hash.  This prevents a path rewrite
    from silently substituting an experimental input.
    """
    return resolve_manifest_by_hash(
        recorded_path,
        expected_sha256,
        manifests_dir=MANIFESTS_DIR,
        load_manifest=load_manifest,
    )


def resolve_profile_path(recorded_path: object, run_dir: Path, *, circuit_id: str) -> Path | None:
    """Resolve a profile within its immutable run bundle after relocation."""
    try:
        return resolve_run_local(
            recorded_path, run_dir,
            Path("cutensornet_profiles") / f"{circuit_id}.profile.jsonl",
            kind="file", require_run_name=True,
        )
    except (OSError, ValueError, RuntimeError):
        return None


def same_number(observed: object, expected: float) -> bool:
    try:
        return math.isclose(
            float(observed), expected, rel_tol=1.0e-12, abs_tol=1.0e-12
        )
    except (TypeError, ValueError):
        return False


def validate_run_directory(run_dir: Path) -> tuple[int, list[str]]:
    missing = [name for name in REQUIRED_FILES if not (run_dir / name).is_file()]
    if missing:
        return 2, [f"BLOCKED missing crossover evidence: {', '.join(missing)}"]
    try:
        executor = load_json(run_dir / "crossover_executor.json")
        environment = load_json(run_dir / "environment_manifest.json")
        build = load_json(run_dir / "build_manifest.json")
        diagnostic = load_json(run_dir / "crossover_diagnostic.json")
        offload = load_json(run_dir / "offload_proof.json")
        profile_summary = load_json(run_dir / "profile_summary.json")
        aggregate = load_json(run_dir / "crossover_aggregate.json")
        timings = load_jsonl(run_dir / "timings_raw.jsonl")
        warmups = load_jsonl(run_dir / "warmups_raw.jsonl")
    except (OSError, ValueError, json.JSONDecodeError) as error:
        return 1, [f"FAIL invalid crossover evidence: {error}"]
    run_id = run_dir.name
    errors: list[str] = []
    if executor.get("run_id") != run_id or executor.get("status") != "PASS":
        errors.append("crossover executor has a different run_id or non-PASS status")
    if executor.get("measurement_mode") != "end_to_end_mps_with_terminal_measurements":
        errors.append("crossover executor has an unexpected measurement mode")
    if executor.get("timing_instrumentation") != "none":
        errors.append("crossover timing samples were not collected without recorder instrumentation")
    executor_cells = executor.get("cells")
    if not isinstance(executor_cells, list):
        errors.append("crossover executor lacks per-backend timing reports")
    else:
        gpu_cells = [cell for cell in executor_cells if isinstance(cell, dict) and cell.get("backend") == "custom_gpu"]
        if len(gpu_cells) != 1:
            errors.append("crossover executor lacks exactly one custom-GPU timing report")
        else:
            gpu_cell = gpu_cells[0]
            if (gpu_cell.get("instrumentation_mode") != "none" or gpu_cell.get("offload_cells") or
                    gpu_cell.get("profile_cells") or gpu_cell.get("decision_cells")):
                errors.append("custom-GPU timing report contains recorder instrumentation evidence")
    protocol = executor.get("protocol")
    if not isinstance(protocol, dict) or (protocol.get("warmups"), protocol.get("timed_repetitions"), protocol.get("shots")) != (5, 20, 100):
        errors.append("crossover executor does not record the fixed 5/20/100 protocol")
    threshold = executor.get("dispatch_threshold_elements")
    if not isinstance(threshold, int) or isinstance(threshold, bool) or threshold < 1:
        errors.append("crossover executor lacks a positive dispatch threshold")
        threshold = 0
    wall_time = executor.get("cell_wall_time_seconds")
    if not isinstance(wall_time, (int, float)) or isinstance(wall_time, bool) or float(wall_time) <= 0:
        errors.append("crossover executor lacks a positive declared cell wall-time limit")
    for name, document in (("environment manifest", environment), ("build manifest", build),
                           ("crossover aggregate", aggregate)):
        if document.get("run_id") != run_id:
            errors.append(f"{name} has a different run_id")
    aer = environment.get("aer")
    if not isinstance(aer, dict) or not isinstance(aer.get("source_path"), str) or "GPU" not in aer.get("available_devices", []):
        errors.append("environment manifest lacks custom Aer GPU provenance")
    source = build.get("source")
    if (not isinstance(source, dict) or not isinstance(source.get("path"), str) or not source.get("commit")
            or not build.get("cmake_cuda_enabled") or not build.get("cutensornet_enabled")):
        errors.append("build manifest lacks CUDA/cuTensorNet source provenance")
    elif isinstance(aer, dict) and isinstance(aer.get("source_path"), str) and source["path"] not in aer["source_path"]:
        errors.append("environment Aer import does not originate from the recorded custom build")
    manifest_path = executor.get("manifest_path")
    if not isinstance(manifest_path, str):
        errors.append("crossover executor lacks a manifest path")
        manifest: dict[str, Any] | None = None
    else:
        try:
            manifest = load_manifest(resolve_frozen_manifest(manifest_path, executor.get("manifest_sha256")))
        except RuntimeError as error:
            errors.append(f"cannot load frozen crossover manifest: {error}")
            manifest = None
        else:
            if executor.get("manifest_sha256") != manifest.get("manifest_sha256"):
                errors.append("crossover executor manifest hash does not match the frozen manifest")
    if diagnostic.get("run_id") != run_id or diagnostic.get("status") != "PASS":
        errors.append("crossover diagnostic has a different run_id or non-PASS status")
    if diagnostic.get("performance_claims_permitted") is not False:
        errors.append("crossover diagnostic must explicitly prohibit performance claims")
    if diagnostic.get("manifest_sha256") != executor.get("manifest_sha256"):
        errors.append("crossover diagnostic manifest differs from raw timing")
    if diagnostic.get("dispatch_threshold_elements") != threshold:
        errors.append("crossover diagnostic threshold differs from raw timing")
    diagnostic_config = diagnostic.get("simulation_config")
    if not isinstance(diagnostic_config, dict):
        errors.append("crossover diagnostic lacks a simulation configuration")
    else:
        for field in ("max_bond_dimension", "truncation_threshold", "seed_simulator", "seed_transpiler"):
            if diagnostic_config.get(field) != executor.get(field):
                errors.append(f"crossover diagnostic configuration differs from raw timing for {field}")
        if diagnostic_config.get("device") != "GPU":
            errors.append("crossover diagnostic does not select GPU")
    diagnostic_instrumentation = diagnostic.get("instrumentation")
    if diagnostic_instrumentation != {"events": True, "profiles": True, "decisions": True}:
        errors.append("crossover diagnostic does not enable all required opt-in recorders")
    diagnostic_cell = diagnostic.get("cell_report")
    if not isinstance(diagnostic_cell, dict) or diagnostic_cell.get("instrumentation_mode") != "opt_in_recorder":
        errors.append("crossover diagnostic lacks an instrumented custom-GPU cell report")
    e2_errors = validate_e2(run_dir)
    errors.extend(f"same-run E2: {error}" for error in e2_errors)

    timing_cells = validate_measurement_records(timings, run_id=run_id, label="timing", expected_warmup=False,
                                                expected_count=20, allowed_backends=TIMING_BACKENDS, errors=errors)
    warmup_cells = validate_measurement_records(warmups, run_id=run_id, label="warm-up", expected_warmup=True,
                                                expected_count=5, allowed_backends=TIMING_BACKENDS, errors=errors)
    if set(timing_cells) != set(warmup_cells):
        errors.append("warm-up and timing cell sets differ")
    circuits: dict[str, set[str]] = defaultdict(set)
    for circuit_id, backend in timing_cells:
        circuits[circuit_id].add(backend)
    for circuit_id, backends in circuits.items():
        if backends != TIMING_BACKENDS:
            errors.append(f"circuit {circuit_id} lacks matched custom-CPU/custom-GPU cells")
            continue
        configs: set[str] = set()
        for backend in TIMING_BACKENDS:
            config = validate_simulation_config(timing_cells[(circuit_id, backend)], f"timing cell {(circuit_id, backend)}", errors)
            if config is not None:
                configs.add(stable_json({key: config[key] for key in COMPARABLE_CONFIG_FIELDS}))
        if len(configs) != 1:
            errors.append(f"circuit {circuit_id} has unmatched CPU/GPU configurations")
    if manifest is not None:
        expected = {str(spec["id"]) for spec in manifest["circuits"]}
        if set(circuits) != expected:
            errors.append("timing circuits do not exactly cover the frozen crossover manifest")

    if offload.get("run_id") != run_id or offload.get("status") != "PASS":
        errors.append("offload proof has a different run_id or non-PASS status")
    if offload.get("source") != "instrumented_crossover_diagnostic" or offload.get("performance_claims_permitted") is not False:
        errors.append("offload proof is not a separately labelled non-timing diagnostic")
    proof_keys: set[tuple[str, str]] = set()
    cells = offload.get("cells")
    if not isinstance(cells, list):
        errors.append("offload proof lacks a cells list")
        cells = []
    for number, cell in enumerate(cells, start=1):
        if not isinstance(cell, dict) or cell.get("backend") != "custom_gpu":
            errors.append(f"offload proof cell {number} is not a custom-GPU object")
            continue
        circuit_id = cell.get("circuit_id")
        if not isinstance(circuit_id, str) or int(cell.get("cutensor_csvd_wrapper_calls", 0)) < 1:
            errors.append(f"offload proof cell {number} lacks an executed SVD call")
            continue
        proof_keys.add((circuit_id, "custom_gpu"))
    required_profiles = {
        key for key, record in timing_cells.items()
        if key[1] == "custom_gpu" and record.get("offload_required") is True
    }
    timing_gpu_keys = {key for key in timing_cells if key[1] == "custom_gpu"}
    if not required_profiles.issubset(proof_keys):
        errors.append("offload-required GPU timing cells lack offload proof")
    if not proof_keys.issubset(timing_gpu_keys):
        errors.append("offload proof contains a cell outside the frozen GPU timing set")

    if profile_summary.get("run_id") != run_id or profile_summary.get("status") != "PASS":
        errors.append("profile summary has a different run_id or non-PASS status")
    if (profile_summary.get("source") != "instrumented_crossover_diagnostic" or
            profile_summary.get("performance_claims_permitted") is not False):
        errors.append("profile summary is not a separately labelled non-timing diagnostic")
    if profile_summary.get("dispatch_threshold_elements") != threshold:
        errors.append("profile summary threshold differs from crossover executor")
    summary_cells = profile_summary.get("cells")
    profile_keys: set[tuple[str, str]] = set()
    if not isinstance(summary_cells, list):
        errors.append("profile summary lacks a cells list")
        summary_cells = []
    for number, cell in enumerate(summary_cells, start=1):
        if not isinstance(cell, dict) or cell.get("backend") != "custom_gpu" or not isinstance(cell.get("circuit_id"), str):
            errors.append(f"profile summary cell {number} is invalid")
            continue
        key = (str(cell["circuit_id"]), "custom_gpu")
        profile_keys.add(key)
        path = resolve_profile_path(cell.get("profile_path", ""), run_dir, circuit_id=key[0])
        if path is None:
            errors.append(f"profile {key} cannot resolve a run-local raw profile")
            continue
        try:
            records = load_jsonl(path)
        except (OSError, ValueError, json.JSONDecodeError) as error:
            errors.append(f"profile summary cell {number} cannot load raw profile: {error}")
            continue
        record_errors = validate_records(records, threshold=threshold)
        errors.extend(f"profile {key}: {error}" for error in record_errors)
        if cell.get("profile_record_count") != len(records):
            errors.append(f"profile {key} record count differs from raw profile")
        if cell.get("algorithms") != summarize(records)["algorithms"]:
            errors.append(f"profile {key} algorithm summary differs from raw profile")
    if not required_profiles.issubset(profile_keys):
        errors.append("offload-required GPU timing cells lack phase-profile summaries")

    aggregate_cells = aggregate.get("cells")
    if not isinstance(aggregate_cells, list):
        errors.append("crossover aggregate lacks cells list")
    else:
        aggregate_keys = {(item.get("circuit_id"), item.get("backend")) for item in aggregate_cells if isinstance(item, dict)}
        if aggregate_keys != set(timing_cells):
            errors.append("crossover aggregate cells do not exactly cover raw timing cells")
        if len(aggregate_cells) != len(aggregate_keys):
            errors.append("crossover aggregate contains duplicate or invalid cells")
        for item in aggregate_cells:
            if not isinstance(item, dict):
                continue
            key = (item.get("circuit_id"), item.get("backend"))
            raw = timing_cells.get(key)  # type: ignore[arg-type]
            if raw is not None and item.get("simulation_config") != raw.get("simulation_config"):
                errors.append(f"crossover aggregate configuration differs from raw timing for {key}")
            if item.get("warmup_sample_count") != 5 or item.get("timed_sample_count") != 20:
                errors.append(f"crossover aggregate sample counts are invalid for {key}")
            try:
                selected_timings = [
                    float(record["elapsed_seconds"])
                    for record in timings
                    if (record.get("circuit_id"), record.get("backend")) == key
                ]
            except (KeyError, TypeError, ValueError):
                errors.append(f"raw timing values are invalid for {key}")
                continue
            selected_warmups = [
                record
                for record in warmups
                if (record.get("circuit_id"), record.get("backend")) == key
            ]
            if not selected_timings:
                continue
            expected_statistics = {
                "warmup_sample_count": len(selected_warmups),
                "timed_sample_count": len(selected_timings),
                "median_seconds": statistics.median(selected_timings),
                "mean_seconds": statistics.fmean(selected_timings),
                "sample_standard_deviation_seconds": statistics.stdev(selected_timings),
                "minimum_seconds": min(selected_timings),
                "maximum_seconds": max(selected_timings),
            }
            for field, expected_value in expected_statistics.items():
                if field.endswith("sample_count"):
                    matches = item.get(field) == expected_value
                else:
                    matches = same_number(item.get(field), float(expected_value))
                if not matches:
                    errors.append(
                        f"crossover aggregate {field} differs from raw timing for {key}"
                    )
    comparisons = aggregate.get("end_to_end_comparisons")
    if not isinstance(comparisons, list) or {item.get("circuit_id") for item in comparisons if isinstance(item, dict)} != set(circuits):
        errors.append("crossover aggregate lacks one end-to-end comparison per frozen circuit")
    else:
        comparison_by_id = {
            item.get("circuit_id"): item
            for item in comparisons
            if isinstance(item, dict)
        }
        if len(comparison_by_id) != len(comparisons):
            errors.append("crossover aggregate contains duplicate or invalid comparisons")
        recomputed_statuses: list[str] = []
        for offset, circuit_id in enumerate(sorted(circuits)):
            item = comparison_by_id.get(circuit_id)
            if not isinstance(item, dict):
                continue
            try:
                cpu = [
                    float(record["elapsed_seconds"])
                    for record in timings
                    if record.get("circuit_id") == circuit_id
                    and record.get("backend") == "custom_cpu"
                ]
                gpu = [
                    float(record["elapsed_seconds"])
                    for record in timings
                    if record.get("circuit_id") == circuit_id
                    and record.get("backend") == "custom_gpu"
                ]
            except (KeyError, TypeError, ValueError):
                errors.append(f"raw timing values are invalid for {circuit_id}")
                continue
            if not cpu or not gpu:
                continue
            expected = {
                "circuit_id": circuit_id,
                **comparison(cpu, gpu, seed=20260723 + offset),
            }
            if stable_json(item) != stable_json(expected):
                errors.append(
                    f"crossover comparison differs from raw timing for {circuit_id}"
                )
            recomputed_statuses.append(str(expected["advantage_status"]))
        expected_overall = (
            "CONFIRMED"
            if recomputed_statuses
            and all(status == "CONFIRMED" for status in recomputed_statuses)
            else "NOT_CONFIRMED"
        )
        if aggregate.get("overall_end_to_end_gpu_advantage_status") != expected_overall:
            errors.append("crossover overall decision differs from raw timing")
    if errors:
        return 1, ["FAIL crossover evidence validation", *(f"- {error}" for error in errors)]
    return 0, [f"PASS crossover evidence validation for {run_id}"]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    status, diagnostics = validate_run_directory(args.run_dir)
    print("\n".join(diagnostics))
    return status


if __name__ == "__main__":
    raise SystemExit(main())
