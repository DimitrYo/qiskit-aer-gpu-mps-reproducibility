#!/usr/bin/env python3
"""Hash-bound and relocation-safe path helpers for frozen evidence bundles."""

from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Any, Callable


def resolve_frozen_manifest(
    recorded_path: object,
    expected_sha256: object,
    *,
    manifests_dir: Path,
    load_manifest: Callable[[Path], dict[str, Any]],
) -> Path:
    """Resolve a manifest by validated content identity, not checkout location."""
    if not isinstance(recorded_path, str) or not recorded_path:
        raise RuntimeError("executor lacks a recorded manifest path")
    if not isinstance(expected_sha256, str) or len(expected_sha256) != 64:
        raise RuntimeError("executor lacks a valid manifest SHA-256")

    recorded_parts = PurePosixPath(recorded_path.replace("\\", "/")).parts
    if ".." in recorded_parts:
        raise RuntimeError("recorded manifest path contains traversal")
    recorded = Path(recorded_path)
    if recorded.is_file():
        manifest = load_manifest(recorded)
        if manifest.get("manifest_sha256") != expected_sha256:
            raise RuntimeError("recorded manifest hash differs from executor")
        return recorded.resolve()

    matches: list[Path] = []
    for candidate in sorted(manifests_dir.glob("*.json")):
        try:
            manifest = load_manifest(candidate)
        except (OSError, KeyError, TypeError, ValueError, RuntimeError):
            continue
        if manifest.get("manifest_sha256") == expected_sha256:
            matches.append(candidate.resolve())
    if len(matches) != 1:
        qualifier = "no" if not matches else "multiple"
        raise RuntimeError(
            "recorded manifest is unavailable and "
            f"{qualifier} unique local hash match exists"
        )
    return matches[0]


def resolve_run_local(
    recorded_path: object,
    run_dir: Path,
    expected_relative: Path,
    *,
    kind: str = "directory",
    require_run_name: bool = False,
) -> Path:
    """Bind a historical destination to one fixed path inside its moved run.

    The historical absolute prefix may change, but its registered suffix must
    still match the expected bundle layout.  Traversal components and any
    resolved path outside ``run_dir`` are rejected. With ``require_run_name``,
    absolute/historical prefixes must end in the current run name followed by
    the expected relative path; an exact run-relative spelling is also valid.
    ``kind="path"`` checks location even when an absent-event file is expected.
    """
    if not isinstance(recorded_path, str) or not recorded_path:
        raise RuntimeError("executor lacks a recorded run-artifact path")
    if expected_relative.is_absolute() or ".." in expected_relative.parts:
        raise RuntimeError("expected run-artifact layout is unsafe")

    normalized = recorded_path.replace("\\", "/")
    recorded_parts = PurePosixPath(normalized).parts
    expected_parts = PurePosixPath(expected_relative.as_posix()).parts
    if ".." in recorded_parts:
        raise RuntimeError("recorded run-artifact path contains traversal")
    if require_run_name and recorded_parts != expected_parts:
        run_suffix = (run_dir.name, *expected_parts)
        if tuple(recorded_parts[-len(run_suffix):]) != run_suffix:
            raise RuntimeError("recorded run-artifact path has a different run or cell")
    if len(recorded_parts) < len(expected_parts) or tuple(
        recorded_parts[-len(expected_parts) :]
    ) != tuple(expected_parts):
        raise RuntimeError(
            "recorded run-artifact path does not match the frozen layout: "
            f"expected suffix {expected_relative.as_posix()}"
        )

    root = run_dir.resolve(strict=True)
    candidate = (root / expected_relative).resolve(strict=kind != "path")
    try:
        candidate.relative_to(root)
    except ValueError as error:
        raise RuntimeError("resolved run-artifact path escapes the run") from error
    if kind == "directory" and not candidate.is_dir():
        raise RuntimeError(f"run-local artifact is not a directory: {expected_relative}")
    if kind == "file" and not candidate.is_file():
        raise RuntimeError(f"run-local artifact is not a file: {expected_relative}")
    if kind not in {"directory", "file", "path"}:
        raise RuntimeError(f"unsupported run-artifact kind: {kind}")
    return candidate
