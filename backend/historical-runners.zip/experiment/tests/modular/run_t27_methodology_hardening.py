#!/usr/bin/env python3
"""Run the frozen T27 thread-controlled and order-balanced campaign."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from run_e2_numerical_correctness_pilot import load_manifest
from run_e3_timing_executor import (
    CELL_DRIVER,
    DEFAULT_RUNS_ROOT,
    environment_python,
)


THREAD_VARIABLES = (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "BLIS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
)
PRIMARY_THREADS = 6
THREAD_SENSITIVITY_ORDER = (6, 1, 12, 2, 4)
PRIMARY_ORDERS = (
    ("custom_cpu", "custom_gpu"),
    ("custom_gpu", "custom_cpu"),
    ("custom_gpu", "custom_cpu"),
    ("custom_cpu", "custom_gpu"),
)


def controlled_environment(threads: int) -> dict[str, str]:
    environment = os.environ.copy()
    for name in THREAD_VARIABLES:
        environment[name] = str(threads)
    environment.update(
        {
            "OMP_DYNAMIC": "FALSE",
            "OMP_PROC_BIND": "close",
            "OMP_PLACES": "cores",
        }
    )
    for name in (
        "AER_CUTENSOR_SVD_EVENTS_PATH",
        "AER_CUTENSOR_SVD_PROFILE_PATH",
        "AER_CUTENSOR_SVD_DECISIONS_PATH",
    ):
        environment.pop(name, None)
    return environment


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path} must contain a JSON object")
    return value


def run_cell(
    *,
    python_bin: Path,
    manifest: Path,
    run_id: str,
    destination: Path,
    backend: str,
    threads: int,
    warmups: int,
    timed_repetitions: int,
    diagnostic: bool = False,
) -> dict[str, Any]:
    destination.mkdir(parents=True, exist_ok=True)
    command = [
        str(python_bin),
        str(CELL_DRIVER),
        "--manifest",
        str(manifest.resolve()),
        "--backend",
        backend,
        "--run-id",
        run_id,
        "--warmups-output",
        str(destination / f"{backend}.warmups.jsonl"),
        "--timings-output",
        str(destination / f"{backend}.timings.jsonl"),
        "--report-output",
        str(destination / f"{backend}.report.json"),
        "--warmups",
        str(warmups),
        "--timed-repetitions",
        str(timed_repetitions),
        "--shots",
        "100",
        "--max-bond-dimension",
        "1024",
        "--truncation-threshold",
        "0",
        "--seed-simulator",
        "20260725",
        "--seed-transpiler",
        "20260725",
        "--cell-wall-time-seconds",
        "3600",
    ]
    if backend == "custom_gpu":
        command.extend(["--dispatch-threshold", "8401"])
        if diagnostic:
            command.extend(
                [
                    "--events-dir",
                    str(destination / "events"),
                    "--profile-dir",
                    str(destination / "profiles"),
                    "--decisions-dir",
                    str(destination / "decisions"),
                ]
            )
        else:
            command.append("--allow-uninstrumented-gpu-timing")
    print(
        f"[T27] {destination.name}: {backend}, threads={threads}, "
        f"{warmups}/{timed_repetitions}",
        flush=True,
    )
    result = subprocess.run(
        command,
        env=controlled_environment(threads),
        text=True,
    )
    if result.returncode:
        raise RuntimeError(f"T27 cell failed: {destination} {backend}")
    return read_json(destination / f"{backend}.report.json")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--sensitivity-manifest", type=Path, required=True)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument(
        "--custom-environment",
        default=".venv_custom_gpu_isolated_20260722",
    )
    args = parser.parse_args()
    run_dir = (args.runs_root / args.run_id).resolve()
    try:
        if run_dir.exists():
            raise RuntimeError(f"refusing to reuse immutable run ID: {run_dir}")
        manifest = load_manifest(args.manifest)
        sensitivity_manifest = load_manifest(args.sensitivity_manifest)
        if len(manifest["circuits"]) != 4 or len(sensitivity_manifest["circuits"]) != 1:
            raise RuntimeError("T27 requires four primary and one sensitivity workload")
        python_bin = environment_python(args.custom_environment)
        run_dir.mkdir(parents=True)

        sensitivity_records: list[dict[str, Any]] = []
        for threads in THREAD_SENSITIVITY_ORDER:
            destination = run_dir / "thread_sensitivity" / f"threads_{threads:02d}"
            report = run_cell(
                python_bin=python_bin,
                manifest=args.sensitivity_manifest,
                run_id=args.run_id,
                destination=destination,
                backend="custom_cpu",
                threads=threads,
                warmups=5,
                timed_repetitions=20,
            )
            sensitivity_records.append(
                {
                    "threads": threads,
                    "destination": str(destination),
                    "aer_path": report["aer_path"],
                }
            )

        repetition_records: list[dict[str, Any]] = []
        for index, order in enumerate(PRIMARY_ORDERS, start=1):
            destination = run_dir / "primary" / f"repetition_{index:02d}"
            reports: list[dict[str, Any]] = []
            for backend in order:
                reports.append(
                    run_cell(
                        python_bin=python_bin,
                        manifest=args.manifest,
                        run_id=args.run_id,
                        destination=destination,
                        backend=backend,
                        threads=PRIMARY_THREADS,
                        warmups=5,
                        timed_repetitions=20,
                    )
                )
            repetition_records.append(
                {
                    "repetition": index,
                    "backend_order": list(order),
                    "destination": str(destination),
                    "aer_paths": {
                        str(report["backend"]): str(report["aer_path"])
                        for report in reports
                    },
                }
            )

        diagnostic_destination = run_dir / "diagnostic"
        diagnostic_report = run_cell(
            python_bin=python_bin,
            manifest=args.manifest,
            run_id=args.run_id,
            destination=diagnostic_destination,
            backend="custom_gpu",
            threads=PRIMARY_THREADS,
            warmups=1,
            timed_repetitions=1,
            diagnostic=True,
        )
        executor = {
            "schema_version": 1,
            "task": "T27",
            "run_id": args.run_id,
            "status": "PASS",
            "manifest_path": str(args.manifest.resolve()),
            "manifest_sha256": manifest["manifest_sha256"],
            "sensitivity_manifest_path": str(args.sensitivity_manifest.resolve()),
            "sensitivity_manifest_sha256": sensitivity_manifest["manifest_sha256"],
            "protocol": {
                "warmups": 5,
                "timed_repetitions": 20,
                "shots": 100,
                "max_bond_dimension": 1024,
                "truncation_threshold": 0.0,
                "dispatch_threshold_elements": 8401,
                "primary_threads": PRIMARY_THREADS,
                "thread_variables": list(THREAD_VARIABLES),
                "thread_sensitivity_order": list(THREAD_SENSITIVITY_ORDER),
                "primary_orders": [list(order) for order in PRIMARY_ORDERS],
                "timing_instrumentation": "none",
            },
            "thread_sensitivity": sensitivity_records,
            "primary_repetitions": repetition_records,
            "diagnostic": {
                "destination": str(diagnostic_destination),
                "instrumentation_mode": diagnostic_report["instrumentation_mode"],
                "performance_claims_permitted": False,
            },
        }
        (run_dir / "t27_executor.json").write_text(
            json.dumps(executor, indent=2) + "\n",
            encoding="utf-8",
        )
        print(f"PASS: T27 raw evidence written to {run_dir}")
        return 0
    except (OSError, KeyError, TypeError, ValueError, RuntimeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

