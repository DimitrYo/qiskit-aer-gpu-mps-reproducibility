#!/usr/bin/env python3
"""Validate one run-scoped Article 2 E2 numerical-correctness pilot bundle."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path, PurePosixPath

from evidence_paths import resolve_run_local


REPORTS = {
    "custom_gpu": "e2_custom_gpu.json",
    "custom_cpu": "e2_custom_cpu.json",
    "upstream_cpu": "e2_upstream_cpu.json",
}
EVALUATED_SOURCE_COMMIT = "75137ba7dee76ec864cb723a6c3aa9650fbf4f43"
EVALUATED_SOURCE_TREE = "73ec36070db917a58c65440516cd7dfd26b88576"
EVALUATED_CMAKE_CACHE_SHA256 = (
    "b76980f034d184febd1a3449aa75b278b935277c1f985bcc07edb105d170b31a"
)
STRICT_EVALUATED_RUN_PREFIXES = (
    "20260723_l5_exact_",
    "20260724_t17_",
    "20260724_t21_",
    "20260724_t26_",
)
HEX40 = re.compile(r"[0-9a-f]{40}")
HEX64 = re.compile(r"[0-9a-f]{64}")


def resolve_run_local_file(recorded_path: str, run_dir: Path, *, expected_name: str) -> Path | None:
    """Resolve a recorded evidence path without making a clone location part of proof.

    Producers record absolute paths for local forensic provenance.  Those paths
    may remain available when the immutable run bundle is checked out elsewhere.
    They are provenance, never a reason to read another checkout. The recorded
    run/name suffix is checked with either path separator, and only the fixed
    event file inside the current run is consumed.
    """
    try:
        return resolve_run_local(recorded_path, run_dir, Path(expected_name),
                                 kind="file", require_run_name=True)
    except (OSError, ValueError, RuntimeError):
        return None

def provenance_parts(value: object) -> tuple[str, ...] | None:
    if not isinstance(value, (str, Path)) or not str(value):
        return None
    parts = PurePosixPath(str(value).replace("\\", "/")).parts
    if ".." in parts:
        return None
    return tuple(parts)


def recorded_import_matches_build(aer_path: object, source_path: object) -> bool:
    """Match two recorded paths lexically without requiring either to exist."""
    source = provenance_parts(source_path)
    imported = provenance_parts(aer_path)
    return (
        source is not None
        and imported is not None
        and imported == (*source, "qiskit_aer", "__init__.py")
    )


def recorded_path_is_within_source(path: object, source_path: object) -> bool:
    source = provenance_parts(source_path)
    candidate = provenance_parts(path)
    return (
        source is not None
        and candidate is not None
        and len(candidate) > len(source)
        and candidate[: len(source)] == source
    )


def imports_selected_custom_build(aer_path: Path) -> bool:
    """Accept the selected custom source, including an isolated worktree.

    E2 producers and this validator must apply the same provenance rule.  The
    environment variable is intentionally inherited by an immutable campaign
    runner; it records which already-built custom environment was selected and
    never changes an environment.
    """
    selected = os.environ.get("ARTICLE2_CUSTOM_SOURCE_DIR")
    if selected:
        return recorded_import_matches_build(aer_path, selected)
    # Retain compatibility with historical fixture bundles, which identify the
    # default custom checkout by its stable worktree name.  Production isolated
    # runs always set ARTICLE2_CUSTOM_SOURCE_DIR and take the strict branch.
    return "qiskit-aer-pr2168" in str(aer_path)


def validate_build_manifest(
    build: dict[str, object], run_id: str
) -> tuple[list[str], str | None]:
    """Validate portable source/build identity recorded at collection time."""
    errors: list[str] = []
    if build.get("run_id") != run_id:
        errors.append("build manifest run_id mismatch")
    source = build.get("source")
    if not isinstance(source, dict):
        return [*errors, "build manifest lacks source metadata"], None
    source_path = source.get("path")
    if provenance_parts(source_path) is None:
        errors.append("build manifest has an invalid source path")
        source_path_value = None
    else:
        source_path_value = str(source_path)
    commit = source.get("commit")
    tree = source.get("tree")
    dirty = source.get("dirty")
    cache_hash = build.get("cmake_cache_sha256")
    if not isinstance(commit, str) or HEX40.fullmatch(commit) is None:
        errors.append("build manifest lacks a valid source commit")
    if tree is not None and (
        not isinstance(tree, str) or HEX40.fullmatch(tree) is None
    ):
        errors.append("build manifest has an invalid source tree")
    if not isinstance(dirty, bool):
        errors.append("build manifest lacks a boolean dirty flag")
    if not isinstance(cache_hash, str) or HEX64.fullmatch(cache_hash) is None:
        errors.append("build manifest lacks a valid CMake-cache SHA-256")
    if not isinstance(build.get("custom_environment"), str):
        errors.append("build manifest lacks the selected custom environment")
    if not isinstance(build.get("cmake_cuda_compiler"), str):
        errors.append("build manifest lacks the configured CUDA compiler")
    if (
        build.get("cmake_cuda_enabled") is not True
        or build.get("cutensornet_enabled") is not True
        or build.get("cutensornet_linked_by_controller") is not True
    ):
        errors.append("build manifest lacks the required CUDA/cuTensorNet configuration")

    strict = run_id.startswith(STRICT_EVALUATED_RUN_PREFIXES)
    if strict:
        if commit != EVALUATED_SOURCE_COMMIT:
            errors.append("build manifest source commit differs from the evaluated source")
        if tree is not None and tree != EVALUATED_SOURCE_TREE:
            errors.append("build manifest source tree differs from the evaluated source")
        if cache_hash != EVALUATED_CMAKE_CACHE_SHA256:
            errors.append("build manifest CMake configuration differs from the evaluated build")
        if dirty is not False:
            errors.append("evaluated custom source was not clean")
    return errors, source_path_value


def load_json(path: Path, errors: list[str]) -> dict[str, object] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        errors.append(f"cannot read {path.name}: {error}")
        return None
    if not isinstance(value, dict):
        errors.append(f"{path.name}: root must be an object")
        return None
    return value


def validate_report(
    report: dict[str, object],
    backend: str,
    run_id: str,
    run_dir: Path,
    custom_source_path: str | None,
) -> tuple[list[str], set[str], str | None]:
    errors: list[str] = []
    if report.get("run_id") != run_id:
        errors.append(f"{backend}: run_id mismatch")
    if report.get("backend") != backend or report.get("status") != "PASS":
        errors.append(f"{backend}: backend or status is not PASS")
    if report.get("performance_claims_permitted") is not False:
        errors.append(f"{backend}: E2 report must prohibit performance claims")
    driver_hash = report.get("driver_sha256")
    if not isinstance(driver_hash, str) or len(driver_hash) != 64:
        errors.append(f"{backend}: missing driver_sha256")
        driver_hash = None
    aer_path = report.get("aer_path")
    exact_custom_import = recorded_import_matches_build(
        aer_path, custom_source_path
    )
    within_custom_source = recorded_path_is_within_source(
        aer_path, custom_source_path
    )
    if backend.startswith("custom_") and not exact_custom_import:
        errors.append(f"{backend}: does not import the custom PR build")
    if backend == "upstream_cpu" and within_custom_source:
        errors.append("upstream_cpu imports the custom PR build")
    config = report.get("simulation_config")
    if not isinstance(config, dict) or config.get("method") != "matrix_product_state":
        errors.append(f"{backend}: missing MPS simulation configuration")
    elif config.get("device") != ("GPU" if backend == "custom_gpu" else "CPU"):
        errors.append(f"{backend}: unexpected configured device")
    records = report.get("records")
    circuit_ids: set[str] = set()
    if not isinstance(records, list) or not records:
        errors.append(f"{backend}: no correctness records")
    else:
        for record in records:
            if not isinstance(record, dict):
                errors.append(f"{backend}: invalid correctness record")
                continue
            circuit_id = record.get("circuit_id")
            if not isinstance(circuit_id, str):
                errors.append(f"{backend}: record lacks circuit_id")
            else:
                circuit_ids.add(circuit_id)
            reference = record.get("reference", {})
            mps = record.get("mps", {})
            if record.get("status") != "PASS" or not isinstance(reference, dict) or not isinstance(mps, dict):
                errors.append(f"{backend}:{circuit_id}: record is not a passing reference/MPS comparison")
                continue
            if float(reference.get("fidelity", -1.0)) < float(reference.get("fidelity_min", 1.0)):
                errors.append(f"{backend}:{circuit_id}: exact references disagree")
            if float(mps.get("fidelity", -1.0)) < float(mps.get("fidelity_min", 1.0)):
                errors.append(f"{backend}:{circuit_id}: MPS fidelity gate failed")
            if float(mps.get("norm_error", float("inf"))) > float(mps.get("norm_error_max", 0.0)):
                errors.append(f"{backend}:{circuit_id}: MPS norm gate failed")
    if backend == "custom_gpu":
        proof = report.get("offload_proof")
        if not isinstance(proof, dict):
            errors.append("custom_gpu: missing cuTensorNet offload proof")
        else:
            path = resolve_run_local_file(str(proof.get("events_path", "")), run_dir,
                                          expected_name="e2_custom_gpu.events.jsonl")
            if path is None:
                errors.append("custom_gpu: event log is missing or outside the run directory")
            else:
                lines = path.read_bytes().splitlines()
                if len(lines) < 1 or proof.get("event_count") != len(lines):
                    errors.append("custom_gpu: event count does not match event log")
                if proof.get("event_sha256") != hashlib.sha256(path.read_bytes()).hexdigest():
                    errors.append("custom_gpu: event log hash mismatch")
    return errors, circuit_ids, driver_hash


def validate(run_dir: Path) -> list[str]:
    run_dir = run_dir.resolve()
    errors: list[str] = []
    build = load_json(run_dir / "build_manifest.json", errors)
    environment = load_json(run_dir / "environment_manifest.json", errors)
    custom_source_path: str | None = None
    if build is not None:
        build_errors, custom_source_path = validate_build_manifest(build, run_dir.name)
        errors.extend(build_errors)
    if environment is not None:
        if environment.get("run_id") != run_dir.name:
            errors.append("environment manifest run_id mismatch")
        aer = environment.get("aer")
        if not isinstance(aer, dict) or not recorded_import_matches_build(
            aer.get("source_path"), custom_source_path
        ):
            errors.append(
                "environment Aer import does not match the recorded custom build"
            )
    reports = {backend: load_json(run_dir / name, errors) for backend, name in REPORTS.items()}
    circuit_sets: dict[str, set[str]] = {}
    driver_hashes: set[str] = set()
    configs: dict[str, dict[str, object]] = {}
    for backend, report in reports.items():
        if report is None:
            continue
        report_errors, circuit_ids, driver_hash = validate_report(
            report,
            backend,
            run_dir.name,
            run_dir,
            custom_source_path,
        )
        errors.extend(report_errors)
        circuit_sets[backend] = circuit_ids
        if driver_hash:
            driver_hashes.add(driver_hash)
        config = report.get("simulation_config")
        if isinstance(config, dict):
            configs[backend] = config
    if len(circuit_sets) == len(REPORTS) and len(set(map(frozenset, circuit_sets.values()))) != 1:
        errors.append("backends do not cover the same frozen exact-reference circuits")
    if len(driver_hashes) != 1:
        errors.append("reports were not produced by the same E2 driver revision")
    comparable = ("shots", "max_bond_dimension", "truncation_threshold", "seed_transpiler")
    if len(configs) == len(REPORTS):
        for key in comparable:
            if len({config.get(key) for config in configs.values()}) != 1:
                errors.append(f"simulation configuration mismatch for {key}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    errors = validate(args.run_dir)
    if errors:
        print("BLOCKED: " + "; ".join(errors))
        return 1
    print(f"PASS: E2 correctness bundle {args.run_dir.name} is internally consistent.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
