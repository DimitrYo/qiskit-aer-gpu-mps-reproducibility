#!/usr/bin/env python3
"""Execute one complete immutable L5 crossover evidence bundle.

The command serializes raw crossover timing, provenance, exact-reference E2
controls, assembly, and validation. It never reuses a run directory, so a
failure remains inspectable rather than being repaired in place.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from run_e3_timing_executor import DEFAULT_RUNS_ROOT, EXPERIMENTS_DIR, environment_python


HERE = Path(__file__).resolve().parent
CROSSOVER_EXECUTOR = HERE / "run_crossover_timing_executor.py"
CROSSOVER_DIAGNOSTIC = HERE / "run_crossover_gpu_diagnostic.py"
COLLECT_ENVIRONMENT = HERE / "collect_environment_manifest.py"
COLLECT_BUILD = HERE / "collect_build_manifest.py"
E2 = HERE / "run_e2_numerical_correctness_pilot.py"
VALIDATE_E2 = HERE / "validate_e2_correctness.py"
ASSEMBLE = HERE / "assemble_crossover_evidence.py"
VALIDATE = HERE / "validate_crossover_evidence.py"


def invoke(command: list[str], label: str) -> None:
    print(f"[L5] {label}", flush=True)
    if subprocess.run(command, text=True).returncode:
        raise RuntimeError(f"{label} failed")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--cmake-cache", type=Path, required=True)
    parser.add_argument("--max-bond-dimension", type=int, required=True)
    parser.add_argument("--dispatch-threshold", type=int, required=True)
    parser.add_argument("--cell-wall-time-seconds", type=float, default=1800.0)
    parser.add_argument("--seed-simulator", type=int, default=20260722)
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument("--custom-environment", default=".venv_custom_gpu_pr2168_20260721")
    parser.add_argument("--upstream-environment", default=".venv_cpu")
    parser.add_argument("--source-dir", type=Path, default=EXPERIMENTS_DIR.parent / "qiskit-aer-pr2168")
    args = parser.parse_args()
    run_dir = args.runs_root / args.run_id
    try:
        if run_dir.exists():
            raise RuntimeError(f"refusing to reuse existing run directory: {run_dir}")
        custom_python = environment_python(args.custom_environment)
        upstream_python = environment_python(args.upstream_environment)
        # Collectors inherit this explicit selected environment name; it is
        # evidence metadata, not a request to create or modify any venv.
        os.environ["ARTICLE2_CUSTOM_ENV_NAME"] = args.custom_environment
        invoke([str(custom_python), str(CROSSOVER_EXECUTOR), "--run-id", args.run_id,
                "--manifest", str(args.manifest.resolve()), "--runs-root", str(args.runs_root.resolve()),
                "--custom-environment", args.custom_environment,
                "--max-bond-dimension", str(args.max_bond_dimension),
                "--dispatch-threshold", str(args.dispatch_threshold),
                "--cell-wall-time-seconds", str(args.cell_wall_time_seconds),
                "--seed-simulator", str(args.seed_simulator),
                "--seed-transpiler", str(args.seed_transpiler)], "raw uninstrumented timing")
        invoke([str(custom_python), str(CROSSOVER_DIAGNOSTIC), "--run-id", args.run_id,
                "--manifest", str(args.manifest.resolve()), "--runs-root", str(args.runs_root.resolve()),
                "--custom-environment", args.custom_environment,
                "--max-bond-dimension", str(args.max_bond_dimension),
                "--dispatch-threshold", str(args.dispatch_threshold),
                "--seed-simulator", str(args.seed_simulator),
                "--seed-transpiler", str(args.seed_transpiler)], "GPU offload/profile diagnostic")
        invoke([str(custom_python), str(COLLECT_ENVIRONMENT), "--run-id", args.run_id,
                "--backend", "custom_gpu", "--output", str(run_dir / "environment_manifest.json")], "environment provenance")
        invoke([str(custom_python), str(COLLECT_BUILD), "--run-id", args.run_id,
                "--cmake-cache", str(args.cmake_cache.resolve()), "--source-dir", str(args.source_dir.resolve()),
                "--output", str(run_dir / "build_manifest.json")], "build provenance")
        for backend, python_bin, output in (
            ("custom_cpu", custom_python, "e2_custom_cpu.json"),
            ("custom_gpu", custom_python, "e2_custom_gpu.json"),
            ("upstream_cpu", upstream_python, "e2_upstream_cpu.json"),
        ):
            command = [str(python_bin), str(E2), "--manifest", str(args.manifest.resolve()),
                       "--backend", backend, "--run-id", args.run_id, "--output", str(run_dir / output),
                       "--max-bond-dimension", str(args.max_bond_dimension),
                       "--dispatch-threshold", str(args.dispatch_threshold)]
            if backend == "custom_gpu":
                command += ["--events-path", str(run_dir / "e2_custom_gpu.events.jsonl")]
            invoke(command, f"E2 {backend}")
        invoke([str(custom_python), str(VALIDATE_E2), "--run-dir", str(run_dir)], "same-run E2 validation")
        invoke([str(custom_python), str(ASSEMBLE), "--run-dir", str(run_dir)], "crossover assembly")
        invoke([str(custom_python), str(VALIDATE), "--run-dir", str(run_dir)], "crossover validation")
        print(f"PASS: complete L5 crossover bundle {args.run_id}")
        return 0
    except (OSError, RuntimeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
