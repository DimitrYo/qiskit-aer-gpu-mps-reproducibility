#!/usr/bin/env python3
"""Run the isolated T32 Aer discarded-weight boundary regression."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import qiskit_aer
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.backends import controller_wrappers


THRESHOLD = 1.0e-4
CASES = (
    ("tail_below_cutoff", THRESHOLD / 2, 1),
    ("tail_equal_cutoff", THRESHOLD, 2),
    ("tail_above_cutoff", THRESHOLD * 2, 2),
)
EXPECTED_SOURCE_COMMIT = "f7631b1c9be2ffa24474d0d6e40225f8627ee78d"
EXPECTED_PARENT_COMMIT = "75137ba7dee76ec864cb723a6c3aa9650fbf4f43"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path} must contain a JSON object")
    return value


def git(source: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(source), *args],
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def package_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def run_case(label: str, tail_weight: float, expected_rank: int) -> dict[str, Any]:
    backend = AerSimulator(
        method="matrix_product_state",
        device="CPU",
        matrix_product_state_truncation_threshold=THRESHOLD,
    )
    circuit = QuantumCircuit(2)
    circuit.ry(2 * math.asin(math.sqrt(tail_weight)), 0)
    circuit.cx(0, 1)
    circuit.save_matrix_product_state(label="mps")
    circuit.save_statevector(label="statevector")
    result = backend.run(transpile(circuit, backend, optimization_level=0)).result()
    if not result.success:
        raise RuntimeError(f"T32 Aer execution failed for {label}")

    data = result.data(0)
    lambdas = data["mps"][1]
    retained_rank = len(lambdas[0])
    statevector = np.asarray(data["statevector"], dtype=complex)
    exact = np.zeros(4, dtype=complex)
    exact[0] = math.sqrt(1.0 - tail_weight)
    exact[3] = math.sqrt(tail_weight)
    fidelity = float(abs(np.vdot(exact, statevector)) ** 2)
    norm_error = float(abs(np.linalg.norm(statevector) - 1.0))
    if retained_rank != expected_rank:
        raise RuntimeError(
            f"{label}: expected retained rank {expected_rank}, got {retained_rank}"
        )
    minimum_fidelity = 1.0 - tail_weight - 1.0e-12
    if fidelity < minimum_fidelity or norm_error > 1.0e-12:
        raise RuntimeError(
            f"{label}: fidelity/norm gate failed ({fidelity}, {norm_error})"
        )
    return {
        "case": label,
        "tail_weight": tail_weight,
        "cutoff": THRESHOLD,
        "expected_rank": expected_rank,
        "retained_rank": retained_rank,
        "schmidt_values_after_reduction": [
            float(value) for value in lambdas[0]
        ],
        "state_fidelity": fidelity,
        "norm_error": norm_error,
        "status": "PASS",
    }


def normalized_t29_semantics(executor: dict[str, Any]) -> list[dict[str, Any]]:
    by_case = {
        str(item["case"]): item
        for item in executor.get("semantic_results", [])
        if isinstance(item, dict)
    }
    mapping = (
        ("tail_below_cutoff", "above"),
        ("tail_equal_cutoff", "equal"),
        ("tail_above_cutoff", "below"),
    )
    normalized: list[dict[str, Any]] = []
    for label, t29_label in mapping:
        item = by_case.get(t29_label)
        if item is None:
            raise RuntimeError(f"T29 semantic reference lacks case {t29_label}")
        normalized.append(
            {
                "case": label,
                "t29_case": t29_label,
                "pre_fix_aer_rank": int(item["aer_side"]["retained_rank"]),
                "native_cutensornet_rank": int(item["native"]["retained_rank"]),
            }
        )
    return normalized


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--runs-root", type=Path, required=True)
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--baseline-run-dir", type=Path, required=True)
    parser.add_argument("--source-patch", type=Path, required=True)
    args = parser.parse_args()

    run_dir = (args.runs_root / args.run_id).resolve()
    if run_dir.exists():
        raise RuntimeError(f"refusing to reuse immutable run ID: {args.run_id}")
    source = args.source_dir.resolve()
    baseline_run = args.baseline_run_dir.resolve()
    source_patch = args.source_patch.resolve()
    svd = source / "src/simulators/matrix_product_state/svd.cpp"
    source_test = (
        source
        / "test/terra/backends/aer_simulator/test_save_matrix_product_state.py"
    )
    for path in (svd, source_test, source_patch):
        if not path.is_file():
            raise RuntimeError(f"missing T32 input: {path}")

    commit = git(source, "rev-parse", "HEAD")
    parent = git(source, "rev-parse", "HEAD^")
    status = git(source, "status", "--porcelain")
    if (commit, parent, status) != (
        EXPECTED_SOURCE_COMMIT,
        EXPECTED_PARENT_COMMIT,
        "",
    ):
        raise RuntimeError("T32 source revision, parent, or cleanliness mismatch")

    aer_path = Path(qiskit_aer.__file__).resolve()
    binding_path = Path(controller_wrappers.__file__).resolve()
    if source not in aer_path.parents or source not in binding_path.parents:
        raise RuntimeError("active T32 interpreter does not import the T32 source")

    svd_text = svd.read_text(encoding="utf-8")
    strict_index = svd_text.find(
        "sum_squares + std::norm(S[new_SV_num - 1]) <"
    )
    decrement_index = svd_text.find("new_SV_num--;", strict_index)
    discarded_index = svd_text.find("double discarded_value = 0.0;", strict_index)
    resize_index = svd_text.find("S.resize(new_SV_num);", strict_index)
    if not (
        0 <= strict_index < decrement_index < discarded_index < resize_index
        and "while (new_SV_num > 1 &&" in svd_text
    ):
        raise RuntimeError("T32 source does not encode the registered strict contract")

    unit_test = subprocess.run(
        [
            sys.executable,
            "-m",
            "unittest",
            "-v",
            (
                "test.terra.backends.aer_simulator.test_save_matrix_product_state."
                "TestSaveMatrixProductStateTests."
                "test_mps_discarded_weight_boundaries"
            ),
        ],
        cwd=source,
        capture_output=True,
        text=True,
    )
    if unit_test.returncode:
        raise RuntimeError(unit_test.stdout + unit_test.stderr)

    patched_results = [
        run_case(label, tail_weight, expected_rank)
        for label, tail_weight, expected_rank in CASES
    ]
    baseline_executor_path = baseline_run / "t29_executor.json"
    baseline_executor = read_json(baseline_executor_path)
    if (
        baseline_executor.get("task"),
        baseline_executor.get("run_id"),
        baseline_executor.get("status"),
    ) != ("T29", baseline_run.name, "PASS"):
        raise RuntimeError("T29 baseline identity/status mismatch")
    comparison = normalized_t29_semantics(baseline_executor)
    patched_by_case = {
        str(item["case"]): int(item["retained_rank"])
        for item in patched_results
    }
    for item in comparison:
        item["patched_aer_rank"] = patched_by_case[str(item["case"])]
        item["patched_matches_native"] = (
            item["patched_aer_rank"] == item["native_cutensornet_rank"]
        )

    record = {
        "schema_version": 1,
        "task": "T32",
        "run_id": args.run_id,
        "status": "PASS",
        "classification": "isolated_semantic_regression_not_performance_evidence",
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "semantic_contract": {
            "quantity": "cumulative squared Schmidt-coefficient weight",
            "comparison": "strictly_less_than",
            "equality_action": "retain",
            "minimum_retained_rank": 1,
            "terminal_tail_action": "apply_accumulated_reduction",
            "documentation_url": (
                "https://qiskit.github.io/qiskit-aer/stubs/"
                "qiskit_aer.AerSimulator.html"
            ),
        },
        "source": {
            "path": str(source),
            "git_commit": commit,
            "git_parent_commit": parent,
            "git_branch": git(source, "branch", "--show-current"),
            "git_status_porcelain": status,
            "svd_cpp": {"path": str(svd), "sha256": sha256(svd)},
            "source_test": {
                "path": str(source_test),
                "sha256": sha256(source_test),
            },
            "source_patch": {
                "path": str(source_patch),
                "sha256": sha256(source_patch),
            },
            "introduction_commit": git(
                source,
                "log",
                "-S",
                "sum_squares + std::norm",
                "-1",
                "--format=%H",
                "--",
                "src/simulators/matrix_product_state/svd.cpp",
            ),
        },
        "environment": {
            "python": sys.executable,
            "qiskit_aer_path": str(aer_path),
            "controller_binding_path": str(binding_path),
            "available_devices": list(AerSimulator().available_devices()),
            "versions": {
                name: package_version(name)
                for name in (
                    "qiskit",
                    "qiskit-aer-gpu",
                    "numpy",
                    "cuquantum-cu12",
                )
            },
        },
        "unit_regression": {
            "command": unit_test.args,
            "returncode": unit_test.returncode,
            "stdout": unit_test.stdout,
            "stderr": unit_test.stderr,
        },
        "patched_aer_results": patched_results,
        "immutable_t29_reference": {
            "run_id": baseline_run.name,
            "executor_sha256": sha256(baseline_executor_path),
            "normalized_comparison": comparison,
        },
        "decision": {
            "terminal_tail_defect_confirmed": True,
            "terminal_tail_defect_fixed": True,
            "strict_equality_is_documented_contract": True,
            "remaining_native_difference": "equality_only",
            "native_timing_unblocked": False,
            "t29_rewritten": False,
        },
        "correctness_claim_permitted": True,
        "performance_claim_permitted": False,
    }
    run_dir.mkdir(parents=True)
    output = run_dir / "t32_semantic_regression.json"
    output.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
