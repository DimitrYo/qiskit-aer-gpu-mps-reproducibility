#!/usr/bin/env python3
"""Capture non-timing offload and phase diagnostics for one L5 run.

This runner is intentionally separate from the immutable 5/20 timing cells.
It performs one warm-up and one diagnostic execution per circuit with the
opt-in cuTensorNet recorders enabled, then produces the offload/profile files
consumed by the L5 validator.  Its elapsed values are retained for audit only
and must never be used as timing samples or a speed-up estimate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from crossover_profile import load_jsonl, summarize, validate_records
from run_e2_numerical_correctness_pilot import load_manifest
from run_e3_timing_executor import CELL_DRIVER, DEFAULT_RUNS_ROOT, environment_python


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def profile_summary(report: dict[str, Any], *, threshold: int) -> dict[str, Any]:
    cells: list[dict[str, Any]] = []
    for cell in report.get("profile_cells", []):
        if not isinstance(cell, dict):
            raise RuntimeError("custom-GPU diagnostic report contains an invalid profile cell")
        path = Path(str(cell.get("profile_path", "")))
        records = load_jsonl(path)
        errors = validate_records(records, threshold=threshold)
        if errors:
            raise RuntimeError(f"invalid diagnostic profile {path}: {'; '.join(errors)}")
        if cell.get("profile_records") != len(records) or cell.get("profile_sha256") != sha256_file(path):
            raise RuntimeError(f"diagnostic profile count or hash mismatch: {path}")
        cells.append({
            "circuit_id": cell.get("circuit_id"), "backend": "custom_gpu",
            "profile_path": str(path), "profile_sha256": sha256_file(path),
            **summarize(records),
        })
    return {"schema_version": 1, "status": "PASS", "cells": cells}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument("--custom-environment", default=".venv_custom_gpu_pr2168_20260721")
    parser.add_argument("--max-bond-dimension", type=int, required=True)
    parser.add_argument("--truncation-threshold", type=float, default=0.0)
    parser.add_argument("--dispatch-threshold", type=int, required=True)
    parser.add_argument("--cell-wall-time-seconds", type=float, default=600.0)
    parser.add_argument("--shots", type=int, default=100)
    parser.add_argument("--seed-simulator", type=int, default=20260722)
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    args = parser.parse_args()
    run_dir = args.runs_root / args.run_id
    try:
        if not run_dir.is_dir():
            raise RuntimeError(f"crossover timing run directory does not exist: {run_dir}")
        outputs = (run_dir / "crossover_diagnostic.json", run_dir / "offload_proof.json",
                   run_dir / "profile_summary.json")
        existing = [path.name for path in outputs if path.exists()]
        if existing:
            raise RuntimeError(f"refusing to overwrite crossover diagnostic evidence: {', '.join(existing)}")
        if (args.max_bond_dimension < 2 or args.truncation_threshold < 0 or
                args.dispatch_threshold < 1 or args.cell_wall_time_seconds <= 0 or args.shots < 1):
            raise RuntimeError("invalid diagnostic configuration")
        manifest = load_manifest(args.manifest)
        custom_python = environment_python(args.custom_environment)
        raw_dir = run_dir / "diagnostic_cells"
        report_path = raw_dir / "custom_gpu.report.json"
        command = [
            str(custom_python), str(CELL_DRIVER), "--manifest", str(args.manifest.resolve()),
            "--backend", "custom_gpu", "--run-id", args.run_id,
            "--warmups-output", str(raw_dir / "custom_gpu.warmups.jsonl"),
            "--timings-output", str(raw_dir / "custom_gpu.timings.jsonl"),
            "--report-output", str(report_path), "--warmups", "1", "--timed-repetitions", "1",
            "--shots", str(args.shots), "--max-bond-dimension", str(args.max_bond_dimension),
            "--truncation-threshold", str(args.truncation_threshold),
            "--seed-simulator", str(args.seed_simulator), "--seed-transpiler", str(args.seed_transpiler),
            "--events-dir", str(run_dir / "cutensornet_events"),
            "--profile-dir", str(run_dir / "cutensornet_profiles"),
            "--decisions-dir", str(run_dir / "cutensornet_decisions"),
            "--dispatch-threshold", str(args.dispatch_threshold),
            "--cell-wall-time-seconds", str(args.cell_wall_time_seconds),
        ]
        print("[CROSSOVER-DIAGNOSTIC] custom_gpu", flush=True)
        if subprocess.run(command, text=True).returncode:
            raise RuntimeError(f"custom-GPU diagnostic failed; preserved partial evidence in {run_dir}")
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if not isinstance(report, dict) or report.get("instrumentation_mode") != "opt_in_recorder":
            raise RuntimeError("custom-GPU diagnostic did not retain opt-in recorder metadata")
        proof = report.get("offload_cells")
        if not isinstance(proof, list):
            raise RuntimeError("custom-GPU diagnostic lacks offload proof cells")
        (run_dir / "offload_proof.json").write_text(json.dumps({
            "schema_version": 1, "run_id": args.run_id, "status": "PASS",
            "source": "instrumented_crossover_diagnostic", "performance_claims_permitted": False,
            "cells": proof,
        }, indent=2), encoding="utf-8")
        summary = profile_summary(report, threshold=args.dispatch_threshold)
        summary.update({
            "run_id": args.run_id, "dispatch_threshold_elements": args.dispatch_threshold,
            "source": "instrumented_crossover_diagnostic", "performance_claims_permitted": False,
        })
        (run_dir / "profile_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        (run_dir / "crossover_diagnostic.json").write_text(json.dumps({
            "schema_version": 1, "run_id": args.run_id, "status": "PASS",
            "purpose": "offload and phase-profile diagnostic only; not timing evidence",
            "performance_claims_permitted": False,
            "manifest_path": str(args.manifest.resolve()), "manifest_sha256": manifest["manifest_sha256"],
            "protocol": {"warmups": 1, "timed_repetitions": 1, "shots": args.shots},
            "simulation_config": {
                "method": "matrix_product_state", "device": "GPU", "shots": args.shots,
                "max_bond_dimension": args.max_bond_dimension,
                "truncation_threshold": args.truncation_threshold,
                "seed_simulator": args.seed_simulator, "seed_transpiler": args.seed_transpiler,
            },
            "dispatch_threshold_elements": args.dispatch_threshold,
            "instrumentation": {"events": True, "profiles": True, "decisions": True},
            "cell_report": report,
        }, indent=2), encoding="utf-8")
        print(f"PASS: crossover diagnostic evidence written to {run_dir}")
        return 0
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
