#!/usr/bin/env python3
"""Validate the machine-readable, publication-grade evidence for one run.

The validator deliberately accepts no inferred evidence.  Each timing cell
must carry its own raw samples and configuration, while the custom-GPU cell
must also carry a successful cuTensorNet SVD record.  See
``EVIDENCE_SCHEMA.md`` for the on-disk contract.

Exit 0 means complete and internally consistent evidence; exit 1 means
present-but-invalid evidence; exit 2 means an incomplete run.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


REQUIRED_FILES = (
    "environment_manifest.json",
    "build_manifest.json",
    "offload_proof.json",
    "correctness_raw.jsonl",
    "warmups_raw.jsonl",
    "timings_raw.jsonl",
    "aggregate.json",
)
# These labels deliberately encode both implementation provenance and device.
# A stock Aer GPU-MPS timing cell is invalid: upstream Aer documents MPS as a
# CPU method, so presenting such a cell as a performance control would be a
# false comparison.  ``upstream_cpu`` is an integration/correctness control,
# not a matched timing cell.
TIMING_BACKENDS = frozenset(("custom_cpu", "custom_gpu"))
CORRECTNESS_BACKENDS = frozenset(("custom_cpu", "custom_gpu", "upstream_cpu"))
ALL_BACKENDS = TIMING_BACKENDS | {"upstream_cpu"}
TIMED_REPETITIONS = 20
WARMUP_REPETITIONS = 5
COMPARABLE_CONFIG_FIELDS = (
    "method",
    "shots",
    "max_bond_dimension",
    "truncation_threshold",
    "seed_simulator",
    "seed_transpiler",
)


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path.name} must contain a JSON object")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path.name}:{number} is not a JSON object")
        records.append(value)
    return records


def cell_key(record: dict[str, Any], *, allowed_backends: frozenset[str] = ALL_BACKENDS) -> tuple[str, str] | None:
    circuit_id, backend = record.get("circuit_id"), record.get("backend")
    if not isinstance(circuit_id, str) or not circuit_id:
        return None
    if backend not in allowed_backends:
        return None
    return circuit_id, backend


def stable_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def validate_simulation_config(record: dict[str, Any], label: str, errors: list[str]) -> dict[str, Any] | None:
    config = record.get("simulation_config")
    if not isinstance(config, dict):
        errors.append(f"{label} lacks simulation_config")
        return None
    missing = [field for field in COMPARABLE_CONFIG_FIELDS if field not in config]
    if missing:
        errors.append(f"{label} simulation_config lacks {', '.join(missing)}")
        return None
    if config.get("method") != "matrix_product_state":
        errors.append(f"{label} does not use matrix_product_state")
    return config


def validate_measurement_records(
    records: list[dict[str, Any]],
    *,
    run_id: str,
    label: str,
    expected_warmup: bool,
    expected_count: int,
    allowed_backends: frozenset[str],
    errors: list[str],
) -> dict[tuple[str, str], dict[str, Any]]:
    """Return one representative record per valid timing cell."""
    representatives: dict[tuple[str, str], dict[str, Any]] = {}
    indexes: dict[tuple[str, str], set[int]] = defaultdict(set)
    counts: Counter[tuple[str, str]] = Counter()
    if not records:
        errors.append(f"no {label} records")
        return representatives
    for number, record in enumerate(records, start=1):
        prefix = f"{label} record {number}"
        if record.get("run_id") != run_id:
            errors.append(f"{prefix} has a different run_id")
            continue
        key = cell_key(record, allowed_backends=allowed_backends)
        if key is None:
            errors.append(f"{prefix} has invalid circuit_id or backend")
            continue
        if record.get("is_warmup") is not expected_warmup:
            errors.append(f"{prefix} has wrong is_warmup flag")
        sample_index = record.get("sample_index")
        if not isinstance(sample_index, int) or isinstance(sample_index, bool) or not 0 <= sample_index < expected_count:
            errors.append(f"{prefix} has invalid sample_index")
        elif sample_index in indexes[key]:
            errors.append(f"{label} cell {key} repeats sample_index {sample_index}")
        else:
            indexes[key].add(sample_index)
        elapsed = record.get("elapsed_seconds")
        if (not isinstance(elapsed, (int, float)) or isinstance(elapsed, bool)
                or not math.isfinite(float(elapsed)) or float(elapsed) <= 0):
            errors.append(f"{prefix} has invalid elapsed_seconds")
        config = validate_simulation_config(record, prefix, errors)
        if key not in representatives:
            representatives[key] = record
        elif config is not None:
            original = validate_simulation_config(representatives[key], f"{label} cell {key}", errors)
            if original is not None and stable_json(config) != stable_json(original):
                errors.append(f"{label} cell {key} has inconsistent simulation_config")
        counts[key] += 1
    expected_indexes = set(range(expected_count))
    for key, count in counts.items():
        if count != expected_count:
            errors.append(f"{label} cell {key} has {count}, expected {expected_count} samples")
        if indexes[key] != expected_indexes:
            errors.append(f"{label} cell {key} sample_index values must be 0..{expected_count - 1}")
    return representatives


def validate_run_directory(run_dir: Path) -> tuple[int, list[str]]:
    """Return ``(exit_code, diagnostics)`` without printing, for unit tests."""
    missing = [name for name in REQUIRED_FILES if not (run_dir / name).is_file()]
    if missing:
        return 2, [f"BLOCKED missing evidence: {', '.join(missing)}"]
    try:
        environment = load_json(run_dir / "environment_manifest.json")
        build = load_json(run_dir / "build_manifest.json")
        offload = load_json(run_dir / "offload_proof.json")
        aggregate = load_json(run_dir / "aggregate.json")
        correctness = load_jsonl(run_dir / "correctness_raw.jsonl")
        warmups = load_jsonl(run_dir / "warmups_raw.jsonl")
        timings = load_jsonl(run_dir / "timings_raw.jsonl")
    except (OSError, json.JSONDecodeError, ValueError) as error:
        return 1, [f"FAIL invalid evidence: {error}"]

    run_id = run_dir.name
    errors: list[str] = []
    for name, document in (("environment_manifest", environment), ("build_manifest", build),
                           ("offload_proof", offload), ("aggregate", aggregate)):
        if document.get("run_id") != run_id:
            errors.append(f"{name} has a different run_id")

    aer = environment.get("aer")
    if not isinstance(aer, dict) or not isinstance(aer.get("source_path"), str):
        errors.append("environment manifest lacks Aer source provenance")
    elif "GPU" not in aer.get("available_devices", []):
        errors.append("environment manifest does not record an available GPU")
    source = build.get("source")
    if not isinstance(source, dict) or not isinstance(source.get("path"), str) or not source.get("commit"):
        errors.append("build manifest lacks source path and commit provenance")
    elif isinstance(aer, dict) and isinstance(aer.get("source_path"), str) and source["path"] not in aer["source_path"]:
        errors.append("environment Aer import does not originate from build manifest source")
    if not build.get("cmake_cuda_enabled") or not build.get("cutensornet_enabled"):
        errors.append("build manifest does not confirm CUDA and cuTensorNet")

    timing_cells = validate_measurement_records(
        timings, run_id=run_id, label="timing", expected_warmup=False,
        expected_count=TIMED_REPETITIONS, allowed_backends=TIMING_BACKENDS, errors=errors,
    )
    warmup_cells = validate_measurement_records(
        warmups, run_id=run_id, label="warm-up", expected_warmup=True,
        expected_count=WARMUP_REPETITIONS, allowed_backends=TIMING_BACKENDS, errors=errors,
    )
    if set(timing_cells) != set(warmup_cells):
        errors.append("warm-up and timing cell sets differ")

    circuit_backends: dict[str, set[str]] = defaultdict(set)
    for circuit_id, backend in timing_cells:
        circuit_backends[circuit_id].add(backend)
    for circuit_id, backends in circuit_backends.items():
        if backends != TIMING_BACKENDS:
            errors.append(f"circuit {circuit_id} lacks matched custom-CPU and custom-GPU timing cells")
            continue
        comparable: set[str] = set()
        for backend in TIMING_BACKENDS:
            config = validate_simulation_config(timing_cells[(circuit_id, backend)], f"timing cell {(circuit_id, backend)}", errors)
            if config is not None:
                comparable.add(stable_json({field: config[field] for field in COMPARABLE_CONFIG_FIELDS}))
        if len(comparable) != 1:
            errors.append(f"circuit {circuit_id} uses unmatched custom-CPU/custom-GPU simulation settings")

    correctness_cells: set[tuple[str, str]] = set()
    if not correctness:
        errors.append("no correctness records")
    for number, record in enumerate(correctness, start=1):
        prefix = f"correctness record {number}"
        if record.get("run_id") != run_id:
            errors.append(f"{prefix} has a different run_id")
            continue
        key = cell_key(record, allowed_backends=CORRECTNESS_BACKENDS)
        if key is None:
            errors.append(f"{prefix} has invalid circuit_id or backend")
            continue
        try:
            fidelity = float(record["fidelity"])
        except (KeyError, TypeError, ValueError):
            errors.append(f"{prefix} lacks numeric fidelity")
            continue
        if not math.isfinite(fidelity) or fidelity < 0.99:
            errors.append(f"{prefix} falls below fidelity threshold 0.99")
        correctness_cells.add(key)
    timing_circuits = {circuit_id for circuit_id, _ in timing_cells}
    for circuit_id in timing_circuits:
        expected_correctness = {(circuit_id, backend) for backend in CORRECTNESS_BACKENDS}
        missing_correctness = expected_correctness - correctness_cells
        if missing_correctness:
            labels = ", ".join(backend for _, backend in sorted(missing_correctness))
            errors.append(f"circuit {circuit_id} lacks correctness integration controls: {labels}")

    proof_cells = offload.get("cells")
    if offload.get("status") != "PASS" or not isinstance(proof_cells, list) or not proof_cells:
        errors.append("offload proof must have status PASS and non-empty cells")
        proof_cells = []
    proven_custom_cells: set[tuple[str, str]] = set()
    for number, proof in enumerate(proof_cells, start=1):
        if not isinstance(proof, dict):
            errors.append(f"offload proof cell {number} is not an object")
            continue
        key = cell_key(proof, allowed_backends=frozenset(("custom_gpu",)))
        if key is None or key[1] != "custom_gpu":
            errors.append(f"offload proof cell {number} must identify a custom_gpu circuit")
            continue
        try:
            calls = int(proof.get("cutensor_csvd_wrapper_calls", 0))
        except (TypeError, ValueError):
            calls = 0
        if calls < 1:
            errors.append(f"offload proof cell {key} records no cutensor_csvd_wrapper call")
            continue
        if not isinstance(proof.get("events_path"), str) or not proof["events_path"]:
            errors.append(f"offload proof cell {key} lacks events_path provenance")
            continue
        proven_custom_cells.add(key)
    offload_required_cells: set[tuple[str, str]] = set()
    for key, record in timing_cells.items():
        if key[1] != "custom_gpu":
            continue
        required = record.get("offload_required")
        if not isinstance(required, bool):
            errors.append(f"custom-GPU timing cell {key} lacks boolean offload_required")
        elif required:
            offload_required_cells.add(key)
    if offload_required_cells != proven_custom_cells:
        errors.append("offload proof cells do not exactly cover offload-required custom-GPU timing cells")

    aggregate_cells = aggregate.get("cells")
    if not isinstance(aggregate_cells, list):
        errors.append("aggregate lacks cells list")
    else:
        aggregate_keys: set[tuple[str, str]] = set()
        for number, cell in enumerate(aggregate_cells, start=1):
            if not isinstance(cell, dict) or (key := cell_key(cell, allowed_backends=TIMING_BACKENDS)) is None:
                errors.append(f"aggregate cell {number} has invalid circuit_id or backend")
                continue
            if key in aggregate_keys:
                errors.append(f"aggregate repeats cell {key}")
            aggregate_keys.add(key)
            if cell.get("timed_sample_count") != TIMED_REPETITIONS or cell.get("warmup_sample_count") != WARMUP_REPETITIONS:
                errors.append(f"aggregate cell {key} does not declare 5 warm-ups and 20 timed samples")
            config = validate_simulation_config(cell, f"aggregate cell {key}", errors)
            raw = timing_cells.get(key)
            if config is not None and raw is not None:
                raw_config = validate_simulation_config(raw, f"timing cell {key}", errors)
                if raw_config is not None and stable_json(config) != stable_json(raw_config):
                    errors.append(f"aggregate cell {key} simulation_config differs from raw timings")
        if aggregate_keys != set(timing_cells):
            errors.append("aggregate cells do not exactly cover timing cells")

    # Stock GPU MPS is an explicitly optional negative capability control.  It
    # is intentionally outside raw timing/aggregate data.  If a runner records
    # it, require an honest unsupported result rather than allowing it to be
    # re-labelled as a benchmark backend.
    capability_path = run_dir / "capability_controls.json"
    if capability_path.exists():
        try:
            capabilities = load_json(capability_path)
        except (OSError, json.JSONDecodeError, ValueError) as error:
            errors.append(f"invalid capability controls: {error}")
        else:
            if capabilities.get("run_id") != run_id:
                errors.append("capability controls has a different run_id")
            cells = capabilities.get("cells")
            if not isinstance(cells, list):
                errors.append("capability controls lacks cells list")
            else:
                for number, control in enumerate(cells, start=1):
                    if not isinstance(control, dict):
                        errors.append(f"capability control {number} is not an object")
                        continue
                    if control.get("control_id") != "stock_gpu_mps_capability":
                        errors.append(f"capability control {number} has unknown control_id")
                    if control.get("method") != "matrix_product_state" or control.get("requested_device") != "GPU":
                        errors.append(f"capability control {number} is not a stock GPU MPS request")
                    if control.get("status") != "UNSUPPORTED":
                        errors.append(f"capability control {number} must record status UNSUPPORTED")

    if errors:
        return 1, ["FAIL evidence validation", *(f"- {error}" for error in errors)]
    return 0, [f"PASS evidence validation for {run_id}"]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    status, diagnostics = validate_run_directory(args.run_dir)
    print("\n".join(diagnostics))
    return status


if __name__ == "__main__":
    raise SystemExit(main())
