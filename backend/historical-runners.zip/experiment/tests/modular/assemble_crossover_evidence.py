#!/usr/bin/env python3
"""Join same-run correctness, provenance, and crossover raw evidence safely."""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path
from typing import Any

from assemble_l4_evidence_bundle import comparison
from evidence_paths import resolve_frozen_manifest
from run_e2_numerical_correctness_pilot import load_manifest
from validate_crossover_evidence import validate_run_directory
from validate_e2_correctness import validate as validate_e2


REPORTS = {"custom_gpu": "e2_custom_gpu.json", "custom_cpu": "e2_custom_cpu.json", "upstream_cpu": "e2_upstream_cpu.json"}
MANIFESTS_DIR = Path(__file__).resolve().parents[2] / "manifests"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path.name} must contain a JSON object")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def aggregate_cell(circuit_id: str, backend: str, timings: list[dict[str, Any]], warmups: list[dict[str, Any]]) -> dict[str, Any]:
    values = [float(record["elapsed_seconds"]) for record in timings]
    return {
        "circuit_id": circuit_id, "backend": backend,
        "simulation_config": timings[0]["simulation_config"],
        "warmup_sample_count": len(warmups), "timed_sample_count": len(values),
        "median_seconds": statistics.median(values), "mean_seconds": statistics.fmean(values),
        "sample_standard_deviation_seconds": statistics.stdev(values),
        "minimum_seconds": min(values), "maximum_seconds": max(values),
    }


def assemble(run_dir: Path) -> None:
    run_dir = run_dir.resolve()
    output = run_dir / "crossover_aggregate.json"
    if output.exists():
        raise RuntimeError(f"refusing to overwrite derived evidence: {output.name}")
    executor = load_json(run_dir / "crossover_executor.json")
    manifest = load_manifest(
        resolve_frozen_manifest(
            executor["manifest_path"],
            executor["manifest_sha256"],
            manifests_dir=MANIFESTS_DIR,
            load_manifest=load_manifest,
        )
    )
    if executor.get("run_id") != run_dir.name or executor.get("manifest_sha256") != manifest["manifest_sha256"]:
        raise RuntimeError("crossover executor run ID or frozen manifest does not match")
    e2_errors = validate_e2(run_dir)
    if e2_errors:
        raise RuntimeError("invalid same-run E2 controls: " + "; ".join(e2_errors))
    reports = {backend: load_json(run_dir / filename) for backend, filename in REPORTS.items()}
    exact_ids = {str(spec["id"]) for spec in manifest["circuits"] if spec.get("exact_reference")}
    for backend, report in reports.items():
        if report.get("manifest_sha256") != manifest["manifest_sha256"]:
            raise RuntimeError(f"{backend} E2 report has a mismatched manifest hash")
        report_ids = {str(record.get("circuit_id")) for record in report.get("records", []) if isinstance(record, dict)}
        if report_ids != exact_ids:
            raise RuntimeError(f"{backend} E2 report does not exactly cover frozen exact-reference circuits")
    timings = load_jsonl(run_dir / "timings_raw.jsonl")
    warmups = load_jsonl(run_dir / "warmups_raw.jsonl")
    circuit_ids = {str(spec["id"]) for spec in manifest["circuits"]}
    cells: list[dict[str, Any]] = []
    comparisons: list[dict[str, Any]] = []
    for offset, circuit_id in enumerate(sorted(circuit_ids)):
        per_backend: dict[str, list[dict[str, Any]]] = {}
        for backend in ("custom_cpu", "custom_gpu"):
            per_backend[backend] = [item for item in timings if item.get("circuit_id") == circuit_id and item.get("backend") == backend]
            matching_warmups = [item for item in warmups if item.get("circuit_id") == circuit_id and item.get("backend") == backend]
            if not per_backend[backend]:
                raise RuntimeError(f"missing {backend} timing records for {circuit_id}")
            cells.append(aggregate_cell(circuit_id, backend, per_backend[backend], matching_warmups))
        comparisons.append({
            "circuit_id": circuit_id,
            **comparison([float(item["elapsed_seconds"]) for item in per_backend["custom_cpu"]],
                         [float(item["elapsed_seconds"]) for item in per_backend["custom_gpu"]],
                         seed=20260723 + offset),
        })
    output.write_text(json.dumps({
        "schema_version": 1, "run_id": run_dir.name, "measurement_mode": executor["measurement_mode"],
        "cells": cells, "end_to_end_comparisons": comparisons,
        "overall_end_to_end_gpu_advantage_status": (
            "CONFIRMED" if comparisons and all(item["advantage_status"] == "CONFIRMED" for item in comparisons)
            else "NOT_CONFIRMED"),
    }, indent=2), encoding="utf-8")
    status, diagnostics = validate_run_directory(run_dir)
    if status:
        output.unlink(missing_ok=True)
        raise RuntimeError("assembled crossover bundle failed validation: " + "; ".join(diagnostics))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        assemble(args.run_dir)
        print(f"PASS: assembled crossover evidence bundle {args.run_dir.name}")
        return 0
    except (OSError, KeyError, TypeError, ValueError, RuntimeError, json.JSONDecodeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
