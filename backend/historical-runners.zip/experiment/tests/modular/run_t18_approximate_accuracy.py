#!/usr/bin/env python3
"""Collect the preregistered T18 approximate-MPS accuracy grid.

This orchestrator launches only exact-reference correctness comparisons.  It
does not collect timings, select a cap, or claim an offload result when the
custom-GPU process has no wrapper event.  Each cap gets its own immutable
subdirectory and cap-specific run ID so rejected configurations remain part of
the study record.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from run_e2_numerical_correctness_pilot import load_manifest


HERE = Path(__file__).resolve().parent
EXPERIMENTS = HERE.parents[1]
DEFAULT_MANIFEST = EXPERIMENTS / "manifests" / "t18_approx_brickwork_14_d14.json"
DEFAULT_RUNS_ROOT = Path(__file__).resolve().parents[2] / "new_runs"
E2_DRIVER = HERE / "run_e2_numerical_correctness_pilot.py"
CAPS = (32, 64, 128)
BACKENDS = ("custom_cpu", "custom_gpu", "upstream_cpu")
FIDELITY_MIN = 0.999999
NORM_ERROR_MAX = 1.0e-10
FROZEN_MANIFEST_SHA256 = "1c3be5daeaf07a43a2a9f250639b9397565eca2c13fcf77f9a6532c4830d783b"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_run_id(value: str) -> bool:
    return bool(value) and value.replace("-", "").replace("_", "").replace(".", "").isalnum()


def read_report(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    if not path.is_file():
        return None, "E2 did not write a report"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return None, f"cannot read E2 report: {error}"
    if not isinstance(value, dict):
        return None, "E2 report root is not an object"
    return value, None


def invoke_e2(*, python_bin: Path, backend: str, cap_run_id: str, manifest: Path,
              cap: int, cap_dir: Path, timeout_seconds: float) -> dict[str, object]:
    output = cap_dir / f"e2_{backend}.json"
    command = [
        str(python_bin), str(E2_DRIVER), "--manifest", str(manifest.resolve()),
        "--backend", backend, "--run-id", cap_run_id, "--output", str(output),
        "--max-bond-dimension", str(cap), "--truncation-threshold", "0.0",
        "--mps-fidelity-min", str(FIDELITY_MIN),
    ]
    if backend == "custom_gpu":
        command += ["--events-path", str(cap_dir / "e2_custom_gpu.events.jsonl"), "--allow-no-offload"]
    print(f"[T18] chi={cap} {backend}", flush=True)
    try:
        completed = subprocess.run(command, text=True, timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        return {
            "backend": backend, "status": "TIMEOUT", "returncode": None,
            "report_path": str(output), "report_sha256": None,
            "timeout_seconds": timeout_seconds,
        }
    report, error = read_report(output)
    return {
        "backend": backend,
        "status": str(report.get("status")) if report else "ERROR",
        "returncode": completed.returncode,
        "report_path": str(output),
        "report_sha256": sha256_file(output) if output.is_file() else None,
        "error": error,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True, help="Fresh immutable study ID.")
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument("--custom-python", type=Path, required=True,
                        help="Interpreter from the selected isolated custom-GPU environment.")
    parser.add_argument("--upstream-python", type=Path, required=True,
                        help="Interpreter from the isolated upstream CPU control environment.")
    parser.add_argument("--per-backend-wall-time-seconds", type=float, default=900.0)
    args = parser.parse_args()
    run_dir = args.runs_root / args.run_id
    try:
        if run_dir.exists():
            raise RuntimeError(f"refusing to reuse existing study directory: {run_dir}")
        if not safe_run_id(args.run_id):
            raise RuntimeError("run_id may contain only letters, digits, dot, underscore, and hyphen")
        if args.per_backend_wall_time_seconds <= 0:
            raise RuntimeError("per-backend wall time must be positive")
        if not args.custom_python.is_file() or not args.upstream_python.is_file():
            raise RuntimeError("custom and upstream interpreter paths must exist")
        manifest = load_manifest(args.manifest)
        if (manifest.get("purpose") != "T18 approximate-MPS accuracy-first pilot; not timing evidence." or
                manifest.get("manifest_sha256") != FROZEN_MANIFEST_SHA256):
            raise RuntimeError("T18 runner accepts only the frozen T18 accuracy manifest")
        run_dir.mkdir(parents=True)
        caps: list[dict[str, object]] = []
        for cap in CAPS:
            cap_dir = run_dir / f"chi_{cap:03d}"
            cap_dir.mkdir()
            cap_run_id = f"{args.run_id}__chi{cap:03d}"
            results: list[dict[str, object]] = []
            for backend in BACKENDS:
                python_bin = args.upstream_python if backend == "upstream_cpu" else args.custom_python
                results.append(invoke_e2(
                    python_bin=python_bin, backend=backend, cap_run_id=cap_run_id,
                    manifest=args.manifest, cap=cap, cap_dir=cap_dir,
                    timeout_seconds=args.per_backend_wall_time_seconds,
                ))
            caps.append({"cap": cap, "run_id": cap_run_id, "directory": cap_dir.name,
                         "backend_results": results})
        summary = {
            "schema_version": 1,
            "run_id": args.run_id,
            "purpose": "T18 preregistered approximate-MPS accuracy grid only; no timing or performance claims.",
            "performance_claims_permitted": False,
            "driver_path": str(Path(__file__).resolve()),
            "driver_sha256": sha256_file(Path(__file__)),
            "manifest_path": str(args.manifest.resolve()),
            "manifest_sha256": manifest["manifest_sha256"],
            "caps": list(CAPS),
            "truncation_threshold": 0.0,
            "mps_fidelity_min": FIDELITY_MIN,
            "norm_error_max": NORM_ERROR_MAX,
            "custom_gpu_offload_policy": "NOT_OBSERVED is a retained control result, never offload evidence and never a timing authorization.",
            "per_backend_wall_time_seconds": args.per_backend_wall_time_seconds,
            "cap_runs": caps,
        }
        (run_dir / "t18_collection.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        failures = [result for cap in caps for result in cap["backend_results"]
                    if result.get("returncode") != 0]
        state = "COLLECTED" if not failures else "COLLECTED_WITH_REJECTIONS"
        print(f"{state}: T18 raw accuracy evidence written to {run_dir}")
        # A rejected accuracy point is still correctly collected evidence.
        return 0
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
