#!/usr/bin/env python3
"""Run immutable, uninstrumented GPU-MPS crossover timing cells.

The companion ``run_crossover_gpu_diagnostic.py`` records offload proof and
phase profiles in a separate short process.  Recorder I/O must never occur
inside the 5/20 timed samples collected here.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from run_e2_numerical_correctness_pilot import load_manifest
from run_e3_timing_executor import CELL_DRIVER, DEFAULT_RUNS_ROOT, EXPERIMENTS_DIR, concatenate_new, environment_python


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument("--custom-environment", default=".venv_custom_gpu_pr2168_20260721")
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--timed-repetitions", type=int, default=20)
    parser.add_argument("--shots", type=int, default=100)
    parser.add_argument("--max-bond-dimension", type=int, required=True)
    parser.add_argument("--truncation-threshold", type=float, default=0.0)
    parser.add_argument("--dispatch-threshold", type=int, required=True)
    parser.add_argument("--cell-wall-time-seconds", type=float, default=1800.0,
                        help="Positive per-backend process cap; 1800 seconds is the preregistered escalation guard.")
    parser.add_argument("--seed-simulator", type=int, default=20260722)
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    args = parser.parse_args()
    run_dir = args.runs_root / args.run_id
    try:
        if run_dir.exists():
            raise RuntimeError(f"refusing to reuse existing run directory: {run_dir}")
        if (args.warmups, args.timed_repetitions, args.shots) != (5, 20, 100):
            raise RuntimeError("crossover end-to-end protocol requires exactly 5 warm-ups, 20 timings, and 100 shots")
        if (args.max_bond_dimension < 2 or args.truncation_threshold < 0 or
                args.dispatch_threshold < 1 or args.cell_wall_time_seconds <= 0):
            raise RuntimeError("bond dimension must be >= 2, threshold non-negative, and dispatch threshold positive")
        manifest = load_manifest(args.manifest)
        custom_python = environment_python(args.custom_environment)
        run_dir.mkdir(parents=True)
        raw_dir = run_dir / "raw_cells"
        reports: list[dict[str, Any]] = []
        for backend in ("custom_cpu", "custom_gpu"):
            command = [str(custom_python), str(CELL_DRIVER), "--manifest", str(args.manifest.resolve()),
                       "--backend", backend, "--run-id", args.run_id,
                       "--warmups-output", str(raw_dir / f"{backend}.warmups.jsonl"),
                       "--timings-output", str(raw_dir / f"{backend}.timings.jsonl"),
                       "--report-output", str(raw_dir / f"{backend}.report.json"),
                       "--warmups", "5", "--timed-repetitions", "20", "--shots", "100",
                       "--max-bond-dimension", str(args.max_bond_dimension),
                       "--truncation-threshold", str(args.truncation_threshold),
                       "--seed-simulator", str(args.seed_simulator), "--seed-transpiler", str(args.seed_transpiler),
                       "--cell-wall-time-seconds", str(args.cell_wall_time_seconds)]
            if backend == "custom_gpu":
                command += ["--allow-uninstrumented-gpu-timing",
                            "--dispatch-threshold", str(args.dispatch_threshold)]
            print("[CROSSOVER]", backend, flush=True)
            if subprocess.run(command, text=True).returncode:
                raise RuntimeError(f"{backend} timing cell failed; preserved partial evidence in {run_dir}")
            reports.append(json.loads((raw_dir / f"{backend}.report.json").read_text(encoding="utf-8")))
        concatenate_new(run_dir / "warmups_raw.jsonl", [raw_dir / "custom_cpu.warmups.jsonl", raw_dir / "custom_gpu.warmups.jsonl"])
        concatenate_new(run_dir / "timings_raw.jsonl", [raw_dir / "custom_cpu.timings.jsonl", raw_dir / "custom_gpu.timings.jsonl"])
        (run_dir / "crossover_executor.json").write_text(json.dumps({
            "schema_version": 1, "run_id": args.run_id, "status": "PASS",
            "manifest_path": str(args.manifest.resolve()), "manifest_sha256": manifest["manifest_sha256"],
            "measurement_mode": "end_to_end_mps_with_terminal_measurements",
            "protocol": {"warmups": 5, "timed_repetitions": 20, "shots": 100},
            "max_bond_dimension": args.max_bond_dimension,
            "truncation_threshold": args.truncation_threshold,
            "seed_simulator": args.seed_simulator,
            "seed_transpiler": args.seed_transpiler,
            "dispatch_threshold_elements": args.dispatch_threshold,
            "cell_wall_time_seconds": args.cell_wall_time_seconds,
            "timing_instrumentation": "none",
            "diagnostic_required": "run_crossover_gpu_diagnostic.py",
            "cells": reports,
        }, indent=2), encoding="utf-8")
        print(f"PASS: crossover raw evidence written to {run_dir}")
        return 0
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
