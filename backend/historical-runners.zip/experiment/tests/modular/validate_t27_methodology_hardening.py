#!/usr/bin/env python3
"""Independently validate the frozen T27 raw and derived evidence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from evidence_paths import resolve_frozen_manifest, resolve_run_local
from run_e2_numerical_correctness_pilot import load_manifest
from t27_interpretation import (
    PUBLICATION_INTERPRETATIONS,
    publication_interpretation,
)


EXPECTED_ORDERS = [
    ["custom_cpu", "custom_gpu"],
    ["custom_gpu", "custom_cpu"],
    ["custom_gpu", "custom_cpu"],
    ["custom_cpu", "custom_gpu"],
]
EXPECTED_THREADS = [6, 1, 12, 2, 4]
MANIFESTS_DIR = Path(__file__).resolve().parents[2] / "manifests"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path} must contain a JSON object")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def validate(run_dir: Path) -> list[str]:
    run_dir = run_dir.resolve()
    errors: list[str] = []
    try:
        executor = load_json(run_dir / "t27_executor.json")
        aggregate = load_json(run_dir / "t27_aggregate.json")
        build = load_json(run_dir / "build_manifest.json")
        environment = load_json(run_dir / "environment_manifest.json")
        manifest = load_manifest(
            resolve_frozen_manifest(
                executor["manifest_path"],
                executor["manifest_sha256"],
                manifests_dir=MANIFESTS_DIR,
                load_manifest=load_manifest,
            )
        )
        sensitivity_manifest = load_manifest(
            resolve_frozen_manifest(
                executor["sensitivity_manifest_path"],
                executor["sensitivity_manifest_sha256"],
                manifests_dir=MANIFESTS_DIR,
                load_manifest=load_manifest,
            )
        )
    except (OSError, KeyError, ValueError, RuntimeError, json.JSONDecodeError) as error:
        return [f"cannot load T27 bundle: {error}"]
    if (executor.get("task"), executor.get("run_id"), executor.get("status")) != (
        "T27",
        run_dir.name,
        "PASS",
    ):
        errors.append("executor identity/status mismatch")
    if (
        executor.get("manifest_sha256") != manifest["manifest_sha256"]
        or executor.get("sensitivity_manifest_sha256")
        != sensitivity_manifest["manifest_sha256"]
    ):
        errors.append("frozen manifest hash mismatch")
    if (
        build.get("run_id"),
        build.get("cmake_cuda_enabled"),
        build.get("cutensornet_enabled"),
        build.get("source", {}).get("dirty"),
    ) != (run_dir.name, True, True, False):
        errors.append("T27 clean CUDA/cuTensorNet build provenance mismatch")
    if (
        environment.get("run_id"),
        environment.get("backend"),
        environment.get("environment", {}).get("OMP_NUM_THREADS"),
        "GPU" in environment.get("aer", {}).get("available_devices", []),
    ) != (run_dir.name, "custom_gpu", "6", True):
        errors.append("T27 environment/thread/GPU provenance mismatch")
    protocol = executor.get("protocol", {})
    if (
        protocol.get("warmups"),
        protocol.get("timed_repetitions"),
        protocol.get("primary_threads"),
        protocol.get("thread_sensitivity_order"),
        protocol.get("primary_orders"),
    ) != (5, 20, 6, EXPECTED_THREADS, EXPECTED_ORDERS):
        errors.append("T27 protocol differs from the frozen run protocol")

    circuit_ids = {str(spec["id"]) for spec in manifest["circuits"]}
    thread_items = executor.get("thread_sensitivity", [])
    if not isinstance(thread_items, list) or [
        item.get("threads") for item in thread_items if isinstance(item, dict)
    ] != EXPECTED_THREADS:
        errors.append("T27 thread-sensitivity executor layout mismatch")
        thread_items = []
    for item in thread_items:
        threads = int(item["threads"])
        try:
            destination = resolve_run_local(
                item.get("destination"),
                run_dir,
                Path("thread_sensitivity") / f"threads_{threads:02d}",
            )
            records = load_jsonl(destination / "custom_cpu.timings.jsonl")
        except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
            errors.append(f"cannot resolve thread-sensitivity cell {threads}: {error}")
            continue
        if len(records) != 20 or {record.get("circuit_id") for record in records} != {
            "brickwork_n16_d24_s20260724"
        }:
            errors.append(f"invalid thread-sensitivity cell: {destination}")
    repetitions = executor.get("primary_repetitions", [])
    if len(repetitions) != 4:
        errors.append("T27 must contain four within-campaign timing blocks")
    for index, item in enumerate(repetitions):
        if not isinstance(item, dict):
            errors.append(f"invalid repetition descriptor {index + 1}")
            continue
        repetition = index + 1
        if item.get("repetition") != repetition:
            errors.append(f"repetition identity mismatch in repetition {repetition}")
        try:
            destination = resolve_run_local(
                item.get("destination"),
                run_dir,
                Path("primary") / f"repetition_{repetition:02d}",
            )
        except (OSError, RuntimeError, ValueError) as error:
            errors.append(f"cannot resolve repetition {repetition}: {error}")
            continue
        if item.get("backend_order") != EXPECTED_ORDERS[index]:
            errors.append(f"backend order mismatch in repetition {index + 1}")
        for backend in ("custom_cpu", "custom_gpu"):
            try:
                records = load_jsonl(destination / f"{backend}.timings.jsonl")
            except (OSError, ValueError, json.JSONDecodeError) as error:
                errors.append(
                    f"cannot load repetition {repetition} {backend}: {error}"
                )
                continue
            counts = {
                circuit_id: sum(
                    record.get("circuit_id") == circuit_id for record in records
                )
                for circuit_id in circuit_ids
            }
            if counts != {circuit_id: 20 for circuit_id in circuit_ids}:
                errors.append(
                    f"invalid primary sample coverage: repetition {index + 1} {backend}"
                )

    try:
        diagnostic_dir = resolve_run_local(
            executor["diagnostic"]["destination"],
            run_dir,
            Path("diagnostic"),
        )
        diagnostic = load_json(diagnostic_dir / "custom_gpu.report.json")
    except (OSError, KeyError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        errors.append(f"cannot resolve T27 diagnostic: {error}")
        diagnostic = {}
    raw_offload = diagnostic.get("offload_cells", [])
    if not isinstance(raw_offload, list):
        errors.append("T27 diagnostic offload cells are not a list")
        raw_offload = []
    offload: dict[str, int] = {}
    for item in raw_offload:
        if not isinstance(item, dict):
            errors.append("T27 diagnostic contains an invalid offload cell")
            continue
        try:
            offload[str(item.get("circuit_id"))] = int(
                item.get("cutensor_csvd_wrapper_calls", 0)
            )
        except (TypeError, ValueError):
            errors.append("T27 diagnostic contains an invalid offload count")
    for circuit_id in circuit_ids:
        if offload.get(circuit_id, 0) < 1:
            errors.append(f"missing diagnostic GPU offload proof: {circuit_id}")

    summaries = aggregate.get("circuit_summaries", [])
    aggregate_repetitions = aggregate.get("per_repetition", [])
    if (
        aggregate.get("task"),
        aggregate.get("run_id"),
        len(aggregate_repetitions) if isinstance(aggregate_repetitions, list) else -1,
        len(summaries) if isinstance(summaries, list) else -1,
    ) != ("T27", run_dir.name, 16, 4):
        errors.append("aggregate identity or coverage mismatch")
    schema_version = aggregate.get("schema_version")
    if schema_version not in {1, 2}:
        errors.append("unsupported T27 aggregate schema version")
    if not isinstance(summaries, list):
        summaries = []
    if schema_version == 1 and any(
        not isinstance(item, dict)
        or item.get("robust_advantage_status")
        not in {"ROBUST_CONFIRMED", "NOT_ROBUSTLY_CONFIRMED"}
        for item in summaries
    ):
        errors.append("legacy aggregate contains an invalid robust decision")
    if schema_version == 2 and any(
        isinstance(item, dict) and "robust_advantage_status" in item
        for item in summaries
    ):
        errors.append("schema-2 aggregate contains a stale two-state decision")
    if isinstance(aggregate_repetitions, list) and isinstance(summaries, list):
        for summary in summaries:
            if not isinstance(summary, dict):
                errors.append("aggregate contains a non-object circuit summary")
                continue
            circuit_id = str(summary.get("circuit_id"))
            matching = [
                item
                for item in aggregate_repetitions
                if isinstance(item, dict) and item.get("circuit_id") == circuit_id
            ]
            if len(matching) != 4:
                errors.append(f"aggregate repetition coverage mismatch: {circuit_id}")
                continue
            try:
                interpretation = publication_interpretation(matching)
            except (TypeError, ValueError) as error:
                errors.append(f"cannot interpret T27 circuit {circuit_id}: {error}")
                continue
            recorded = summary.get("publication_interpretation")
            if schema_version == 2 and recorded is None:
                errors.append(f"missing publication interpretation: {circuit_id}")
            if recorded is not None and recorded != interpretation:
                errors.append(f"publication interpretation mismatch: {circuit_id}")
            if recorded is not None and recorded not in PUBLICATION_INTERPRETATIONS:
                errors.append(f"invalid publication interpretation: {circuit_id}")
            if schema_version == 1:
                expected_legacy = (
                    "ROBUST_CONFIRMED"
                    if interpretation == "ROBUST_GPU_FASTER"
                    else "NOT_ROBUSTLY_CONFIRMED"
                )
                if summary.get("robust_advantage_status") != expected_legacy:
                    errors.append(f"legacy robust GPU decision mismatch: {circuit_id}")
    if aggregate.get("diagnostic_offload_calls") != offload:
        errors.append("aggregate diagnostic offload counts differ from raw diagnostic")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    errors = validate(args.run_dir.resolve())
    if errors:
        print("BLOCKED T27 evidence")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"PASS: independently validated T27 bundle {args.run_dir.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
