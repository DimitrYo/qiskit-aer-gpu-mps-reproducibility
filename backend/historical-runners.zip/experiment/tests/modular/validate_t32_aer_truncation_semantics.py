#!/usr/bin/env python3
"""Independently validate the recorded T32 Aer boundary regression."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any


EXPECTED_CASES = {
    "tail_below_cutoff": 1,
    "tail_equal_cutoff": 2,
    "tail_above_cutoff": 2,
}
EXPERIMENTS = Path(__file__).resolve().parents[2]
T32_HISTORICAL_RUN = "20260725_t32_aer_truncation_semantics_01"
T32_SOURCE_COMMIT = "f7631b1c9be2ffa24474d0d6e40225f8627ee78d"
T32_PARENT_COMMIT = "75137ba7dee76ec864cb723a6c3aa9650fbf4f43"
T32_SOURCE_TREE = "8a973fe10853a41b34489e824d5002e2b810d57a"
T32_SOURCE_FILES = {
    "svd_cpp": "src/simulators/matrix_product_state/svd.cpp",
    "source_test": "test/terra/backends/aer_simulator/test_save_matrix_product_state.py",
}
T32_PATCH = "0001-Fix-MPS-terminal-tail-truncation-semantics.patch"
T32_HISTORICAL_HASHES = {
    "svd_cpp": "2ae651d723c6b7e5682df764fffd54b66525dee133cdab538294f94cd8b30037",
    "source_test": "88872a19d610daea6edf4d08f1656941c1794f674876456c239a03016ee7fc9d",
    "source_patch": "ac3ad87d586e12440f5d9bb78a624e88ad7b1ad3404a3dd81b6a767160ae7733",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def historical_source_file(key: str) -> Path:
    """Resolve the byte-preserving audit in the export or maintained sources."""
    packaged = EXPERIMENTS / "source/t32_audit" / key
    if packaged.is_file():
        return packaged
    if key == "source_patch":
        return EXPERIMENTS / "source_patches/t32" / T32_PATCH
    return EXPERIMENTS / "source_patches/t32/audit" / key


def validate_source(source: object, *, historical: bool) -> list[str]:
    if not isinstance(source, dict):
        return ["T32 source provenance is missing"]
    errors: list[str] = []
    if (
        source.get("git_commit") != T32_SOURCE_COMMIT
        or source.get("git_parent_commit") != T32_PARENT_COMMIT
        or source.get("git_status_porcelain") != ""
    ):
        errors.append("T32 clean source provenance mismatch")
    if historical:
        for key, expected_hash in T32_HISTORICAL_HASHES.items():
            item = source.get(key, {})
            if not isinstance(item, dict) or item.get("sha256") != expected_hash:
                errors.append(f"T32 historical source declaration mismatch: {key}")
                continue
            path = Path(str(item.get("path", "")))
            if not path.is_file():
                path = historical_source_file(key)
            if not path.is_file() or sha256(path) != expected_hash:
                errors.append(f"T32 source hash mismatch: {key}")
        return errors

    # New runs must preserve their own raw hashes and provide the actual source
    # checkout. They cannot borrow the historical audit's byte hashes.
    source_root = Path(str(source.get("path", ""))).resolve()
    try:
        def git(*args: str) -> bytes:
            return subprocess.check_output(
                ["git", "-C", str(source_root), *args], stderr=subprocess.PIPE
            )

        if (
            Path(git("rev-parse", "--show-toplevel").decode().strip()).resolve() != source_root
            or git("rev-parse", "HEAD").decode().strip() != T32_SOURCE_COMMIT
            or git("rev-parse", "HEAD^").decode().strip() != T32_PARENT_COMMIT
            or git("rev-parse", "HEAD^{tree}").decode().strip() != T32_SOURCE_TREE
            or git("status", "--porcelain").strip()
        ):
            return errors + ["T32 new source is not the registered clean Git checkout"]
        for key, relative in T32_SOURCE_FILES.items():
            item = source.get(key, {})
            if not isinstance(item, dict):
                errors.append(f"T32 new source declaration is missing: {key}")
                continue
            path = Path(str(item.get("path", ""))).resolve()
            if path != source_root / relative or not path.is_file():
                errors.append(f"T32 new source path mismatch: {key}")
                continue
            content = path.read_bytes()
            if hashlib.sha256(content).hexdigest() != item.get("sha256"):
                errors.append(f"T32 new source hash mismatch: {key}")
            blob = git("show", f"{T32_SOURCE_COMMIT}:{relative}")
            if content.replace(b"\r\n", b"\n") != blob.replace(b"\r\n", b"\n"):
                errors.append(f"T32 new source Git content mismatch: {key}")
        patch = source.get("source_patch", {})
        path = Path(str(patch.get("path", ""))) if isinstance(patch, dict) else Path()
        if (
            not isinstance(patch, dict)
            or patch.get("sha256") != T32_HISTORICAL_HASHES["source_patch"]
            or not path.is_file()
            or sha256(path) != T32_HISTORICAL_HASHES["source_patch"]
        ):
            errors.append("T32 new source patch hash mismatch")
    except (OSError, subprocess.SubprocessError, UnicodeError):
        errors.append("T32 new source Git checkout cannot be verified")
    return errors


def validate(run_dir: Path) -> list[str]:
    errors: list[str] = []
    path = run_dir / "t32_semantic_regression.json"
    try:
        record: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return [f"cannot read T32 evidence: {error}"]
    if (
        record.get("task"),
        record.get("run_id"),
        record.get("status"),
        record.get("classification"),
    ) != (
        "T32",
        run_dir.name,
        "PASS",
        "isolated_semantic_regression_not_performance_evidence",
    ):
        errors.append("T32 identity/status/classification mismatch")

    contract = record.get("semantic_contract", {})
    if (
        contract.get("comparison"),
        contract.get("equality_action"),
        contract.get("minimum_retained_rank"),
        contract.get("terminal_tail_action"),
    ) != ("strictly_less_than", "retain", 1, "apply_accumulated_reduction"):
        errors.append("T32 strict boundary contract mismatch")

    results = record.get("patched_aer_results", [])
    observed = {
        str(item.get("case")): int(item.get("retained_rank", -1))
        for item in results
        if isinstance(item, dict)
    }
    if observed != EXPECTED_CASES:
        errors.append("T32 patched rank boundary mismatch")
    for item in results:
        if not isinstance(item, dict):
            errors.append("malformed T32 result")
            continue
        if (
            item.get("status") != "PASS"
            or float(item.get("norm_error", 1)) > 1.0e-12
            or float(item.get("state_fidelity", 0))
            < 1.0 - float(item.get("tail_weight", 1)) - 1.0e-12
        ):
            errors.append(f"T32 numerical gate failed: {item.get('case')}")

    errors.extend(validate_source(
        record.get("source"), historical=run_dir.name == T32_HISTORICAL_RUN
    ))

    unit = record.get("unit_regression", {})
    if unit.get("returncode") != 0 or "OK" not in str(unit.get("stderr", "")):
        errors.append("T32 source regression did not pass")

    reference = record.get("immutable_t29_reference", {})
    baseline = run_dir.parent / str(reference.get("run_id", ""))
    baseline_executor = baseline / "t29_executor.json"
    if (
        not baseline_executor.is_file()
        or reference.get("executor_sha256") != sha256(baseline_executor)
    ):
        errors.append("T32 immutable T29 reference mismatch")
    comparison = {
        str(item.get("case")): (
            int(item.get("pre_fix_aer_rank", -1)),
            int(item.get("native_cutensornet_rank", -1)),
            int(item.get("patched_aer_rank", -1)),
            bool(item.get("patched_matches_native")),
        )
        for item in reference.get("normalized_comparison", [])
        if isinstance(item, dict)
    }
    expected_comparison = {
        "tail_below_cutoff": (2, 1, 1, True),
        "tail_equal_cutoff": (2, 1, 2, False),
        "tail_above_cutoff": (2, 2, 2, True),
    }
    if comparison != expected_comparison:
        errors.append("T32 old/native/patched comparison mismatch")

    decision = record.get("decision", {})
    if (
        decision.get("terminal_tail_defect_confirmed"),
        decision.get("terminal_tail_defect_fixed"),
        decision.get("strict_equality_is_documented_contract"),
        decision.get("remaining_native_difference"),
        decision.get("native_timing_unblocked"),
        decision.get("t29_rewritten"),
    ) != (True, True, True, "equality_only", False, False):
        errors.append("T32 decision boundary mismatch")
    if (
        record.get("correctness_claim_permitted"),
        record.get("performance_claim_permitted"),
    ) != (True, False):
        errors.append("T32 claim-permission mismatch")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    errors = validate(args.run_dir.resolve())
    if errors:
        print("BLOCKED T32 evidence")
        for error in errors:
            print(f"- {error}")
        return 1
    print(
        f"PASS: T32 evidence {args.run_dir.name} proves strict equality and "
        "the terminal-tail fix; it does not authorize performance claims."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
