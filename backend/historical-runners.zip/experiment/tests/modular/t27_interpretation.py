#!/usr/bin/env python3
"""Publication-facing interpretation of T27 within-campaign block intervals."""

from __future__ import annotations

import math
from typing import Any


PUBLICATION_INTERPRETATIONS = {
    "ROBUST_GPU_FASTER",
    "ROBUST_CPU_FASTER",
    "INCONCLUSIVE",
}


def publication_interpretation(repetitions: list[dict[str, Any]]) -> str:
    """Classify a circuit without collapsing CPU-faster and uncertain results.

    A directional advantage is publication-eligible only when all four
    block-specific 95% intervals lie strictly on the same side of parity.
    Anything else is inconclusive, including consistently directed point
    estimates whose intervals overlap one.
    """
    if not repetitions:
        raise ValueError("publication interpretation requires repetitions")
    intervals: list[tuple[float, float]] = []
    for repetition in repetitions:
        bootstrap = repetition.get("bootstrap")
        interval = bootstrap.get("interval") if isinstance(bootstrap, dict) else None
        if not isinstance(interval, list) or len(interval) != 2:
            raise ValueError("repetition lacks a two-sided bootstrap interval")
        low, high = float(interval[0]), float(interval[1])
        if not math.isfinite(low) or not math.isfinite(high) or low > high:
            raise ValueError("repetition has an invalid bootstrap interval")
        intervals.append((low, high))
    if all(high < 1.0 for _, high in intervals):
        return "ROBUST_GPU_FASTER"
    if all(low > 1.0 for low, _ in intervals):
        return "ROBUST_CPU_FASTER"
    return "INCONCLUSIVE"
