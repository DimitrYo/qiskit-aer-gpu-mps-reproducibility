#!/usr/bin/env python3
"""Extract machine-readable CUDA/cuTensorNet build evidence from a CMake cache."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path


def cache_value(cache: str, name: str) -> str | None:
    prefix = f"{name}:"
    for line in cache.splitlines():
        if line.startswith(prefix) and "=" in line:
            return line.split("=", 1)[1]
    return None


def truthy(value: str | None) -> bool:
    return value is not None and value.upper() in {"1", "ON", "TRUE", "YES", "CUDA"}


def configured_cuda_compiler(value: str | None) -> bool:
    """Return whether CMake configured a usable CUDA compiler.

    ``AER_THRUST_BACKEND`` is deliberately a normal CMake variable in the Aer
    project: it is populated from the build environment and is therefore not
    necessarily written to ``CMakeCache.txt``.  A configured CUDA compiler is
    the durable cache-side consequence of the CUDA backend branch.
    """
    return value is not None and bool(value.strip()) and not value.upper().endswith("-NOTFOUND")


def controller_links_cutensornet(cache: str) -> bool:
    """Return whether the compiled controller target links cuTensorNet.

    The custom Python-root build path embeds the cuTensorNet library in
    ``controller_wrappers_LIB_DEPENDS`` rather than exposing an
    ``AER_ENABLE_CUTENSORNET`` cache option.  Limit the check to the controller
    target so a stray string elsewhere in the cache cannot qualify the build.
    """
    dependencies = cache_value(cache, "controller_wrappers_LIB_DEPENDS")
    return dependencies is not None and "libcutensornet" in dependencies


def git_metadata(source_dir: Path) -> dict[str, str | bool | None]:
    def run(*arguments: str) -> str | None:
        result = subprocess.run(["git", "-C", str(source_dir), *arguments], text=True, capture_output=True)
        return result.stdout.strip() if result.returncode == 0 else None

    status = run("status", "--porcelain")
    return {
        "commit": run("rev-parse", "HEAD"),
        "tree": run("rev-parse", "HEAD^{tree}"),
        "dirty": bool(status) if status is not None else None,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--cmake-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-dir", type=Path, required=True)
    args = parser.parse_args()

    if not args.cmake_cache.is_file():
        print(f"Missing CMake cache: {args.cmake_cache}")
        return 2
    cache = args.cmake_cache.read_text(encoding="utf-8", errors="replace")
    thrust_backend = cache_value(cache, "AER_THRUST_BACKEND")
    cutensornet = cache_value(cache, "AER_ENABLE_CUTENSORNET")
    cuda_compiler = cache_value(cache, "CMAKE_CUDA_COMPILER")
    has_cuda = configured_cuda_compiler(cuda_compiler)
    has_cutensornet_link = controller_links_cutensornet(cache)
    manifest = {
        "run_id": args.run_id,
        "custom_environment": os.environ.get("ARTICLE2_CUSTOM_ENV_NAME", ".venv_custom_gpu"),
        "cmake_cache": str(args.cmake_cache.resolve()),
        "cmake_cache_sha256": hashlib.sha256(cache.encode("utf-8")).hexdigest(),
        "source": {"path": str(args.source_dir.resolve()), **git_metadata(args.source_dir)},
        "aer_thrust_backend": thrust_backend,
        "aer_enable_cutensornet": cutensornet,
        "cmake_cuda_compiler": cuda_compiler,
        "cutensornet_linked_by_controller": has_cutensornet_link,
        "cmake_cuda_enabled": truthy(thrust_backend) or has_cuda,
        "cutensornet_enabled": truthy(cutensornet) or (has_cuda and has_cutensornet_link),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
