#!/usr/bin/env python3
"""Collect one immutable T21 approximate-MPS chi=128 timing bundle.

T21 is deliberately separate from the exact L5/T17 evidence. It requires the
validated T18 chi=128 accuracy result, regenerates same-run accuracy controls
at the preregistered approximate threshold, collects uninstrumented 5/20 timing,
and keeps the instrumented GPU diagnostic in a separate process.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from run_e3_timing_executor import DEFAULT_RUNS_ROOT, EXPERIMENTS_DIR, environment_python


HERE = Path(__file__).resolve().parent
DEFAULT_MANIFEST = EXPERIMENTS_DIR / "manifests" / "t21_approx_brickwork_14_d14_chi128.json"
TIMING = HERE / "run_crossover_timing_executor.py"
DIAGNOSTIC = HERE / "run_crossover_gpu_diagnostic.py"
COLLECT_ENVIRONMENT = HERE / "collect_environment_manifest.py"
COLLECT_BUILD = HERE / "collect_build_manifest.py"
E2 = HERE / "run_e2_numerical_correctness_pilot.py"
VALIDATE_E2 = HERE / "validate_e2_correctness.py"
ASSEMBLE = HERE / "assemble_crossover_evidence.py"
VALIDATE_CROSSOVER = HERE / "validate_crossover_evidence.py"
VALIDATE_T18 = HERE / "validate_t18_approximate_evidence.py"
VALIDATE_T21 = HERE / "validate_t21_approximate_timing.py"
CHI = 128
FIDELITY_MIN = 0.999999
TRUNCATION_THRESHOLD = 0.0


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path.name} must contain a JSON object")
    return value


def invoke(command: list[str], label: str) -> None:
    print(f"[T21] {label}", flush=True)
    if subprocess.run(command, text=True).returncode:
        raise RuntimeError(f"{label} failed")


def accuracy_link(source_dir: Path) -> dict[str, Any]:
    collection_path = source_dir / "t18_collection.json"
    collection = load_json(collection_path)
    cap_record = next(
        (
            item for item in collection.get("cap_runs", [])
            if isinstance(item, dict) and item.get("cap") == CHI
        ),
        None,
    )
    if not isinstance(cap_record, dict) or cap_record.get("directory") != "chi_128":
        raise RuntimeError("validated T18 source does not contain the registered chi=128 result")
    cap_dir = source_dir / "chi_128"
    reports: dict[str, dict[str, Any]] = {}
    for backend in ("custom_cpu", "custom_gpu", "upstream_cpu"):
        path = cap_dir / f"e2_{backend}.json"
        report = load_json(path)
        if report.get("status") != "PASS":
            raise RuntimeError(f"T18 chi=128 {backend} accuracy did not pass")
        simulation = report.get("simulation_config")
        if not isinstance(simulation, dict) or (
            simulation.get("max_bond_dimension"),
            simulation.get("truncation_threshold"),
        ) != (CHI, TRUNCATION_THRESHOLD):
            raise RuntimeError(f"T18 chi=128 {backend} configuration differs from T21")
        records = report.get("records")
        if not isinstance(records, list) or not records:
            raise RuntimeError(f"T18 chi=128 {backend} has no correctness records")
        reports[backend] = {
            "relative_path": path.relative_to(source_dir).as_posix(),
            "sha256": sha256(path),
            "minimum_fidelity": min(float(item["mps"]["fidelity"]) for item in records),
            "maximum_norm_error": max(float(item["mps"]["norm_error"]) for item in records),
        }
    gpu_report = load_json(cap_dir / "e2_custom_gpu.json")
    if gpu_report.get("offload_observation") != "OBSERVED":
        raise RuntimeError("T18 chi=128 lacks observed custom-GPU offload")
    return {
        "schema_version": 1,
        "source_task": "T18",
        "source_run_id": source_dir.name,
        "source_collection_relative_path": "t18_collection.json",
        "source_collection_sha256": sha256(collection_path),
        "selected_cap": CHI,
        "truncation_threshold": TRUNCATION_THRESHOLD,
        "acceptance": {
            "mps_fidelity_min": FIDELITY_MIN,
            "norm_error_max": 1.0e-10,
        },
        "reports": reports,
        "custom_gpu_offload_observation": "OBSERVED",
    }


def write_summary(run_dir: Path) -> None:
    aggregate = load_json(run_dir / "crossover_aggregate.json")
    comparisons = aggregate.get("end_to_end_comparisons")
    if not isinstance(comparisons, list) or len(comparisons) != 1:
        raise RuntimeError("T21 aggregate must contain exactly one comparison")
    comparison = comparisons[0]
    if not isinstance(comparison, dict):
        raise RuntimeError("T21 comparison must be an object")
    ratio = float(comparison["point_estimate"])
    low, high = (float(value) for value in comparison["bootstrap"]["interval"])
    summary = {
        "schema_version": 1,
        "run_id": run_dir.name,
        "task": "T21",
        "classification": "approximate_mps_timing",
        "scope": {
            "circuit_id": comparison["circuit_id"],
            "max_bond_dimension": CHI,
            "truncation_threshold": TRUNCATION_THRESHOLD,
            "accuracy_source": "t21_accuracy_link.json",
        },
        "gpu_cpu_median_ratio": ratio,
        "gpu_cpu_ratio_95_percent_interval": [low, high],
        "cpu_gpu_speedup": 1.0 / ratio,
        "cpu_gpu_speedup_95_percent_interval": [1.0 / high, 1.0 / low],
        "advantage_status": comparison["advantage_status"],
        "limitations": [
            "One frozen 14-qubit depth-14 brickwork circuit only.",
            "Approximate chi=128 result; not exact-L5/T17 evidence.",
            "No fitted scaling law, general speedup, or optimal-cap claim.",
        ],
    }
    output = run_dir / "t21_summary.json"
    if output.exists():
        raise RuntimeError("refusing to overwrite t21_summary.json")
    output.write_text(json.dumps(summary, indent=2), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--t18-run-dir", type=Path, required=True)
    parser.add_argument("--cmake-cache", type=Path, required=True)
    parser.add_argument("--dispatch-threshold", type=int, default=8401)
    parser.add_argument("--cell-wall-time-seconds", type=float, default=900.0)
    parser.add_argument("--seed-simulator", type=int, default=20260722)
    parser.add_argument("--seed-transpiler", type=int, default=20260722)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument("--custom-environment", default=".venv_custom_gpu_isolated_20260722")
    parser.add_argument("--upstream-environment", default=".venv_cpu")
    parser.add_argument(
        "--source-dir",
        type=Path,
        default=EXPERIMENTS_DIR.parent / "custom-build-worktrees" / "_isolated_20260722",
    )
    args = parser.parse_args()
    run_dir = (args.runs_root / args.run_id).resolve()
    try:
        if run_dir.exists():
            raise RuntimeError(f"refusing to reuse existing run directory: {run_dir}")
        if not args.run_id.replace("-", "").replace("_", "").replace(".", "").isalnum():
            raise RuntimeError("run_id contains unsupported characters")
        custom_python = environment_python(args.custom_environment)
        upstream_python = environment_python(args.upstream_environment)
        source_dir = args.source_dir.resolve()
        os.environ["ARTICLE2_CUSTOM_ENV_NAME"] = args.custom_environment
        os.environ["ARTICLE2_CUSTOM_SOURCE_DIR"] = str(source_dir)
        invoke(
            [str(custom_python), str(VALIDATE_T18), "--run-dir", str(args.t18_run_dir.resolve())],
            "validate prerequisite T18 accuracy",
        )
        link = accuracy_link(args.t18_run_dir.resolve())
        invoke(
            [
                str(custom_python), str(TIMING), "--run-id", args.run_id,
                "--manifest", str(args.manifest.resolve()), "--runs-root", str(args.runs_root.resolve()),
                "--custom-environment", args.custom_environment,
                "--max-bond-dimension", str(CHI),
                "--truncation-threshold", str(TRUNCATION_THRESHOLD),
                "--dispatch-threshold", str(args.dispatch_threshold),
                "--cell-wall-time-seconds", str(args.cell_wall_time_seconds),
                "--seed-simulator", str(args.seed_simulator),
                "--seed-transpiler", str(args.seed_transpiler),
            ],
            "raw uninstrumented 5/20 timing",
        )
        (run_dir / "t21_accuracy_link.json").write_text(
            json.dumps(link, indent=2), encoding="utf-8"
        )
        invoke(
            [
                str(custom_python), str(DIAGNOSTIC), "--run-id", args.run_id,
                "--manifest", str(args.manifest.resolve()), "--runs-root", str(args.runs_root.resolve()),
                "--custom-environment", args.custom_environment,
                "--max-bond-dimension", str(CHI),
                "--truncation-threshold", str(TRUNCATION_THRESHOLD),
                "--dispatch-threshold", str(args.dispatch_threshold),
                "--seed-simulator", str(args.seed_simulator),
                "--seed-transpiler", str(args.seed_transpiler),
            ],
            "separate GPU offload/profile diagnostic",
        )
        invoke(
            [
                str(custom_python), str(COLLECT_ENVIRONMENT), "--run-id", args.run_id,
                "--backend", "custom_gpu", "--output", str(run_dir / "environment_manifest.json"),
            ],
            "environment provenance",
        )
        invoke(
            [
                str(custom_python), str(COLLECT_BUILD), "--run-id", args.run_id,
                "--cmake-cache", str(args.cmake_cache.resolve()), "--source-dir", str(source_dir),
                "--output", str(run_dir / "build_manifest.json"),
            ],
            "build provenance",
        )
        for backend, python_bin, output in (
            ("custom_cpu", custom_python, "e2_custom_cpu.json"),
            ("custom_gpu", custom_python, "e2_custom_gpu.json"),
            ("upstream_cpu", upstream_python, "e2_upstream_cpu.json"),
        ):
            command = [
                str(python_bin), str(E2), "--manifest", str(args.manifest.resolve()),
                "--backend", backend, "--run-id", args.run_id,
                "--output", str(run_dir / output),
                "--max-bond-dimension", str(CHI),
                "--truncation-threshold", str(TRUNCATION_THRESHOLD),
                "--mps-fidelity-min", str(FIDELITY_MIN),
                "--seed-transpiler", str(args.seed_transpiler),
            ]
            if backend == "custom_gpu":
                command += ["--events-path", str(run_dir / "e2_custom_gpu.events.jsonl")]
            invoke(command, f"same-run approximate E2 {backend}")
        invoke(
            [str(custom_python), str(VALIDATE_E2), "--run-dir", str(run_dir)],
            "same-run E2 validation",
        )
        invoke(
            [str(custom_python), str(ASSEMBLE), "--run-dir", str(run_dir)],
            "timing assembly",
        )
        invoke(
            [str(custom_python), str(VALIDATE_CROSSOVER), "--run-dir", str(run_dir)],
            "generic crossover validation",
        )
        write_summary(run_dir)
        invoke(
            [str(custom_python), str(VALIDATE_T21), "--run-dir", str(run_dir)],
            "T21 approximate-timing validation",
        )
        print(f"PASS: complete T21 approximate timing bundle {args.run_id}")
        return 0
    except (OSError, KeyError, TypeError, ValueError, RuntimeError, json.JSONDecodeError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
