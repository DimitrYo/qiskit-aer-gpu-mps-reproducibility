#!/usr/bin/env python3
"""Validate T21 approximate chi=128 timing without relabelling it exact."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from run_e2_numerical_correctness_pilot import load_manifest
from validate_crossover_evidence import validate_run_directory
from validate_t18_approximate_evidence import validate as validate_t18


HERE = Path(__file__).resolve().parent
EXPERIMENTS = HERE.parents[1]
DEFAULT_MANIFEST = EXPERIMENTS / "manifests" / "t21_approx_brickwork_14_d14_chi128.json"
MANIFEST_SHA256 = "88a83aa3433eabe0d883cde9223c1c9003aa3090d828ea9280c589436a484c08"
CHI = 128
FIDELITY_MIN = 0.999999


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_object(path: Path, errors: list[str]) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        errors.append(f"cannot read {path.name}: {error}")
        return None
    if not isinstance(value, dict):
        errors.append(f"{path.name}: root must be an object")
        return None
    return value


def validate(run_dir: Path, *, manifest_path: Path = DEFAULT_MANIFEST) -> list[str]:
    run_dir = run_dir.resolve()
    errors: list[str] = []
    status, generic_errors = validate_run_directory(run_dir)
    if status:
        errors.extend(f"generic crossover: {item}" for item in generic_errors)
    manifest = load_manifest(manifest_path)
    if (
        manifest.get("purpose")
        != "T21 approximate-MPS chi=128 timing study; requires the validated T18 accuracy gate."
        or manifest.get("manifest_sha256") != MANIFEST_SHA256
    ):
        errors.append("T21 manifest purpose or frozen hash mismatch")
    executor = load_object(run_dir / "crossover_executor.json", errors)
    if executor is not None:
        if executor.get("manifest_sha256") != MANIFEST_SHA256:
            errors.append("timing executor does not use the frozen T21 manifest")
        if (
            executor.get("max_bond_dimension"),
            executor.get("truncation_threshold"),
        ) != (CHI, 0.0):
            errors.append("timing executor is not the registered chi=128 cap-only configuration")
        if executor.get("timing_instrumentation") != "none":
            errors.append("T21 timing must remain uninstrumented")
        if executor.get("protocol") != {
            "warmups": 5,
            "timed_repetitions": 20,
            "shots": 100,
        }:
            errors.append("T21 timing protocol must be exactly 5/20/100")
    link = load_object(run_dir / "t21_accuracy_link.json", errors)
    if link is not None:
        if (
            link.get("source_task"),
            link.get("selected_cap"),
            link.get("truncation_threshold"),
            link.get("custom_gpu_offload_observation"),
        ) != ("T18", CHI, 0.0, "OBSERVED"):
            errors.append("T21 accuracy link does not select the validated T18 chi=128 result")
        acceptance = link.get("acceptance")
        if not isinstance(acceptance, dict) or (
            acceptance.get("mps_fidelity_min"),
            acceptance.get("norm_error_max"),
        ) != (FIDELITY_MIN, 1.0e-10):
            errors.append("T21 accuracy link has incorrect acceptance thresholds")
        source_run_id = link.get("source_run_id")
        if not isinstance(source_run_id, str):
            errors.append("T21 accuracy link lacks a source run ID")
        else:
            source_dir = run_dir.parent / source_run_id
            t18_errors = validate_t18(source_dir)
            errors.extend(f"linked T18: {item}" for item in t18_errors)
            collection = source_dir / "t18_collection.json"
            if not collection.is_file() or link.get("source_collection_sha256") != sha256(collection):
                errors.append("linked T18 collection hash mismatch")
            reports = link.get("reports")
            if not isinstance(reports, dict):
                errors.append("T21 accuracy link lacks source reports")
            else:
                for backend in ("custom_cpu", "custom_gpu", "upstream_cpu"):
                    item = reports.get(backend)
                    if not isinstance(item, dict):
                        errors.append(f"T21 accuracy link lacks {backend}")
                        continue
                    path = source_dir / str(item.get("relative_path", ""))
                    if not path.is_file() or item.get("sha256") != sha256(path):
                        errors.append(f"T21 linked {backend} report hash mismatch")
    for backend in ("custom_cpu", "custom_gpu", "upstream_cpu"):
        report = load_object(run_dir / f"e2_{backend}.json", errors)
        if report is None:
            continue
        config = report.get("simulation_config")
        if not isinstance(config, dict) or (
            config.get("max_bond_dimension"),
            config.get("truncation_threshold"),
        ) != (CHI, 0.0):
            errors.append(f"{backend}: same-run E2 configuration mismatch")
            continue
        records = report.get("records")
        if not isinstance(records, list) or not records:
            errors.append(f"{backend}: same-run E2 lacks records")
            continue
        for record in records:
            if not isinstance(record, dict) or record.get("status") != "PASS":
                errors.append(f"{backend}: same-run approximate accuracy did not pass")
                continue
            mps = record.get("mps")
            if not isinstance(mps, dict) or mps.get("fidelity_min") != FIDELITY_MIN:
                errors.append(f"{backend}: same-run E2 did not use the T21 accuracy threshold")
    summary = load_object(run_dir / "t21_summary.json", errors)
    if summary is not None:
        if (
            summary.get("run_id"),
            summary.get("task"),
            summary.get("classification"),
        ) != (run_dir.name, "T21", "approximate_mps_timing"):
            errors.append("T21 summary identity or classification mismatch")
        ratio = summary.get("gpu_cpu_median_ratio")
        speedup = summary.get("cpu_gpu_speedup")
        if not isinstance(ratio, (int, float)) or not isinstance(speedup, (int, float)):
            errors.append("T21 summary lacks reciprocal timing metrics")
        elif abs(float(speedup) - 1.0 / float(ratio)) > 1.0e-12:
            errors.append("T21 summary speedup is not the reciprocal of its ratio")
        limitations = summary.get("limitations")
        if not isinstance(limitations, list) or not any(
            "not exact-L5/T17 evidence" in str(item) for item in limitations
        ):
            errors.append("T21 summary lacks the exact-evidence separation warning")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    args = parser.parse_args()
    try:
        errors = validate(args.run_dir, manifest_path=args.manifest)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        errors = [str(error)]
    if errors:
        print("BLOCKED T21 approximate timing")
        for error in errors:
            print(f"- {error}")
        return 1
    print(
        f"PASS: T21 approximate timing bundle {args.run_dir.name} is valid "
        "for its frozen chi=128 workload only."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
