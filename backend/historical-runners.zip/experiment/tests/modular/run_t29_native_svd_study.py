#!/usr/bin/env python3
"""Run the correctness-gated T29 native cutoff and SVD algorithm study."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import statistics
import subprocess
import sys
from pathlib import Path
from typing import Any

from run_e2_numerical_correctness_pilot import load_manifest
from run_e3_timing_executor import (
    CELL_DRIVER,
    DEFAULT_RUNS_ROOT,
    TESTS_DIR,
    environment_python,
)


E2_DRIVER = TESTS_DIR / "run_e2_numerical_correctness_pilot.py"
SEMANTIC_CASES = (
    ("below", 0.00005),
    ("equal", 0.0001),
    ("above", 0.0002),
)
CONFIGURATIONS = (
    {
        "id": "gesvd_exact",
        "algorithm": "GESVD",
        "native": False,
        "cutoff": 0.0,
        "max_bond_dimension": 1024,
        "fidelity_min": 1.0 - 1.0e-10,
    },
    {
        "id": "gesvdj_exact",
        "algorithm": "GESVDJ",
        "native": False,
        "cutoff": 0.0,
        "max_bond_dimension": 1024,
        "fidelity_min": 1.0 - 1.0e-10,
    },
    {
        "id": "gesvd_aer_cutoff",
        "algorithm": "GESVD",
        "native": False,
        "cutoff": 1.0e-8,
        "max_bond_dimension": 1024,
        "fidelity_min": 0.999999,
    },
    {
        "id": "gesvd_native_cutoff",
        "algorithm": "GESVD",
        "native": True,
        "cutoff": 1.0e-8,
        "max_bond_dimension": 1024,
        "fidelity_min": 0.999999,
    },
    {
        "id": "gesvdj_native_cutoff",
        "algorithm": "GESVDJ",
        "native": True,
        "cutoff": 1.0e-8,
        "max_bond_dimension": 1024,
        "fidelity_min": 0.999999,
    },
    {
        "id": "gesvdr_rank128",
        "algorithm": "GESVDR",
        "native": True,
        "cutoff": 0.0,
        "max_bond_dimension": 128,
        "fidelity_min": 0.99,
    },
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path} must contain a JSON object")
    return value


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def configuration_environment(
    algorithm: str,
    native: bool,
    native_log: Path | None,
    *,
    dispatch_threshold: int = 8401,
) -> dict[str, str]:
    environment = os.environ.copy()
    environment["AER_CUTENSOR_SVD_ALGORITHM"] = algorithm
    environment["AER_CUTENSOR_NATIVE_DISCARDED_WEIGHT"] = "1" if native else "0"
    environment["AER_CUTENSOR_SVD_MIN_ELEMENTS"] = str(dispatch_threshold)
    if native_log is None:
        environment.pop("AER_CUTENSOR_SVD_NATIVE_PATH", None)
    else:
        environment["AER_CUTENSOR_SVD_NATIVE_PATH"] = str(native_log.resolve())
    for name in (
        "AER_CUTENSOR_SVD_PROFILE_PATH",
        "AER_CUTENSOR_SVD_DECISIONS_PATH",
    ):
        environment.pop(name, None)
    return environment


def run_correctness(
    *,
    python_bin: Path,
    manifest: Path,
    run_id: str,
    destination: Path,
    algorithm: str,
    native: bool,
    cutoff: float,
    max_bond_dimension: int,
    fidelity_min: float,
    dispatch_threshold: int,
) -> tuple[dict[str, Any], list[dict[str, Any]], int]:
    destination.parent.mkdir(parents=True, exist_ok=True)
    events = destination.with_suffix(".events.jsonl")
    native_log = destination.with_suffix(".native.jsonl")
    command = [
        str(python_bin),
        str(E2_DRIVER),
        "--manifest",
        str(manifest.resolve()),
        "--backend",
        "custom_gpu",
        "--run-id",
        run_id,
        "--output",
        str(destination),
        "--events-path",
        str(events),
        "--max-bond-dimension",
        str(max_bond_dimension),
        "--truncation-threshold",
        str(cutoff),
        "--mps-fidelity-min",
        str(fidelity_min),
        "--seed-transpiler",
        "20260725",
    ]
    print(
        f"[T29 correctness] {destination.stem}: {algorithm}, "
        f"native={native}, cutoff={cutoff}, chi={max_bond_dimension}",
        flush=True,
    )
    result = subprocess.run(
        command,
        env=configuration_environment(
            algorithm,
            native,
            native_log,
            dispatch_threshold=dispatch_threshold,
        ),
        text=True,
    )
    report = (
        read_json(destination)
        if destination.is_file()
        else {
            "status": "FAIL",
            "records": [],
            "failure": "correctness process returned without a report",
        }
    )
    native_records = read_jsonl(native_log) if native_log.is_file() else []
    return report, native_records, result.returncode


def inferred_rank(fidelity: float, tail_weight: float) -> int:
    midpoint = 1.0 - tail_weight / 2.0
    return 2 if fidelity >= midpoint else 1


def run_timing(
    *,
    python_bin: Path,
    manifest: Path,
    run_id: str,
    destination: Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    destination.mkdir(parents=True, exist_ok=True)
    command = [
        str(python_bin),
        str(CELL_DRIVER),
        "--manifest",
        str(manifest.resolve()),
        "--backend",
        "custom_gpu",
        "--run-id",
        run_id,
        "--warmups-output",
        str(destination / "warmups.jsonl"),
        "--timings-output",
        str(destination / "timings.jsonl"),
        "--report-output",
        str(destination / "report.json"),
        "--warmups",
        "5",
        "--timed-repetitions",
        "20",
        "--shots",
        "100",
        "--max-bond-dimension",
        str(config["max_bond_dimension"]),
        "--truncation-threshold",
        str(config["cutoff"]),
        "--seed-simulator",
        "20260725",
        "--seed-transpiler",
        "20260725",
        "--dispatch-threshold",
        "8401",
        "--allow-uninstrumented-gpu-timing",
        "--cell-wall-time-seconds",
        "3600",
    ]
    print(f"[T29 timing] {config['id']}: 5/20 uninstrumented", flush=True)
    result = subprocess.run(
        command,
        env=configuration_environment(
            str(config["algorithm"]),
            bool(config["native"]),
            None,
        ),
        text=True,
    )
    if result.returncode:
        raise RuntimeError(f"T29 timing failed: {config['id']}")
    records = read_jsonl(destination / "timings.jsonl")
    samples = [float(record["elapsed_seconds"]) for record in records]
    if len(samples) != 20:
        raise RuntimeError(f"T29 timing sample-count mismatch: {config['id']}")
    return {
        "status": "PASS",
        "destination": str(destination),
        "sample_count": len(samples),
        "median_seconds": statistics.median(samples),
        "minimum_seconds": min(samples),
        "maximum_seconds": max(samples),
    }


def run_forbidden_combination_probe(
    *,
    python_bin: Path,
    manifest: Path,
    run_id: str,
    destination: Path,
) -> dict[str, Any]:
    events = destination.with_suffix(".events.jsonl")
    command = [
        str(python_bin),
        str(E2_DRIVER),
        "--manifest",
        str(manifest.resolve()),
        "--backend",
        "custom_gpu",
        "--run-id",
        run_id,
        "--output",
        str(destination),
        "--events-path",
        str(events),
        "--max-bond-dimension",
        "128",
        "--truncation-threshold",
        "1e-8",
        "--mps-fidelity-min",
        "0.99",
    ]
    result = subprocess.run(
        command,
        env=configuration_environment("GESVDR", True, None),
        capture_output=True,
        text=True,
    )
    if result.returncode == 0 or destination.exists():
        raise RuntimeError("forbidden GESVDR/cutoff combination was not rejected")
    record = {
        "status": "PASS",
        "expected_outcome": "REJECTED",
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "forbidden_combination": {
            "algorithm": "GESVDR",
            "native": True,
            "cutoff": 1.0e-8,
            "max_bond_dimension": 128,
        },
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.with_name("gesvdr_cutoff_rejection.json").write_text(
        json.dumps(record, indent=2) + "\n",
        encoding="utf-8",
    )
    return record


def git(source: Path, *arguments: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(source), *arguments],
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--semantic-manifest", type=Path, required=True)
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT)
    parser.add_argument(
        "--custom-environment",
        default=".venv_custom_gpu_t29_20260725",
    )
    args = parser.parse_args()
    run_dir = (args.runs_root / args.run_id).resolve()
    try:
        if run_dir.exists():
            raise RuntimeError(f"refusing to reuse immutable run ID: {run_dir}")
        manifest = load_manifest(args.manifest)
        semantic_manifest = load_manifest(args.semantic_manifest)
        source = args.source_dir.resolve()
        if git(source, "status", "--porcelain"):
            raise RuntimeError("T29 evaluated source must be clean")
        python_bin = environment_python(args.custom_environment)
        run_dir.mkdir(parents=True)

        forbidden_probe = run_forbidden_combination_probe(
            python_bin=python_bin,
            manifest=args.manifest,
            run_id=args.run_id,
            destination=run_dir / "negative_control" / "forbidden_output.json",
        )

        semantic_results: list[dict[str, Any]] = []
        tail_weight = float(semantic_manifest["circuits"][0]["tail_weight"])
        for label, cutoff in SEMANTIC_CASES:
            per_mode: dict[str, dict[str, Any]] = {}
            for mode, native in (("aer_side", False), ("native", True)):
                destination = run_dir / "semantic" / label / f"{mode}.json"
                report, native_records, returncode = run_correctness(
                    python_bin=python_bin,
                    manifest=args.semantic_manifest,
                    run_id=args.run_id,
                    destination=destination,
                    algorithm="GESVD",
                    native=native,
                    cutoff=cutoff,
                    max_bond_dimension=1024,
                    fidelity_min=0.999,
                    dispatch_threshold=1,
                )
                if returncode or report.get("status") != "PASS":
                    raise RuntimeError(f"T29 semantic correctness failed: {label} {mode}")
                fidelity = float(report["records"][0]["mps"]["fidelity"])
                if not native_records:
                    raise RuntimeError(f"T29 semantic native log is empty: {label} {mode}")
                observed = native_records[-1]
                rank = (
                    int(observed["reduced_extent"])
                    if native
                    else inferred_rank(fidelity, tail_weight)
                )
                per_mode[mode] = {
                    "retained_rank": rank,
                    "fidelity": fidelity,
                    "native_record": observed,
                }
            matches = (
                per_mode["aer_side"]["retained_rank"]
                == per_mode["native"]["retained_rank"]
            )
            semantic_results.append(
                {
                    "case": label,
                    "cutoff": cutoff,
                    "tail_weight": tail_weight,
                    "aer_side": per_mode["aer_side"],
                    "native": per_mode["native"],
                    "retained_rank_matches": matches,
                }
            )
        semantic_status = (
            "PASS"
            if all(item["retained_rank_matches"] for item in semantic_results)
            else "SEMANTIC_MISMATCH"
        )

        configuration_results: list[dict[str, Any]] = []
        for config_value in CONFIGURATIONS:
            config = dict(config_value)
            destination = run_dir / "correctness" / f"{config['id']}.json"
            report, native_records, returncode = run_correctness(
                python_bin=python_bin,
                manifest=args.manifest,
                run_id=args.run_id,
                destination=destination,
                algorithm=str(config["algorithm"]),
                native=bool(config["native"]),
                cutoff=float(config["cutoff"]),
                max_bond_dimension=int(config["max_bond_dimension"]),
                fidelity_min=float(config["fidelity_min"]),
                dispatch_threshold=8401,
            )
            correctness_passed = returncode == 0 and report.get("status") == "PASS"
            mps_record = (
                report["records"][0]["mps"]
                if report.get("records")
                else {"fidelity": None, "norm_error": None}
            )
            requires_semantic_gate = "native_cutoff" in str(config["id"])
            eligible = correctness_passed and (
                not requires_semantic_gate or semantic_status == "PASS"
            )
            timing = (
                run_timing(
                    python_bin=python_bin,
                    manifest=args.manifest,
                    run_id=args.run_id,
                    destination=run_dir / "timing" / str(config["id"]),
                    config=config,
                )
                if eligible
                else {
                    "status": "BLOCKED",
                    "reason": (
                        "correctness gate failed"
                        if not correctness_passed
                        else "native cutoff semantic gate did not pass"
                    ),
                }
            )
            configuration_results.append(
                {
                    **config,
                    "correctness_status": report.get("status"),
                    "correctness_returncode": returncode,
                    "fidelity": mps_record["fidelity"],
                    "norm_error": mps_record["norm_error"],
                    "correctness_failure": report.get("failure"),
                    "native_event_count": len(native_records),
                    "native_reduced_extent_min": min(
                        int(item["reduced_extent"]) for item in native_records
                    ),
                    "native_reduced_extent_max": max(
                        int(item["reduced_extent"]) for item in native_records
                    ),
                    "timing": timing,
                }
            )

        source_files = {}
        for relative in (
            "src/simulators/matrix_product_state/svd.cpp",
            "src/simulators/matrix_product_state/svd.hpp",
            "src/simulators/matrix_product_state/matrix_product_state_tensor.hpp",
            "src/simulators/matrix_product_state/matrix_product_state_internal.cpp",
        ):
            path = source / relative
            source_files[relative] = sha256(path)
        executor = {
            "schema_version": 1,
            "task": "T29",
            "run_id": args.run_id,
            "status": "PASS",
            "semantic_gate_status": semantic_status,
            "semantic_results": semantic_results,
            "manifest_path": str(args.manifest.resolve()),
            "manifest_sha256": manifest["manifest_sha256"],
            "semantic_manifest_path": str(args.semantic_manifest.resolve()),
            "semantic_manifest_sha256": semantic_manifest["manifest_sha256"],
            "source": {
                "path": str(source),
                "git_commit": git(source, "rev-parse", "HEAD"),
                "git_status_porcelain": git(source, "status", "--porcelain"),
                "files": source_files,
            },
            "installed_api_restriction": (
                "GESVDR is never combined with a nonzero discarded-weight cutoff."
            ),
            "forbidden_combination_probe": forbidden_probe,
            "configurations": configuration_results,
        }
        (run_dir / "t29_executor.json").write_text(
            json.dumps(executor, indent=2) + "\n",
            encoding="utf-8",
        )
        print(
            f"PASS: T29 study completed with semantic gate {semantic_status}: "
            f"{run_dir}"
        )
        return 0
    except (
        OSError,
        KeyError,
        TypeError,
        ValueError,
        RuntimeError,
        subprocess.CalledProcessError,
    ) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
