#!/usr/bin/env python3
"""Independently validate T29 semantic, correctness, and timing gates."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import subprocess
from pathlib import Path
from typing import Any

from evidence_paths import resolve_frozen_manifest, resolve_run_local
from run_e2_numerical_correctness_pilot import load_manifest


EXPECTED_CONFIGURATIONS = {
    "gesvd_exact",
    "gesvdj_exact",
    "gesvd_aer_cutoff",
    "gesvd_native_cutoff",
    "gesvdj_native_cutoff",
    "gesvdr_rank128",
}
EXPERIMENTS = Path(__file__).resolve().parents[2]
MANIFESTS_DIR = EXPERIMENTS / "manifests"
SOURCE_PATCHES_DIR = EXPERIMENTS / "source_patches"
T29_SOURCE_COMMIT = "7d639c941c582af794bcf8ff65159a8c7c7b747f"
T29_SOURCE_TREE = "fad8486f95e0493c544a1edd2b4612c0342f17de"
T29_HISTORICAL_RUN = "20260725_t29_native_svd_03"
T29_SOURCE_FILES = {
    "src/simulators/matrix_product_state/svd.cpp": "079b348dc3b1d7eabdf22e5529658aee3d6d738bfc288fa16567400328bbee18",
    "src/simulators/matrix_product_state/svd.hpp": "73090c0c2eb6c197e222f76d342746edc14ea134dc843f66aaec2acde129db2d",
    "src/simulators/matrix_product_state/matrix_product_state_tensor.hpp": "d2111f9311472cc80a75e359368cdf7aea141b0bcd53c2dd6a745f744efeb2ed",
    "src/simulators/matrix_product_state/matrix_product_state_internal.cpp": "a57d4435640b714a59e81bcb3ae818ae06278078e4b1524c6826d6cddd1ad9fc",
}
T29_PATCHES = {
    "0001-Add-native-cuTensorNet-truncation-study-path.patch": "35560f4f073c818a173d1457c5948bc24902f5e72ec7ee5e62201df6d13f3b41",
    "0002-Handle-non-reducing-GESVDR-MPS-splits-adaptively.patch": "2a8136956515d0ac426644ef6b38f8ef1141ffb3bdf46203d4d672c056ab0d3c",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"{path} must contain a JSON object")
    return value


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def validate_new_checkout(source: dict[str, Any]) -> list[str]:
    """Bind a new run to the registered Git tree and its actual source bytes.

    Historical Windows worktrees contained mixed line endings. New runs may use
    LF or CRLF, but a changed byte hash must be supported by the real clean Git
    checkout, not by the historical patch fallback.
    """
    source_root = Path(str(source.get("path", ""))).resolve()
    files = source.get("files")
    if not isinstance(files, dict) or set(files) != set(T29_SOURCE_FILES):
        return ["T29 new source file coverage mismatch"]
    try:
        def git(*args: str) -> bytes:
            return subprocess.check_output(
                ["git", "-C", str(source_root), *args], stderr=subprocess.PIPE
            )

        if (
            Path(git("rev-parse", "--show-toplevel").decode().strip()).resolve() != source_root
            or git("rev-parse", "HEAD").decode().strip() != T29_SOURCE_COMMIT
            or git("rev-parse", "HEAD^{tree}").decode().strip() != T29_SOURCE_TREE
            or git("status", "--porcelain").strip()
        ):
            return ["T29 new source is not the registered clean Git checkout"]
        errors: list[str] = []
        for relative, digest in files.items():
            path = source_root / relative
            if path.resolve() != source_root.joinpath(relative) or not path.is_file():
                errors.append(f"T29 new source file is unavailable: {relative}")
                continue
            content = path.read_bytes()
            if hashlib.sha256(content).hexdigest() != digest:
                errors.append(f"T29 new source hash mismatch: {relative}")
            blob = git("show", f"{T29_SOURCE_COMMIT}:{relative}")
            if content.replace(b"\r\n", b"\n") != blob.replace(b"\r\n", b"\n"):
                errors.append(f"T29 new source Git content mismatch: {relative}")
        return errors
    except (OSError, subprocess.SubprocessError, UnicodeError):
        return ["T29 new source Git checkout cannot be verified"]


def validate_source(source: object, *, allow_new_checkout: bool = False) -> list[str]:
    """Preserve historical hashes; verify the actual Git source for new runs."""
    if not isinstance(source, dict):
        return ["T29 executor lacks source provenance"]
    errors: list[str] = []
    if source.get("git_commit") != T29_SOURCE_COMMIT:
        errors.append("T29 evaluated source commit mismatch")
    if source.get("git_status_porcelain") != "":
        errors.append("T29 evaluated source was not clean")
    if allow_new_checkout:
        return errors + validate_new_checkout(source)
    if source.get("files") != T29_SOURCE_FILES:
        return errors + ["T29 evaluated source file declaration mismatch"]

    source_root = Path(str(source.get("path", "")))
    direct_available = source_root.is_dir()
    if direct_available:
        for relative, digest in T29_SOURCE_FILES.items():
            path = source_root / relative
            if not path.is_file() or sha256(path) != digest:
                errors.append(f"T29 source hash mismatch: {relative}")
    else:
        for name, digest in T29_PATCHES.items():
            patch = SOURCE_PATCHES_DIR / name
            if not patch.is_file() or sha256(patch) != digest:
                errors.append(f"T29 portable source patch hash mismatch: {name}")
    return errors


def equal_number(observed: object, expected: float) -> bool:
    try:
        return math.isclose(float(observed), expected, rel_tol=1.0e-12, abs_tol=1.0e-12)
    except (TypeError, ValueError):
        return False


def validate(run_dir: Path) -> list[str]:
    run_dir = run_dir.resolve()
    errors: list[str] = []
    try:
        executor = read_json(run_dir / "t29_executor.json")
        build = read_json(run_dir / "build_manifest.json")
        environment = read_json(run_dir / "environment_manifest.json")
        manifest = load_manifest(
            resolve_frozen_manifest(
                executor["manifest_path"],
                executor["manifest_sha256"],
                manifests_dir=MANIFESTS_DIR,
                load_manifest=load_manifest,
            )
        )
        semantic_manifest = load_manifest(
            resolve_frozen_manifest(
                executor["semantic_manifest_path"],
                executor["semantic_manifest_sha256"],
                manifests_dir=MANIFESTS_DIR,
                load_manifest=load_manifest,
            )
        )
    except (OSError, KeyError, ValueError, RuntimeError, json.JSONDecodeError) as error:
        return [f"cannot load T29 bundle: {error}"]
    if (executor.get("task"), executor.get("run_id"), executor.get("status")) != (
        "T29",
        run_dir.name,
        "PASS",
    ):
        errors.append("T29 identity/status mismatch")
    if (
        executor.get("manifest_sha256") != manifest["manifest_sha256"]
        or executor.get("semantic_manifest_sha256")
        != semantic_manifest["manifest_sha256"]
    ):
        errors.append("T29 frozen manifest hash mismatch")
    semantic_results = executor.get("semantic_results", [])
    if [item.get("case") for item in semantic_results] != [
        "below",
        "equal",
        "above",
    ]:
        errors.append("T29 semantic boundary coverage mismatch")
    computed_semantic = (
        "PASS"
        if semantic_results
        and all(item.get("retained_rank_matches") is True for item in semantic_results)
        else "SEMANTIC_MISMATCH"
    )
    if executor.get("semantic_gate_status") != computed_semantic:
        errors.append("T29 semantic gate decision mismatch")
    forbidden = executor.get("forbidden_combination_probe", {})
    if (
        forbidden.get("status"),
        forbidden.get("expected_outcome"),
        forbidden.get("returncode") == 0,
    ) != ("PASS", "REJECTED", False):
        errors.append("GESVDR/nonzero-cutoff rejection was not proven")

    source_record = executor.get("source", {})
    errors.extend(validate_source(
        source_record, allow_new_checkout=run_dir.name != T29_HISTORICAL_RUN
    ))
    source = source_record if isinstance(source_record, dict) else {}
    if (
        build.get("run_id"),
        build.get("cmake_cuda_enabled"),
        build.get("cutensornet_enabled"),
        build.get("source", {}).get("commit"),
        build.get("source", {}).get("dirty"),
    ) != (run_dir.name, True, True, source.get("git_commit"), False):
        errors.append("T29 clean CUDA/cuTensorNet build provenance mismatch")
    if (
        environment.get("run_id"),
        environment.get("backend"),
        "GPU" in environment.get("aer", {}).get("available_devices", []),
    ) != (run_dir.name, "custom_gpu", True):
        errors.append("T29 environment/GPU provenance mismatch")

    configurations = executor.get("configurations", [])
    if {item.get("id") for item in configurations} != EXPECTED_CONFIGURATIONS:
        errors.append("T29 configuration coverage mismatch")
    for config in configurations:
        config_id = str(config.get("id"))
        algorithm = config.get("algorithm")
        cutoff = float(config.get("cutoff", -1))
        native = bool(config.get("native"))
        if algorithm == "GESVDR" and cutoff != 0.0:
            errors.append("GESVDR was combined with a nonzero cutoff")
        if algorithm == "GESVDR" and not native:
            errors.append("GESVDR did not use fixed-extent native handling")
        if config.get("correctness_status") == "PASS":
            if float(config.get("fidelity", 0)) < float(config.get("fidelity_min", 1)):
                errors.append(f"reported PASS below fidelity gate: {config_id}")
            if float(config.get("norm_error", 1)) > 1.0e-10:
                errors.append(f"reported PASS above norm gate: {config_id}")
        native_log = run_dir / "correctness" / f"{config_id}.native.jsonl"
        try:
            native_records = read_jsonl(native_log)
        except (OSError, ValueError, json.JSONDecodeError) as error:
            errors.append(f"cannot read T29 native events for {config_id}: {error}")
            native_records = []
        if len(native_records) != int(config.get("native_event_count", -1)):
            errors.append(f"T29 native-event count mismatch: {config_id}")
        observed_algorithms = {
            str(item.get("algorithm")) for item in native_records
        }
        if algorithm == "GESVDR":
            if not {"GESVD", "GESVDR"} <= observed_algorithms:
                errors.append(
                    "adaptive GESVDR did not prove both exact early-split and "
                    "rank-reducing randomized execution"
                )
            reducing_events = [
                item
                for item in native_records
                if item.get("algorithm") == "GESVDR"
            ]
            if not reducing_events or not all(
                int(item.get("reduced_extent", 0)) == 128
                and int(item.get("full_extent", 0)) > 128
                for item in reducing_events
            ):
                errors.append("GESVDR events did not prove the registered rank-128 reduction")
        elif observed_algorithms != {algorithm}:
            errors.append(f"unexpected runtime SVD algorithm for {config_id}")
        timing = config.get("timing", {})
        requires_semantic = "native_cutoff" in config_id
        expected_timing = (
            config.get("correctness_status") == "PASS"
            and (not requires_semantic or computed_semantic == "PASS")
        )
        if expected_timing and timing.get("status") != "PASS":
            errors.append(f"eligible T29 configuration was not timed: {config_id}")
        if not expected_timing and timing.get("status") != "BLOCKED":
            errors.append(f"ineligible T29 configuration was timed: {config_id}")
        if timing.get("status") == "PASS":
            try:
                destination = resolve_run_local(
                    timing.get("destination"),
                    run_dir,
                    Path("timing") / config_id,
                )
                records = read_jsonl(destination / "timings.jsonl")
            except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
                errors.append(f"cannot resolve T29 timing cell {config_id}: {error}")
                continue
            if len(records) != 20:
                errors.append(f"T29 timing sample-count mismatch: {config_id}")
                continue
            try:
                elapsed = [float(record["elapsed_seconds"]) for record in records]
            except (KeyError, TypeError, ValueError) as error:
                errors.append(f"invalid T29 timing record for {config_id}: {error}")
                continue
            if timing.get("sample_count") != len(elapsed):
                errors.append(f"T29 timing aggregate count mismatch: {config_id}")
            for field, expected in (
                ("median_seconds", statistics.median(elapsed)),
                ("minimum_seconds", min(elapsed)),
                ("maximum_seconds", max(elapsed)),
            ):
                if not equal_number(timing.get(field), expected):
                    errors.append(f"T29 timing aggregate {field} mismatch: {config_id}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    errors = validate(args.run_dir.resolve())
    if errors:
        print("BLOCKED T29 evidence")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"PASS: independently validated T29 bundle {args.run_dir.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
